"""Minimal CLI for FunPay Pulse plugin development."""

from __future__ import annotations

import argparse
import importlib.util
import inspect
import json
import os
import re
import shutil
import sys
import tempfile
from importlib import resources
from pathlib import Path
from typing import Any

from .broker import BrokerClient, BrokerClientError, broker_event_from_dict
from .events import EventParseError, parse_broker_event
from .manifest import ManifestValidationError, load_manifest, validate_manifest_file
from .marketplace import (
    DEFAULT_MARKETPLACE_BASE_URL,
    MarketplaceClient,
    MarketplaceClientError,
)
from .marketplace_metadata import (
    DEFAULT_MARKETPLACE_METADATA_FILE,
    MarketplaceMetadata,
    MarketplaceMetadataError,
    load_marketplace_metadata,
)
from .package import PluginPackageError, build_plugin_package
from .testing import FixtureBrokerClient, load_event_fixtures

TEMPLATES: dict[str, str] = {
    "broker-poller": "broker_poller",
    "basic-webhook": "basic_webhook",
    "order-assistant": "order_assistant",
    "trusted-actions": "trusted_actions",
}
FIXTURE_EVENT_ALIASES: dict[str, str] = {
    "new-message": "events:new_message",
    "new_message": "events:new_message",
    "events:new_message": "events:new_message",
    "message": "events:new_message",
    "new-order": "events:new_order",
    "new_order": "events:new_order",
    "events:new_order": "events:new_order",
    "order": "events:new_order",
    "order-confirmed": "events:order_confirmed",
    "order_confirmed": "events:order_confirmed",
    "events:order_confirmed": "events:order_confirmed",
    "confirmed": "events:order_confirmed",
    "new-review": "events:new_review",
    "new_review": "events:new_review",
    "events:new_review": "events:new_review",
    "review": "events:new_review",
}
FIXTURE_EVENT_TYPES = frozenset(FIXTURE_EVENT_ALIASES.values())
READ_ACTION_SCOPES = frozenset({"orders:read", "orders:list", "lots:read"})
BROKER_TOKEN_CLI_RE = re.compile(r"^fppb_[A-Za-z0-9_-]+$")
PULSE_TOKEN_CLI_RE = re.compile(r"\bfpp[bid]_[A-Za-z0-9_-]+")


class PluginTestError(RuntimeError):
    """Raised when the local plugin test runner cannot execute the plugin."""


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="pulse-plugin")
    subparsers = parser.add_subparsers(dest="command", required=True)

    init_parser = subparsers.add_parser("init", help="Create a plugin from an SDK template")
    init_parser.add_argument("plugin_id", help="New plugin id")
    init_parser.add_argument("--out", default=None, help="Output directory; defaults to plugin_id")
    init_parser.add_argument(
        "--template",
        choices=sorted(TEMPLATES),
        default="broker-poller",
        help="Template to use; defaults to broker-poller",
    )

    emit_parser = subparsers.add_parser("emit", help="Create a local Broker event fixture")
    emit_parser.add_argument("output", help="Output JSON fixture path")
    emit_parser.add_argument(
        "--event",
        default=None,
        help=(
            "Fixture event type or alias; supports new_message, new_order, "
            "order_confirmed and new_review"
        ),
    )
    emit_parser.add_argument(
        "--force",
        action="store_true",
        help="Overwrite the output file if it already exists",
    )

    validate_parser = subparsers.add_parser("validate", help="Validate a plugin manifest")
    validate_parser.add_argument("manifest", nargs="?", default="funpay-pulse.plugin.json")
    validate_parser.add_argument("--allow-localhost", action="store_true")
    validate_parser.add_argument("--allow-dangerous-scopes", action="store_true")
    validate_parser.add_argument(
        "--allow-future-scopes",
        action="store_true",
        help="Allow scopes that are planned but not available in the current Broker MVP",
    )
    validate_parser.add_argument(
        "--trusted",
        action="store_true",
        help=(
            "Validate a manually reviewed trusted manifest; allows only "
            "messages:send, orders:refund, orders:review, lots:active, "
            "lots:price, lots:raise, blacklist:add and blacklist:remove"
        ),
    )

    check_parser = subparsers.add_parser("check", help="Run local non-executing plugin checks")
    check_parser.add_argument("plugin_dir", nargs="?", default=".")
    check_parser.add_argument("--allow-localhost", action="store_true")
    check_parser.add_argument("--allow-dangerous-scopes", action="store_true")
    check_parser.add_argument(
        "--allow-future-scopes",
        action="store_true",
        help="Allow scopes that are planned but not available in the current Broker MVP",
    )
    check_parser.add_argument(
        "--trusted",
        action="store_true",
        help=(
            "Validate a manually reviewed trusted manifest; allows only "
            "messages:send, orders:refund, orders:review, lots:active, "
            "lots:price, lots:raise, blacklist:add and blacklist:remove"
        ),
    )
    check_parser.add_argument(
        "--fixtures",
        default="fixtures/events.json",
        help="Fixture path relative to plugin_dir; defaults to fixtures/events.json",
    )
    check_parser.add_argument(
        "--require-fixtures",
        action="store_true",
        help="Fail if the fixture file is missing",
    )

    test_parser = subparsers.add_parser(
        "test",
        help="Run local plugin code once against Broker event fixtures",
    )
    test_parser.add_argument("plugin_dir", nargs="?", default=".")
    test_parser.add_argument("--allow-localhost", action="store_true")
    test_parser.add_argument("--allow-dangerous-scopes", action="store_true")
    test_parser.add_argument(
        "--allow-future-scopes",
        action="store_true",
        help="Allow scopes that are planned but not available in the current Broker MVP",
    )
    test_parser.add_argument(
        "--trusted",
        action="store_true",
        help=(
            "Validate a manually reviewed trusted manifest; allows only "
            "messages:send, orders:refund, orders:review, lots:active, "
            "lots:price, lots:raise, blacklist:add and blacklist:remove"
        ),
    )
    test_parser.add_argument(
        "--fixtures",
        default="fixtures/events.json",
        help="Fixture path relative to plugin_dir; defaults to fixtures/events.json",
    )
    test_parser.add_argument(
        "--config",
        default=None,
        help="Optional JSON config file; defaults come from manifest config_schema",
    )
    test_parser.add_argument("--limit", type=int, default=50)
    test_parser.add_argument(
        "--write-log-actions",
        action="store_true",
        help="Submit local logs.write actions after each processed fixture event",
    )

    doctor_parser = subparsers.add_parser(
        "doctor",
        help="Run full local SDK readiness checks without writing or uploading a package",
    )
    doctor_parser.add_argument("plugin_dir", nargs="?", default=".")
    doctor_parser.add_argument("--allow-localhost", action="store_true")
    doctor_parser.add_argument("--allow-dangerous-scopes", action="store_true")
    doctor_parser.add_argument(
        "--allow-future-scopes",
        action="store_true",
        help="Allow scopes that are planned but not available in the current Broker MVP",
    )
    doctor_parser.add_argument(
        "--trusted",
        action="store_true",
        help=(
            "Validate a manually reviewed trusted manifest; allows only "
            "messages:send, orders:refund, orders:review, lots:active, "
            "lots:price, lots:raise, blacklist:add and blacklist:remove"
        ),
    )
    doctor_parser.add_argument(
        "--fixtures",
        default="fixtures/events.json",
        help="Fixture path relative to plugin_dir; defaults to fixtures/events.json",
    )
    doctor_parser.add_argument(
        "--require-fixtures",
        action="store_true",
        help="Fail if the fixture file is missing",
    )

    pack_parser = subparsers.add_parser("pack", help="Build a safe local .fppkg archive")
    pack_parser.add_argument("plugin_dir", nargs="?", default=".")
    pack_parser.add_argument("--allow-localhost", action="store_true")
    pack_parser.add_argument("--allow-dangerous-scopes", action="store_true")
    pack_parser.add_argument(
        "--allow-future-scopes",
        action="store_true",
        help="Allow scopes that are planned but not available in the current Broker MVP",
    )
    pack_parser.add_argument(
        "--trusted",
        action="store_true",
        help=(
            "Validate a manually reviewed trusted manifest; allows only "
            "messages:send, orders:refund, orders:review, lots:active, "
            "lots:price, lots:raise, blacklist:add and blacklist:remove"
        ),
    )
    pack_parser.add_argument(
        "--fixtures",
        default="fixtures/events.json",
        help="Fixture path relative to plugin_dir; defaults to fixtures/events.json",
    )
    pack_parser.add_argument(
        "--require-fixtures",
        action="store_true",
        help="Fail if the fixture file is missing",
    )
    pack_parser.add_argument(
        "--out",
        default=None,
        help="Output .fppkg path; defaults to dist/<plugin_id>-<version>.fppkg",
    )

    publish_parser = subparsers.add_parser(
        "publish",
        help="Run marketplace publication preflight; real publish requires UI review",
    )
    publish_parser.add_argument("plugin_dir", nargs="?", default=".")
    publish_parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Run local package and server manifest preflight without creating a product",
    )
    publish_parser.add_argument(
        "--upload",
        action="store_true",
        help="Register/upload the package to private marketplace review using a developer token",
    )
    publish_parser.add_argument(
        "--public-review",
        action="store_true",
        help=(
            "After --upload, submit the uploaded package to public marketplace "
            "review with the supplied pricing snapshot"
        ),
    )
    publish_parser.add_argument(
        "--pricing-type",
        choices=("free", "one_time", "subscription", "trial"),
        default=None,
        help="Public marketplace pricing type used with --public-review",
    )
    publish_parser.add_argument(
        "--price-rub",
        type=int,
        default=None,
        help="Public marketplace price in RUB used with --public-review",
    )
    publish_parser.add_argument(
        "--access-duration-days",
        type=int,
        default=None,
        help="Fixed subscription access duration in days used with --public-review",
    )
    publish_parser.add_argument(
        "--trial-days",
        type=int,
        default=None,
        help="Free trial duration in days used with --public-review",
    )
    publish_parser.add_argument(
        "--offline",
        action="store_true",
        help="Skip server dry-run and run local package checks only",
    )
    publish_parser.add_argument(
        "--token",
        default=None,
        help=(
            "SDK developer token; use only for local debugging because shell history "
            "and process args may expose it"
        ),
    )
    publish_parser.add_argument(
        "--token-file",
        default=None,
        help="Read SDK developer token from a local file; safer than --token",
    )
    publish_parser.add_argument(
        "--product-id",
        default=None,
        help="Existing product public id to upload to; otherwise publish registers a private product first",
    )
    publish_parser.add_argument(
        "--base-url",
        "--api",
        dest="base_url",
        default=DEFAULT_MARKETPLACE_BASE_URL,
        help="Marketplace API base URL; defaults to https://funpaypulse.com",
    )
    publish_parser.add_argument(
        "--allow-insecure-localhost",
        action="store_true",
        help="Allow http://localhost base URL for local license-server dry-runs",
    )
    publish_parser.add_argument("--allow-localhost", action="store_true")
    publish_parser.add_argument("--allow-dangerous-scopes", action="store_true")
    publish_parser.add_argument(
        "--allow-future-scopes",
        action="store_true",
        help="Allow scopes that are planned but not available in the current Broker MVP",
    )
    publish_parser.add_argument(
        "--trusted",
        action="store_true",
        help=(
            "Validate a manually reviewed trusted manifest; allows only "
            "messages:send, orders:refund, orders:review, lots:active, "
            "lots:price, lots:raise, blacklist:add and blacklist:remove"
        ),
    )
    publish_parser.add_argument(
        "--fixtures",
        default="fixtures/events.json",
        help="Fixture path relative to plugin_dir; defaults to fixtures/events.json",
    )
    publish_parser.add_argument(
        "--require-fixtures",
        action="store_true",
        help="Fail if the fixture file is missing",
    )
    publish_parser.add_argument(
        "--out",
        default=None,
        help="Output .fppkg path; defaults to dist/<plugin_id>-<version>.fppkg",
    )

    download_parser = subparsers.add_parser(
        "download-package",
        help="Download an installed .fppkg through a Broker token",
    )
    download_parser.add_argument(
        "--broker-token",
        default=None,
        help=(
            "Raw fppb_ Broker token; use only for local debugging because shell "
            "history and process args may expose it"
        ),
    )
    download_parser.add_argument(
        "--broker-token-file",
        default=None,
        help="Read raw fppb_ Broker token from a local file; safer than --broker-token",
    )
    download_parser.add_argument(
        "--base-url",
        "--api",
        dest="base_url",
        default=DEFAULT_MARKETPLACE_BASE_URL,
        help="Broker API base URL; defaults to https://funpaypulse.com",
    )
    download_parser.add_argument(
        "--out",
        default=None,
        help="Output .fppkg path; defaults to <plugin_id>-<version>.fppkg",
    )
    download_parser.add_argument(
        "--force",
        action="store_true",
        help="Overwrite the output file if it already exists",
    )
    download_parser.add_argument(
        "--allow-insecure-localhost",
        action="store_true",
        help="Allow http://localhost base URL for local license-server downloads",
    )

    args = parser.parse_args(argv)

    if args.command == "init":
        return _cmd_init(args.plugin_id, args.out, args.template)
    if args.command == "emit":
        return _cmd_emit(args.output, event=args.event, force=args.force)
    if args.command == "validate":
        return _cmd_validate(
            args.manifest,
            args.allow_localhost,
            args.allow_dangerous_scopes,
            args.allow_future_scopes,
            args.trusted,
        )
    if args.command == "check":
        return _cmd_check(
            args.plugin_dir,
            allow_localhost=args.allow_localhost,
            allow_dangerous_scopes=args.allow_dangerous_scopes,
            allow_future_scopes=args.allow_future_scopes,
            trusted=args.trusted,
            fixture_path=args.fixtures,
            require_fixtures=args.require_fixtures,
        )
    if args.command == "test":
        return _cmd_test(
            args.plugin_dir,
            allow_localhost=args.allow_localhost,
            allow_dangerous_scopes=args.allow_dangerous_scopes,
            allow_future_scopes=args.allow_future_scopes,
            trusted=args.trusted,
            fixture_path=args.fixtures,
            config_path=args.config,
            limit=args.limit,
            write_log_actions=args.write_log_actions,
        )
    if args.command == "doctor":
        return _cmd_doctor(
            args.plugin_dir,
            allow_localhost=args.allow_localhost,
            allow_dangerous_scopes=args.allow_dangerous_scopes,
            allow_future_scopes=args.allow_future_scopes,
            trusted=args.trusted,
            fixture_path=args.fixtures,
            require_fixtures=args.require_fixtures,
        )
    if args.command == "pack":
        return _cmd_pack(
            args.plugin_dir,
            out=args.out,
            allow_localhost=args.allow_localhost,
            allow_dangerous_scopes=args.allow_dangerous_scopes,
            allow_future_scopes=args.allow_future_scopes,
            trusted=args.trusted,
            fixture_path=args.fixtures,
            require_fixtures=args.require_fixtures,
        )
    if args.command == "publish":
        return _cmd_publish(
            args.plugin_dir,
            dry_run=args.dry_run,
            upload=args.upload,
            public_review=args.public_review,
            pricing_type=args.pricing_type,
            price_rub=args.price_rub,
            access_duration_days=args.access_duration_days,
            trial_days=args.trial_days,
            offline=args.offline,
            token=args.token,
            token_file=args.token_file,
            product_id=args.product_id,
            base_url=args.base_url,
            allow_insecure_localhost=args.allow_insecure_localhost,
            out=args.out,
            allow_localhost=args.allow_localhost,
            allow_dangerous_scopes=args.allow_dangerous_scopes,
            allow_future_scopes=args.allow_future_scopes,
            trusted=args.trusted,
            fixture_path=args.fixtures,
            require_fixtures=args.require_fixtures,
        )
    if args.command == "download-package":
        return _cmd_download_package(
            broker_token=args.broker_token,
            broker_token_file=args.broker_token_file,
            base_url=args.base_url,
            out=args.out,
            force=args.force,
            allow_insecure_localhost=args.allow_insecure_localhost,
        )

    parser.error("unknown command")
    return 2


def _cmd_init(plugin_id: str, out: str | None, template: str) -> int:
    destination = Path(out or plugin_id)
    if destination.exists():
        print(f"error: {destination} already exists", file=sys.stderr)
        return 1

    template_dir = TEMPLATES[template]
    template_root = resources.files("funpay_pulse_sdk").joinpath(f"templates/{template_dir}")
    shutil.copytree(template_root, destination, ignore=_ignore_template_artifacts)

    for path in destination.rglob("*"):
        if not path.is_file():
            continue
        try:
            text = path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            continue
        path.write_text(text.replace("seller_auto_reply", plugin_id), encoding="utf-8")

    print(f"created {destination}")
    return 0


def _ignore_template_artifacts(path: str, names: list[str]) -> set[str]:
    return {
        name
        for name in names
        if name == "__pycache__" or name.endswith((".pyc", ".pyo"))
    }


def _cmd_emit(output: str, *, event: str | None, force: bool) -> int:
    output_path = Path(output)
    if output_path.exists() and not force:
        print(f"fixture: {output_path} already exists; use --force to overwrite", file=sys.stderr)
        return 1

    try:
        event_type = _resolve_fixture_event_type(event, output_path)
        fixture = _build_fixture_response(event_type)
        for item in fixture["items"]:
            parse_broker_event(broker_event_from_dict(item))
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(
            json.dumps(fixture, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
    except (BrokerClientError, EventParseError, OSError, ValueError) as exc:
        print(f"fixture: invalid: {exc}", file=sys.stderr)
        return 1

    print(f"fixture: created {output_path} event_type={event_type}")
    return 0


def _resolve_fixture_event_type(event: str | None, output_path: Path) -> str:
    raw_event = event.strip().lower() if event else ""
    if raw_event:
        event_type = FIXTURE_EVENT_ALIASES.get(raw_event)
        if event_type is None:
            raise ValueError(
                "unsupported fixture event; choose one of "
                + ", ".join(sorted(FIXTURE_EVENT_TYPES))
            )
        return event_type

    stem = output_path.stem.lower().replace("-", "_")
    for alias, event_type in sorted(
        FIXTURE_EVENT_ALIASES.items(),
        key=lambda item: len(item[0]),
        reverse=True,
    ):
        normalized_alias = alias.replace("events:", "").replace("-", "_")
        if normalized_alias in stem:
            return event_type
    return "events:new_message"


def _build_fixture_response(event_type: str) -> dict[str, Any]:
    event_name = event_type.removeprefix("events:").replace(":", "_")
    item = {
        "delivery_id": f"del_fixture_{event_name}_1",
        "event_id": f"evt_fixture_{event_name}_1",
        "event_type": event_type,
        "payload": _build_fixture_payload(event_type),
        "created_at": "fixture:now",
        "delivered_at": None,
    }
    return {"items": [item], "count": 1}


def _build_fixture_payload(event_type: str) -> dict[str, Any]:
    base: dict[str, Any] = {
        "schema_version": "broker.events.v1",
        "event_type": event_type,
        "occurred_at": "2026-05-02T10:00:00Z",
        "account_id": "42",
        "account_username": "seller",
        "buyer_id": "300",
        "buyer_username": "buyer",
    }
    if event_type == "events:new_message":
        return {
            **base,
            "chat_id": "100",
            "message_id": "200",
            "author_id": "300",
            "author_username": "buyer",
            "text": "Здравствуйте, товар есть?",
            "is_own": False,
            "is_system": False,
            "sender_type": "buyer",
        }
    if event_type == "events:new_order":
        return {
            **base,
            "occurred_at": "2026-05-02T10:01:00Z",
            "order_id": "ORD1",
            "chat_id": "100",
            "lot_id": "200",
            "quantity": 1,
            "amount": 199.5,
            "title": "Demo item",
            "status": "paid",
        }
    if event_type == "events:order_confirmed":
        return {
            **base,
            "occurred_at": "2026-05-02T10:02:00Z",
            "order_id": "ORD1",
            "chat_id": "100",
            "lot_id": "200",
            "title": "Demo item",
            "old_status": "paid",
            "new_status": "closed",
        }
    if event_type == "events:new_review":
        return {
            **base,
            "occurred_at": "2026-05-02T10:03:00Z",
            "review_id": "REV1",
            "order_id": "ORD1",
            "author_username": "buyer",
            "rating": 5,
            "text": "Все отлично",
            "has_reply": False,
        }
    raise ValueError(
        "unsupported fixture event; choose one of "
        + ", ".join(sorted(FIXTURE_EVENT_TYPES))
    )


def _cmd_validate(
    manifest_path: str,
    allow_localhost: bool,
    allow_dangerous_scopes: bool,
    allow_future_scopes: bool,
    trusted: bool,
) -> int:
    try:
        validate_manifest_file(
            manifest_path,
            allow_localhost=allow_localhost,
            allow_dangerous_scopes=allow_dangerous_scopes,
            allow_future_scopes=allow_future_scopes,
            trusted=trusted,
        )
    except (ManifestValidationError, OSError) as exc:
        print(f"invalid: {exc}", file=sys.stderr)
        return 1

    print("valid")
    return 0


def _cmd_check(
    plugin_dir: str,
    *,
    allow_localhost: bool,
    allow_dangerous_scopes: bool,
    allow_future_scopes: bool,
    trusted: bool,
    fixture_path: str,
    require_fixtures: bool,
) -> int:
    root = Path(plugin_dir)
    manifest_path = root / "funpay-pulse.plugin.json"
    try:
        manifest = validate_manifest_file(
            manifest_path,
            allow_localhost=allow_localhost,
            allow_dangerous_scopes=allow_dangerous_scopes,
            allow_future_scopes=allow_future_scopes,
            trusted=trusted,
        )
    except (ManifestValidationError, OSError) as exc:
        print(f"manifest: invalid: {exc}", file=sys.stderr)
        return 1

    print(f"manifest: valid plugin_id={manifest['plugin_id']}")

    fixture_file = root / fixture_path
    if not fixture_file.exists():
        if require_fixtures:
            print(f"fixtures: missing {fixture_file}", file=sys.stderr)
            return 1
        print(f"fixtures: skipped missing {fixture_file}")
        print("check: ok")
        return 0

    try:
        events = load_event_fixtures(fixture_file)
        for event in events:
            parse_broker_event(event)
    except (BrokerClientError, EventParseError, OSError) as exc:
        print(f"fixtures: invalid: {exc}", file=sys.stderr)
        return 1

    print(f"fixtures: valid events={len(events)}")
    print("check: ok")
    return 0


def _cmd_test(
    plugin_dir: str,
    *,
    allow_localhost: bool,
    allow_dangerous_scopes: bool,
    allow_future_scopes: bool,
    trusted: bool,
    fixture_path: str,
    config_path: str | None,
    limit: int,
    write_log_actions: bool,
) -> int:
    root = Path(plugin_dir)
    manifest_path = root / "funpay-pulse.plugin.json"
    try:
        manifest = validate_manifest_file(
            manifest_path,
            allow_localhost=allow_localhost,
            allow_dangerous_scopes=allow_dangerous_scopes,
            allow_future_scopes=allow_future_scopes,
            trusted=trusted,
        )
    except (ManifestValidationError, OSError) as exc:
        print(f"manifest: invalid: {exc}", file=sys.stderr)
        return 1

    print(f"manifest: valid plugin_id={manifest['plugin_id']}")

    runtime = manifest.get("runtime")
    if not isinstance(runtime, dict) or runtime.get("type") != "broker-poller":
        print("plugin: invalid: test command supports runtime.type=broker-poller only", file=sys.stderr)
        return 1

    fixture_file = root / fixture_path
    if not fixture_file.exists():
        print(f"fixtures: missing {fixture_file}", file=sys.stderr)
        return 1

    try:
        events = load_event_fixtures(fixture_file)
        for event in events:
            parse_broker_event(event)
        config = _load_test_config(root, manifest, config_path)
        client = FixtureBrokerClient(
            events,
            config=config,
            **_fixture_client_options_for_manifest(manifest),
        )
    except (BrokerClientError, EventParseError, OSError, ValueError) as exc:
        print(f"fixtures: invalid: {exc}", file=sys.stderr)
        return 1

    print(f"fixtures: valid events={len(events)}")

    try:
        module = _load_plugin_module(root)
    except PluginTestError as exc:
        print(f"plugin: invalid: {exc}", file=sys.stderr)
        return 1
    except SystemExit as exc:
        print(f"plugin: failed: SystemExit: {exc}", file=sys.stderr)
        return 1
    except Exception as exc:  # noqa: BLE001 - plugin code is intentionally isolated at CLI boundary.
        print(f"plugin: failed: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 1

    try:
        processed = _run_plugin_once(
            module,
            client,
            limit=limit,
            write_log_actions=write_log_actions,
        )
    except PluginTestError as exc:
        print(f"plugin: invalid: {exc}", file=sys.stderr)
        return 1
    except SystemExit as exc:
        print(f"plugin: failed: SystemExit: {exc}", file=sys.stderr)
        return 1
    except Exception as exc:  # noqa: BLE001 - plugin exceptions should become clean CLI failures.
        print(f"plugin: failed: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 1

    print(
        "plugin: processed"
        f" events={processed}"
        f" acked={len(client.acked_delivery_ids)}"
        f" actions={len(client.submitted_actions)}"
    )
    print("test: ok")
    return 0


def _load_test_config(
    root: Path,
    manifest: dict[str, Any],
    config_path: str | None,
) -> dict[str, Any]:
    config = _default_config_from_schema(manifest.get("config_schema"))
    if config_path is None:
        return config

    path = Path(config_path)
    if not path.is_absolute():
        path = root / path
    try:
        override = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise ValueError(f"config file is not valid JSON: {path}") from exc
    if not isinstance(override, dict):
        raise ValueError("config file must contain a JSON object")
    config.update(override)
    return config


def _default_config_from_schema(schema: Any) -> dict[str, Any]:
    if not isinstance(schema, dict):
        return {}
    properties = schema.get("properties")
    if not isinstance(properties, dict):
        return {}
    config: dict[str, Any] = {}
    for key, field_schema in properties.items():
        if not isinstance(key, str) or not isinstance(field_schema, dict):
            continue
        if "default" in field_schema:
            config[key] = field_schema["default"]
    return config


def _fixture_client_options_for_manifest(manifest: dict[str, Any]) -> dict[str, Any]:
    scopes = {
        scope
        for scope in manifest.get("scopes", [])
        if isinstance(scope, str)
    }
    return {
        "read_scopes": READ_ACTION_SCOPES & scopes,
        "allow_message_actions": "messages:send" in scopes,
        "allow_order_refund_actions": "orders:refund" in scopes,
        "allow_order_review_reply_actions": "orders:review" in scopes,
        "allow_lot_actions": "lots:active" in scopes,
        "allow_lot_price_actions": "lots:price" in scopes,
        "allow_lot_raise_actions": "lots:raise" in scopes,
        "allow_blacklist_add_actions": "blacklist:add" in scopes,
        "allow_blacklist_remove_actions": "blacklist:remove" in scopes,
        "allow_secret_storage": "secrets:own" in scopes,
    }


def _load_plugin_module(root: Path) -> Any:
    app_path = root / "app.py"
    if not app_path.exists():
        raise PluginTestError("app.py is missing")

    module_name = f"_funpay_pulse_plugin_test_{root.name}"
    spec = importlib.util.spec_from_file_location(module_name, app_path)
    if spec is None or spec.loader is None:
        raise PluginTestError("app.py cannot be loaded")

    module = importlib.util.module_from_spec(spec)
    original_sys_path = list(sys.path)
    sys.path.insert(0, str(root))
    try:
        sys.modules[module_name] = module
        spec.loader.exec_module(module)
    finally:
        sys.path = original_sys_path
        sys.modules.pop(module_name, None)
    return module


def _run_plugin_once(
    module: Any,
    client: FixtureBrokerClient,
    *,
    limit: int,
    write_log_actions: bool,
) -> int:
    run_once = getattr(module, "run_once", None)
    if not callable(run_once):
        create_app = getattr(module, "create_app", None)
        if callable(create_app):
            plugin_app = create_app(client)
            process_once = getattr(plugin_app, "process_once", None)
            if callable(process_once):
                result = process_once(limit=limit, write_log_actions=write_log_actions)
                return _normalize_processed_count(result)
        raise PluginTestError(
            "app.py must export run_once(client, *, limit, write_log_actions=False)"
        )

    if not _callable_accepts_keyword(run_once, "limit"):
        raise PluginTestError("run_once must accept keyword argument limit")
    kwargs: dict[str, Any] = {"limit": limit}
    if _callable_accepts_keyword(run_once, "write_log_actions"):
        kwargs["write_log_actions"] = write_log_actions
    result = run_once(client, **kwargs)
    return _normalize_processed_count(result)


def _callable_accepts_keyword(callable_obj: Any, name: str) -> bool:
    try:
        signature = inspect.signature(callable_obj)
    except (TypeError, ValueError):
        return True
    return any(
        parameter.kind == inspect.Parameter.VAR_KEYWORD or parameter.name == name
        for parameter in signature.parameters.values()
    )


def _normalize_processed_count(value: Any) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise PluginTestError("run_once must return a non-negative integer")
    return value


def _cmd_doctor(
    plugin_dir: str,
    *,
    allow_localhost: bool,
    allow_dangerous_scopes: bool,
    allow_future_scopes: bool,
    trusted: bool,
    fixture_path: str,
    require_fixtures: bool,
) -> int:
    root = Path(plugin_dir)
    manifest_path = root / "funpay-pulse.plugin.json"
    try:
        manifest = validate_manifest_file(
            manifest_path,
            allow_localhost=allow_localhost,
            allow_dangerous_scopes=allow_dangerous_scopes,
            allow_future_scopes=allow_future_scopes,
            trusted=trusted,
        )
    except (ManifestValidationError, OSError) as exc:
        print(f"manifest: invalid: {exc}", file=sys.stderr)
        return 1

    print(f"manifest: valid plugin_id={manifest['plugin_id']} version={manifest['version']}")

    fixture_file = root / fixture_path
    if not fixture_file.exists():
        if require_fixtures:
            print(f"fixtures: missing {fixture_file}", file=sys.stderr)
            return 1
        print(f"fixtures: skipped missing {fixture_file}")
    else:
        try:
            events = load_event_fixtures(fixture_file)
        except (EventParseError, BrokerClientError, OSError) as exc:
            print(f"fixtures: invalid: {exc}", file=sys.stderr)
            return 1
        print(f"fixtures: valid events={len(events)}")

    try:
        with tempfile.TemporaryDirectory(prefix="pulse-plugin-doctor-") as temp_dir:
            result = build_plugin_package(
                root,
                out=str(Path(temp_dir) / "doctor.fppkg"),
                allow_localhost=allow_localhost,
                allow_dangerous_scopes=allow_dangerous_scopes,
                allow_future_scopes=allow_future_scopes,
                trusted=trusted,
                fixture_path=fixture_path,
                require_fixtures=require_fixtures,
            )
    except (ManifestValidationError, PluginPackageError, OSError) as exc:
        print(f"package: invalid: {exc}", file=sys.stderr)
        return 1

    print(
        "package: valid"
        f" plugin_id={result.plugin_id}"
        f" version={result.plugin_version}"
        f" sha256={result.package_sha256}"
        f" bytes={result.package_bytes}"
    )
    print("doctor: ok")
    print("doctor: no package written, no product created, no upload, no broker token issued")
    return 0


def _cmd_pack(
    plugin_dir: str,
    *,
    out: str | None,
    allow_localhost: bool,
    allow_dangerous_scopes: bool,
    allow_future_scopes: bool,
    trusted: bool,
    fixture_path: str,
    require_fixtures: bool,
) -> int:
    try:
        result = build_plugin_package(
            plugin_dir,
            out=out,
            allow_localhost=allow_localhost,
            allow_dangerous_scopes=allow_dangerous_scopes,
            allow_future_scopes=allow_future_scopes,
            trusted=trusted,
            fixture_path=fixture_path,
            require_fixtures=require_fixtures,
        )
    except (ManifestValidationError, PluginPackageError, OSError) as exc:
        print(f"package: invalid: {exc}", file=sys.stderr)
        return 1

    print(f"package: created {result.package_path}")
    print(f"plugin_id: {result.plugin_id}")
    print(f"version: {result.plugin_version}")
    print(f"files: {result.file_count}")
    print(f"manifest_sha256: {result.manifest_sha256}")
    print(f"package_sha256: {result.package_sha256}")
    print(f"package_bytes: {result.package_bytes}")
    return 0


def _cmd_publish(
    plugin_dir: str,
    *,
    dry_run: bool,
    upload: bool,
    public_review: bool,
    pricing_type: str | None,
    price_rub: int | None,
    access_duration_days: int | None,
    trial_days: int | None,
    offline: bool,
    token: str | None,
    token_file: str | None,
    product_id: str | None,
    base_url: str,
    allow_insecure_localhost: bool,
    out: str | None,
    allow_localhost: bool,
    allow_dangerous_scopes: bool,
    allow_future_scopes: bool,
    trusted: bool,
    fixture_path: str,
    require_fixtures: bool,
) -> int:
    if dry_run and upload:
        print("publish: choose either --dry-run or --upload", file=sys.stderr)
        return 1
    if upload and offline:
        print("publish: --offline cannot be used with --upload", file=sys.stderr)
        return 1
    if public_review and not upload:
        print("publish: --public-review requires --upload", file=sys.stderr)
        return 1
    if not dry_run and not upload:
        print(
            "publish: choose --dry-run for preflight or --upload for private package upload",
            file=sys.stderr,
        )
        return 1
    public_review_payload: dict[str, Any] = {}
    if not public_review:
        try:
            _build_public_review_payload(
                public_review=False,
                pricing_type=pricing_type,
                price_rub=price_rub,
                access_duration_days=access_duration_days,
                trial_days=trial_days,
                marketplace_metadata=None,
            )
        except ValueError as exc:
            print(f"publish: invalid public review pricing: {exc}", file=sys.stderr)
            return 1
    developer_token: str | None = None
    if upload:
        try:
            developer_token = _resolve_developer_token(token, token_file)
        except (OSError, ValueError) as exc:
            print(
                f"publish: invalid developer token source: {_redact_cli_error(exc)}",
                file=sys.stderr,
            )
            return 1
        if not developer_token:
            print(
                "publish: --upload requires --token-file, --token or "
                "FUNPAY_PULSE_DEVELOPER_TOKEN",
                file=sys.stderr,
            )
            return 1

    root = Path(plugin_dir)
    marketplace_metadata = None
    if public_review:
        try:
            marketplace_metadata = load_marketplace_metadata(root)
            public_review_payload = _build_public_review_payload(
                public_review=True,
                pricing_type=pricing_type,
                price_rub=price_rub,
                access_duration_days=access_duration_days,
                trial_days=trial_days,
                marketplace_metadata=marketplace_metadata,
            )
        except (MarketplaceMetadataError, ValueError) as exc:
            print(f"publish: invalid public review pricing: {exc}", file=sys.stderr)
            return 1

    manifest_path = root / "funpay-pulse.plugin.json"
    effective_require_fixtures = require_fixtures or upload
    try:
        manifest = validate_manifest_file(
            manifest_path,
            allow_localhost=allow_localhost,
            allow_dangerous_scopes=allow_dangerous_scopes,
            allow_future_scopes=allow_future_scopes,
            trusted=trusted,
        )
        raw_manifest = load_manifest(manifest_path)
        result = build_plugin_package(
            root,
            out=out,
            allow_localhost=allow_localhost,
            allow_dangerous_scopes=allow_dangerous_scopes,
            allow_future_scopes=allow_future_scopes,
            trusted=trusted,
            fixture_path=fixture_path,
            require_fixtures=effective_require_fixtures,
        )
    except (ManifestValidationError, PluginPackageError, OSError) as exc:
        print(f"publish: invalid: {exc}", file=sys.stderr)
        return 1

    print(f"local: valid plugin_id={manifest['plugin_id']}")
    if upload:
        print("preflight: upload requires valid fixtures and package scanner passed")
    print(f"package: created {result.package_path}")
    print(f"package_sha256: {result.package_sha256}")
    print(f"package_bytes: {result.package_bytes}")
    print(f"manifest_sha256: {result.manifest_sha256}")
    if marketplace_metadata is not None:
        print(
            "marketplace: loaded"
            f" {DEFAULT_MARKETPLACE_METADATA_FILE}"
            f" pricing_type={public_review_payload['pricing_type']}"
            f" price_rub={public_review_payload['price_rub']}"
        )

    if offline:
        print("server: skipped (--offline)")
        print("publish: dry-run ok")
        print("publish: no product created, no package uploaded, no broker token issued")
        return 0

    if upload:
        try:
            client = MarketplaceClient(
                base_url=base_url,
                allow_insecure_localhost=allow_insecure_localhost,
            )
            target_product_id = product_id
            if target_product_id is None:
                registration = client.register_private_product(
                    raw_manifest,
                    developer_token=developer_token,
                )
                target_product_id = registration.product_public_id
                print(
                    "server: registered"
                    f" product_id={registration.product_public_id}"
                    f" plugin_id={registration.plugin_id}"
                    f" version={registration.version or result.plugin_version}"
                )
            upload_result = client.upload_private_package(
                target_product_id,
                result.package_path.read_bytes(),
                package_sha256=result.package_sha256,
                developer_token=developer_token,
            )
            review_result = None
            if public_review:
                review_result = client.submit_public_review(
                    upload_result.product_public_id,
                    developer_token=developer_token,
                    **public_review_payload,
                )
        except (MarketplaceClientError, ValueError, OSError) as exc:
            print(f"server: invalid: {exc}", file=sys.stderr)
            return 1

        print(
            "server: uploaded"
            f" product_id={upload_result.product_public_id}"
            f" plugin_id={upload_result.plugin_id}"
            f" version={upload_result.version or result.plugin_version}"
        )
        print(f"server_package_sha256: {upload_result.package_sha256}")
        print(f"server_package_bytes: {upload_result.package_size_bytes}")
        print(f"server_package_files: {upload_result.package_file_count}")
        print("publish: upload ok")
        if review_result is not None:
            print(
                "server: public-review submitted"
                f" product_id={review_result.product_public_id}"
                f" plugin_id={review_result.plugin_id}"
                f" pricing_type={review_result.pricing_type}"
                f" price_rub={review_result.price_rub}"
            )
            if review_result.access_duration_days:
                print(f"server_access_duration_days: {review_result.access_duration_days}")
            if review_result.trial_days:
                print(f"server_trial_days: {review_result.trial_days}")
            print("publish: public review submitted; no install, no broker token issued")
            return 0
        print("publish: package uploaded for review; no install, no broker token issued")
        return 0

    try:
        server_result = MarketplaceClient(
            base_url=base_url,
            allow_insecure_localhost=allow_insecure_localhost,
        ).validate_manifest(
            raw_manifest,
            allow_localhost=allow_localhost,
            allow_dangerous_scopes=allow_dangerous_scopes,
            allow_future_scopes=allow_future_scopes,
            trusted=trusted,
        )
    except (MarketplaceClientError, ValueError) as exc:
        print(f"server: invalid: {exc}", file=sys.stderr)
        return 1

    if not server_result.dry_run:
        print("server: invalid: response was not marked as dry-run", file=sys.stderr)
        return 1
    if not server_result.valid:
        print("server: invalid", file=sys.stderr)
        for error in server_result.errors:
            print(f"- {error}", file=sys.stderr)
        return 1

    print(
        "server: valid"
        f" plugin_id={server_result.plugin_id or result.plugin_id}"
        f" version={server_result.version or result.plugin_version}"
    )
    if server_result.manifest_sha256:
        print(f"server_manifest_sha256: {server_result.manifest_sha256}")
    if server_result.warnings:
        print("server_warnings:")
        for warning in server_result.warnings:
            print(f"- {warning}")
    print("publish: dry-run ok")
    print("publish: no product created, no package uploaded, no broker token issued")
    return 0


def _cmd_download_package(
    *,
    broker_token: str | None,
    broker_token_file: str | None,
    base_url: str,
    out: str | None,
    force: bool,
    allow_insecure_localhost: bool,
) -> int:
    try:
        resolved_token = _resolve_broker_token(broker_token, broker_token_file)
    except (OSError, ValueError) as exc:
        print(
            f"download-package: invalid broker token source: {_redact_cli_error(exc)}",
            file=sys.stderr,
        )
        return 1
    if not resolved_token:
        print(
            "download-package: requires --broker-token-file, --broker-token or "
            "FPP_BROKER_TOKEN",
            file=sys.stderr,
        )
        return 1

    try:
        client = BrokerClient(
            base_url=base_url,
            broker_token=resolved_token,
            allow_insecure_localhost=allow_insecure_localhost,
        )
        manifest = client.get_package_manifest()
        output_path = Path(out) if out else Path(_safe_package_filename(manifest.plugin_id, manifest.version))
        if output_path.exists() and not force:
            print(
                "download-package: "
                f"{_redact_cli_text(str(output_path))} already exists; use --force",
                file=sys.stderr,
            )
            return 1

        package = client.download_package(expected_sha256=manifest.package_sha256)
        _write_downloaded_package(output_path, package.package_bytes, force=force)
    except (BrokerClientError, OSError, ValueError) as exc:
        print(f"download-package: failed: {_redact_cli_error(exc)}", file=sys.stderr)
        return 1

    print(f"download-package: downloaded {_redact_cli_text(str(output_path))}")
    print(f"plugin_id: {manifest.plugin_id}")
    print(f"version: {manifest.version}")
    print(f"package_sha256: {package.package_sha256}")
    print(f"package_bytes: {package.package_size_bytes}")
    print(f"package_files: {manifest.package_file_count}")
    print("download-package: ok")
    return 0


def _build_public_review_payload(
    *,
    public_review: bool,
    pricing_type: str | None,
    price_rub: int | None,
    access_duration_days: int | None,
    trial_days: int | None,
    marketplace_metadata: MarketplaceMetadata | None,
) -> dict[str, Any]:
    if not public_review:
        if (
            pricing_type is not None
            or price_rub is not None
            or access_duration_days is not None
            or trial_days is not None
        ):
            raise ValueError("pricing flags require --public-review")
        return {}
    metadata_pricing = (
        marketplace_metadata.pricing_defaults()
        if marketplace_metadata is not None
        else {}
    )
    if pricing_type is None:
        pricing_type = metadata_pricing.get("pricing_type")
    if price_rub is None:
        price_rub = metadata_pricing.get("price_rub", 0)
    if access_duration_days is None:
        access_duration_days = metadata_pricing.get("access_duration_days")
    if trial_days is None:
        trial_days = metadata_pricing.get("trial_days", 0)

    if price_rub < 0:
        raise ValueError("--price-rub must be a non-negative integer")
    if access_duration_days is not None and access_duration_days < 1:
        raise ValueError("--access-duration-days must be a positive integer")
    if trial_days < 0:
        raise ValueError("--trial-days must be a non-negative integer")

    normalized_type = pricing_type or ("free" if price_rub == 0 else "one_time")
    if normalized_type == "free":
        if price_rub != 0:
            raise ValueError("free pricing requires --price-rub 0")
        if access_duration_days is not None or trial_days != 0:
            raise ValueError("free pricing does not use duration or trial days")
    elif normalized_type == "one_time":
        if price_rub <= 0:
            raise ValueError("one_time pricing requires --price-rub greater than 0")
        if access_duration_days is not None or trial_days != 0:
            raise ValueError("one_time pricing does not use duration or trial days")
    elif normalized_type == "subscription":
        if price_rub <= 0:
            raise ValueError("subscription pricing requires --price-rub greater than 0")
        if trial_days != 0:
            raise ValueError("subscription pricing does not use --trial-days")
    elif normalized_type == "trial":
        if price_rub != 0:
            raise ValueError("trial pricing requires --price-rub 0")
        if access_duration_days is not None:
            raise ValueError("trial pricing uses --trial-days, not --access-duration-days")
    else:
        raise ValueError("--pricing-type must be free, one_time, subscription or trial")

    return {
        "pricing_type": normalized_type,
        "price_rub": price_rub,
        "access_duration_days": access_duration_days,
        "trial_days": trial_days,
    }


def _resolve_broker_token(token: str | None, token_file: str | None) -> str | None:
    if token and token_file:
        raise ValueError("choose either --broker-token-file or --broker-token")
    if token:
        return _normalize_broker_token(token)
    if token_file:
        value = Path(token_file).read_text(encoding="utf-8")
        return _normalize_broker_token(value)
    env_value = os.getenv("FPP_BROKER_TOKEN")
    if env_value is not None and env_value.strip():
        return _normalize_broker_token(env_value)
    legacy_env_value = os.getenv("FUNPAY_PULSE_BROKER_TOKEN")
    if legacy_env_value is not None and legacy_env_value.strip():
        return _normalize_broker_token(legacy_env_value)
    return None


def _normalize_broker_token(value: str) -> str:
    normalized = value.strip()
    if not normalized:
        raise ValueError("broker token is empty")
    if any(char.isspace() for char in normalized) or BROKER_TOKEN_CLI_RE.fullmatch(normalized) is None:
        raise ValueError("broker token must be a well-formed fppb_ token")
    return normalized


def _write_downloaded_package(output_path: Path, package_bytes: bytes, *, force: bool) -> None:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    if force:
        output_path.write_bytes(package_bytes)
        return
    try:
        with output_path.open("xb") as handle:
            handle.write(package_bytes)
    except FileExistsError as exc:
        raise ValueError(f"{output_path} already exists; use --force") from exc


def _redact_cli_error(exc: BaseException) -> str:
    return _redact_cli_text(str(exc))


def _redact_cli_text(text: str) -> str:
    return PULSE_TOKEN_CLI_RE.sub(lambda match: f"{match.group(0)[:5]}<redacted>", text)


def _safe_package_filename(plugin_id: str, version: str) -> str:
    raw_name = f"{plugin_id}-{version}.fppkg"
    safe_name = re.sub(r"[^A-Za-z0-9_.-]+", "-", raw_name).strip(".-")
    if not safe_name or safe_name == "fppkg":
        return "plugin-package.fppkg"
    if not safe_name.endswith(".fppkg"):
        safe_name = f"{safe_name}.fppkg"
    return safe_name


def _resolve_developer_token(token: str | None, token_file: str | None) -> str | None:
    if token and token_file:
        raise ValueError("choose either --token-file or --token")
    if token:
        return token.strip()
    if token_file:
        value = Path(token_file).read_text(encoding="utf-8").strip()
        if not value:
            raise ValueError("developer token file is empty")
        if any(char.isspace() for char in value):
            raise ValueError("developer token file must contain only one token")
        return value
    return os.getenv("FUNPAY_PULSE_DEVELOPER_TOKEN")


if __name__ == "__main__":
    raise SystemExit(main())
