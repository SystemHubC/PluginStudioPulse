# Trusted Actions Template

This template is for manually reviewed plugins only. The generated manifest is
safe by default and requests only `logs:write`.

Add only the mutating scope your plugin really needs before review:

- `messages:send` for delivery-bound buyer replies.
- `orders:refund` for delivery-bound refunds.
- `orders:review` for delivery-bound replies to new buyer reviews.
- `lots:active` for enabling/disabling the event lot.
- `lots:price` for changing the event lot price.
- `lots:raise` for raising the event lot subcategory through Pulse-owned checks.
- `blacklist:add` for adding only the delivery-bound buyer to per-account blacklist.
- `blacklist:remove` for removing only plugin-owned blacklist entries for that buyer.

After adding any of those scopes, validate with:

```bash
pulse-plugin validate funpay-pulse.plugin.json --allow-localhost --trusted
pulse-plugin check . --allow-localhost --trusted
```

Production use still requires platform approval, a trusted product state,
explicit install confirmation, license-server Broker flags, and the
Worker/Backend action executor.

Local fixture run:

```bash
python app.py --fixtures fixtures/events.json --demo-reply --demo-review-reply --demo-refund --demo-disable-lot --demo-price 42.5 --demo-raise-lot --demo-blacklist-add
```

The plugin never receives FunPay credentials. It queues delivery-bound Broker
actions and relies on the platform executor to perform approved actions.
Bundled demo fixtures use `created_at: "fixture:now"` so they stay fresh for
local demos; use fixed old timestamps in your own tests when checking stale
delivery rejection.
