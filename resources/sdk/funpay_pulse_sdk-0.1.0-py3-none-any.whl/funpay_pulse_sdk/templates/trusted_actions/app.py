"""Trusted action workflow template for manually reviewed Broker plugins."""

from __future__ import annotations

import argparse
import logging
import os
from pathlib import Path
from typing import Any

from funpay_pulse_sdk import (
    BrokerClient,
    FixtureBrokerClient,
    NewMessageEvent,
    NewOrderEvent,
    NewReviewEvent,
    PluginApp,
    PluginContext,
)


LOG = logging.getLogger("seller_auto_reply")


def read_broker_token() -> str:
    token_file = os.environ.get("FPP_BROKER_TOKEN_FILE", "").strip()
    if token_file:
        return Path(token_file).read_text(encoding="utf-8").strip()
    return os.environ["FPP_BROKER_TOKEN"]


def build_client(args: argparse.Namespace):
    if args.fixtures:
        config = {
            "enabled": True,
            "reply_to_messages": bool(args.demo_reply),
            "reply_text": args.reply_text,
            "reply_to_reviews": bool(args.demo_review_reply),
            "review_reply_text": args.review_reply_text,
            "refund_demo_orders": bool(args.demo_refund),
            "blacklist_message_sender": bool(args.demo_blacklist_add),
            "remove_message_sender_from_blacklist": bool(args.demo_blacklist_remove),
            "disable_lot_on_order": bool(args.demo_disable_lot),
            "target_lot_price": float(args.demo_price or 0),
            "raise_lot_on_order": bool(args.demo_raise_lot),
        }
        return FixtureBrokerClient.from_file(
            args.fixtures,
            config=config,
            allow_message_actions=True,
            allow_order_refund_actions=True,
            allow_order_review_reply_actions=True,
            allow_lot_actions=True,
            allow_lot_price_actions=True,
            allow_lot_raise_actions=True,
            allow_blacklist_add_actions=True,
            allow_blacklist_remove_actions=True,
        )

    base_url = os.environ.get("FPP_BASE_URL", "https://funpaypulse.com")
    broker_token = read_broker_token()
    allow_localhost = os.environ.get("FPP_ALLOW_INSECURE_LOCALHOST") == "1"
    return BrokerClient(
        base_url=base_url,
        broker_token=broker_token,
        allow_insecure_localhost=allow_localhost,
    )


def create_app(client) -> PluginApp:
    app = PluginApp(client, logger=LOG)

    @app.on(NewMessageEvent)
    def handle_message(event: NewMessageEvent, context: PluginContext) -> None:
        if event.is_own or event.is_system:
            return
        if not _enabled(context):
            return
        capabilities = context.client.get_capabilities()
        reply_text = context.config.get("reply_text") or "Здравствуйте."
        if (
            context.config.get("reply_to_messages") is True
            and "messages.send" in capabilities.supported_actions
            and event.account_id
        ):
            context.client.send_message(
                account_id=event.account_id,
                chat_id=event.chat_id,
                delivery_id=event.delivery_id,
                text=str(reply_text),
                idempotency_key=f"reply-{event.delivery_id}",
            )
        if (
            context.config.get("blacklist_message_sender") is True
            and "blacklist.add" in capabilities.supported_actions
            and event.account_id
            and event.buyer_username
        ):
            context.client.add_to_blacklist(
                account_id=event.account_id,
                username=event.buyer_username,
                buyer_id=event.buyer_id,
                delivery_id=event.delivery_id,
                reason="Demo trusted action",
                idempotency_key=f"blacklist-add-{event.delivery_id}",
            )
        if (
            context.config.get("remove_message_sender_from_blacklist") is True
            and "blacklist.remove" in capabilities.supported_actions
            and event.account_id
            and event.buyer_username
        ):
            context.client.remove_from_blacklist(
                account_id=event.account_id,
                username=event.buyer_username,
                buyer_id=event.buyer_id,
                delivery_id=event.delivery_id,
                idempotency_key=f"blacklist-remove-{event.delivery_id}",
            )

    @app.on(NewOrderEvent)
    def handle_order(event: NewOrderEvent, context: PluginContext) -> None:
        if not _enabled(context) or not event.account_id:
            return
        capabilities = context.client.get_capabilities()
        if (
            context.config.get("refund_demo_orders") is True
            and "orders.refund" in capabilities.supported_actions
        ):
            context.client.refund_order(
                account_id=event.account_id,
                order_id=event.order_id,
                delivery_id=event.delivery_id,
                idempotency_key=f"refund-{event.delivery_id}",
            )
        if (
            context.config.get("disable_lot_on_order") is True
            and "lots.active.set" in capabilities.supported_actions
            and event.lot_id
        ):
            context.client.set_lot_active(
                account_id=event.account_id,
                lot_id=event.lot_id,
                enabled=False,
                delivery_id=event.delivery_id,
                idempotency_key=f"lot-disable-{event.delivery_id}",
            )
        target_price = _positive_price(context.config.get("target_lot_price"))
        if (
            target_price is not None
            and "lots.price.set" in capabilities.supported_actions
            and event.lot_id
        ):
            context.client.set_lot_price(
                account_id=event.account_id,
                lot_id=event.lot_id,
                price=target_price,
                delivery_id=event.delivery_id,
                idempotency_key=f"lot-price-{event.delivery_id}",
            )
        if (
            context.config.get("raise_lot_on_order") is True
            and "lots.raise" in capabilities.supported_actions
            and event.lot_id
        ):
            context.client.raise_lots(
                account_id=event.account_id,
                lot_id=event.lot_id,
                delivery_id=event.delivery_id,
                idempotency_key=f"lot-raise-{event.delivery_id}",
            )

    @app.on(NewReviewEvent)
    def handle_review(event: NewReviewEvent, context: PluginContext) -> None:
        if not _enabled(context) or not event.account_id or not event.order_id:
            return
        if event.has_reply:
            return
        capabilities = context.client.get_capabilities()
        reply_text = context.config.get("review_reply_text") or context.config.get("reply_text")
        if (
            context.config.get("reply_to_reviews") is True
            and "orders.review.reply" in capabilities.supported_actions
            and reply_text
        ):
            context.client.reply_to_review(
                account_id=event.account_id,
                order_id=event.order_id,
                delivery_id=event.delivery_id,
                text=str(reply_text),
                idempotency_key=f"review-reply-{event.delivery_id}",
            )

    return app


def run_once(client, *, limit: int, write_log_actions: bool = False) -> int:
    return create_app(client).process_once(
        limit=limit,
        write_log_actions=write_log_actions,
    )


def _enabled(context: PluginContext) -> bool:
    return context.config.get("enabled", True) is not False


def _positive_price(value: Any) -> float | None:
    if value in (None, "", 0, 0.0):
        return None
    try:
        price = float(value)
    except (TypeError, ValueError):
        return None
    if price <= 0:
        return None
    return price


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="seller_auto_reply")
    parser.add_argument("--fixtures", help="Run against local Broker event fixtures instead of the real API")
    parser.add_argument("--limit", type=int, default=50)
    parser.add_argument("--once", action="store_true", help="Process one poll batch and exit")
    parser.add_argument("--poll-interval", type=float, default=3.0, help="Seconds between empty production polls")
    parser.add_argument("--reply-text", default="Здравствуйте, заказ принят в обработку.")
    parser.add_argument("--review-reply-text", default="Спасибо за отзыв.")
    parser.add_argument("--demo-reply", action="store_true", help="Queue demo message replies in fixture mode")
    parser.add_argument("--demo-review-reply", action="store_true", help="Queue demo review replies in fixture mode")
    parser.add_argument("--demo-refund", action="store_true", help="Queue demo refunds in fixture mode")
    parser.add_argument("--demo-blacklist-add", action="store_true", help="Queue demo blacklist.add actions in fixture mode")
    parser.add_argument("--demo-blacklist-remove", action="store_true", help="Queue demo blacklist.remove actions in fixture mode")
    parser.add_argument("--demo-disable-lot", action="store_true", help="Queue demo lot disable actions in fixture mode")
    parser.add_argument("--demo-price", type=float, default=0.0, help="Queue demo lot price actions in fixture mode")
    parser.add_argument("--demo-raise-lot", action="store_true", help="Queue demo lot raise actions in fixture mode")
    parser.add_argument(
        "--write-log-actions",
        action="store_true",
        help="Submit logs.write actions after each processed event; requires logs:write in production",
    )
    args = parser.parse_args(argv)

    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")
    client = build_client(args)
    app = create_app(client)
    if args.fixtures or args.once:
        processed = app.process_once(
            limit=args.limit,
            write_log_actions=args.write_log_actions,
        )
        LOG.info("processed %s event(s)", processed)
    else:
        LOG.info("starting production trusted actions poller")
        app.run_forever(
            limit=args.limit,
            poll_interval_seconds=args.poll_interval,
            write_log_actions=args.write_log_actions,
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
