import os
from http.server import BaseHTTPRequestHandler, HTTPServer

from funpay_pulse_sdk import BrokerClient, WebhookSignatureError, verify_webhook_signature


def load_webhook_secret() -> str:
    explicit_secret = os.environ.get("FUNPAY_PULSE_WEBHOOK_SECRET", "").strip()
    if explicit_secret:
        return explicit_secret

    base_url = os.environ.get("FUNPAY_PULSE_BASE_URL", "").strip()
    broker_token = os.environ.get("FUNPAY_PULSE_BROKER_TOKEN", "").strip()
    if base_url and broker_token:
        return BrokerClient(
            base_url=base_url,
            broker_token=broker_token,
            allow_insecure_localhost=base_url.startswith("http://localhost")
            or base_url.startswith("http://127."),
        ).get_webhook_secret().webhook_secret

    return "dev_secret_change_me"


WEBHOOK_SECRET = load_webhook_secret()


class Handler(BaseHTTPRequestHandler):
    def do_POST(self):
        length = int(self.headers.get("Content-Length", "0"))
        body = self.rfile.read(length)

        try:
            verify_webhook_signature(secret=WEBHOOK_SECRET, body=body, headers=self.headers)
        except WebhookSignatureError:
            self.send_response(401)
            self.end_headers()
            return

        self.send_response(204)
        self.end_headers()


if __name__ == "__main__":
    HTTPServer(("127.0.0.1", 8787), Handler).serve_forever()
