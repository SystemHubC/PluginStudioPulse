"""Safe order/lot workflow template for FunPay Pulse Broker plugins."""

from __future__ import annotations

import argparse
import logging
import os
from pathlib import Path
from typing import Any

from funpay_pulse_sdk import (
    BrokerClient,
    BrokerClientError,
    FixtureBrokerClient,
    NewOrderEvent,
    NewReviewEvent,
    OrderConfirmedEvent,
    PluginApp,
    PluginContext,
)


LOG = logging.getLogger("seller_auto_reply")
METRICS_KEY = "order_assistant_metrics"


def read_broker_token() -> str:
    token_file = os.environ.get("FPP_BROKER_TOKEN_FILE", "").strip()
    if token_file:
        return Path(token_file).read_text(encoding="utf-8").strip()
    return os.environ["FPP_BROKER_TOKEN"]


def build_client(args: argparse.Namespace):
    if args.fixtures:
        config = {
            "enabled": True,
            "external_service_ref": "external_api_key" if args.fixture_secret else "",
        }
        client = FixtureBrokerClient.from_file(
            args.fixtures,
            config=config,
            allow_read_actions=True,
            allow_secret_storage=True,
        )
        if args.fixture_secret:
            client.set_secret_item("external_api_key", args.fixture_secret)
        return client

    base_url = os.environ.get("FPP_BASE_URL", "https://funpaypulse.com")
    broker_token = read_broker_token()
    allow_localhost = os.environ.get("FPP_ALLOW_INSECURE_LOCALHOST") == "1"
    return BrokerClient(
        base_url=base_url,
        broker_token=broker_token,
        allow_insecure_localhost=allow_localhost,
    )


def create_app(client) -> PluginApp:
    app = PluginApp(client, logger=LOG)

    @app.on(NewOrderEvent)
    def handle_new_order(event: NewOrderEvent, context: PluginContext) -> None:
        capabilities = context.client.get_capabilities()
        _increment_metric(context.client, capabilities, "orders_seen")
        _load_external_secret(context, capabilities)
        _queue_order_reads(context.client, capabilities, event)

    @app.on(OrderConfirmedEvent)
    def handle_order_confirmed(event: OrderConfirmedEvent, context: PluginContext) -> None:
        capabilities = context.client.get_capabilities()
        _increment_metric(context.client, capabilities, "orders_confirmed")
        _queue_order_reads(context.client, capabilities, event)

    @app.on(NewReviewEvent)
    def handle_new_review(event: NewReviewEvent, context: PluginContext) -> None:
        capabilities = context.client.get_capabilities()
        _increment_metric(context.client, capabilities, "reviews_seen")
        if "orders.get" in capabilities.supported_actions and event.account_id and event.order_id:
            context.client.get_order(
                account_id=event.account_id,
                order_id=event.order_id,
                delivery_id=event.delivery_id,
                idempotency_key=f"order-get-{event.delivery_id}",
            )

    return app


def run_once(client, *, limit: int, write_log_actions: bool = False) -> int:
    return create_app(client).process_once(
        limit=limit,
        write_log_actions=write_log_actions,
    )


def _queue_order_reads(client: Any, capabilities: Any, event: Any) -> None:
    if "orders.get" in capabilities.supported_actions and event.account_id and event.order_id:
        client.get_order(
            account_id=event.account_id,
            order_id=event.order_id,
            delivery_id=event.delivery_id,
            idempotency_key=f"order-get-{event.delivery_id}",
        )
    if "orders.list" in capabilities.supported_actions and event.account_id:
        client.list_orders(
            account_id=event.account_id,
            delivery_id=event.delivery_id,
            status="paid",
            limit=10,
            idempotency_key=f"orders-list-{event.delivery_id}",
        )
    if "lots.get" in capabilities.supported_actions and event.account_id and event.lot_id:
        client.get_lot(
            account_id=event.account_id,
            lot_id=event.lot_id,
            delivery_id=event.delivery_id,
            idempotency_key=f"lot-get-{event.delivery_id}",
        )
    if "lots.list" in capabilities.supported_actions and event.account_id:
        client.list_lots(
            account_id=event.account_id,
            delivery_id=event.delivery_id,
            limit=10,
            idempotency_key=f"lots-list-{event.delivery_id}",
        )


def _increment_metric(client: Any, capabilities: Any, field: str) -> None:
    if not (capabilities.broker_storage_enabled and capabilities.storage_authorized):
        return
    try:
        current = client.get_storage_item(METRICS_KEY).value
    except BrokerClientError:
        current = {}
    if not isinstance(current, dict):
        current = {}
    next_value = int(current.get(field) or 0) + 1
    current[field] = next_value
    client.set_storage_item(METRICS_KEY, current)


def _load_external_secret(context: PluginContext, capabilities: Any) -> None:
    if not (capabilities.broker_secrets_enabled and capabilities.secret_storage_authorized):
        return
    credential_ref = context.config.get("external_service_ref")
    if not isinstance(credential_ref, str) or not credential_ref.strip():
        return
    secret_key = credential_ref.strip()
    try:
        secret = context.client.get_secret_item(secret_key).value
    except (BrokerClientError, ValueError):
        LOG.warning("external service credential reference is not configured")
        return
    if secret:
        LOG.info("external service credential is configured")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="seller_auto_reply")
    parser.add_argument("--fixtures", help="Run against local Broker event fixtures instead of the real API")
    parser.add_argument("--fixture-secret", default="", help="Seed local fixture secret storage with a demo external API key")
    parser.add_argument("--limit", type=int, default=50)
    parser.add_argument("--once", action="store_true", help="Process one poll batch and exit")
    parser.add_argument("--poll-interval", type=float, default=3.0, help="Seconds between empty production polls")
    parser.add_argument(
        "--write-log-actions",
        action="store_true",
        help="Submit logs.write actions after each processed event; requires logs:write in production",
    )
    args = parser.parse_args(argv)

    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")
    client = build_client(args)
    app = create_app(client)
    if args.fixtures or args.once:
        processed = app.process_once(
            limit=args.limit,
            write_log_actions=args.write_log_actions,
        )
        LOG.info("processed %s event(s)", processed)
    else:
        LOG.info("starting production order assistant poller")
        app.run_forever(
            limit=args.limit,
            poll_interval_seconds=args.poll_interval,
            write_log_actions=args.write_log_actions,
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
