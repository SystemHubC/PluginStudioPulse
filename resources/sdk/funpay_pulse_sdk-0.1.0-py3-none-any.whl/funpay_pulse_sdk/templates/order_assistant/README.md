# Seller Order Assistant

Safe Broker polling template for plugins that need order and lot context.

This template shows the recommended pattern for external developers:

- read runtime capabilities before using optional features;
- use `orders.get`, `orders.list`, `lots.get`, and `lots.list` only when the installation has the matching scopes;
- store non-secret plugin state in Broker storage;
- store external provider credentials in Broker secret storage after install;
- never read or handle FunPay credentials, cookies, golden keys, connection tokens, or raw Worker internals.

## Local Run

```bash
python app.py --fixtures fixtures/events.json --write-log-actions
```

To test secret storage locally, seed a fixture credential:

```bash
python app.py --fixtures fixtures/events.json --fixture-secret sk_test_external
```

In production, run with a real Broker token:

```bash
export FPP_BASE_URL=https://funpaypulse.com
export FPP_BROKER_TOKEN_FILE=/etc/funpay-pulse/plugins/order-assistant/broker-token
python app.py
```

The install config field `external_service_ref` is only a reference to a
plugin-owned Broker secret item. The credential value itself must be written
through `client.set_secret_item(...)` or a platform UI that calls the same
secret storage API.
