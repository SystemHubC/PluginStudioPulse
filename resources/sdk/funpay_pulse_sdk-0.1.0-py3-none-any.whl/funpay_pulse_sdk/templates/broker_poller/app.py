"""Local-first FunPay Pulse Broker polling plugin template."""

from __future__ import annotations

import argparse
import logging
import os
from pathlib import Path

from funpay_pulse_sdk import (
    BrokerClient,
    FixtureBrokerClient,
    NewMessageEvent,
    NewOrderEvent,
    NewReviewEvent,
    OrderConfirmedEvent,
    PluginApp,
)


LOG = logging.getLogger("seller_auto_reply")


def read_broker_token() -> str:
    token_file = os.environ.get("FPP_BROKER_TOKEN_FILE", "").strip()
    if token_file:
        return Path(token_file).read_text(encoding="utf-8").strip()
    return os.environ["FPP_BROKER_TOKEN"]


def build_client(args: argparse.Namespace):
    if args.fixtures:
        return FixtureBrokerClient.from_file(args.fixtures)

    base_url = os.environ.get("FPP_BASE_URL", "https://funpaypulse.com")
    broker_token = read_broker_token()
    allow_localhost = os.environ.get("FPP_ALLOW_INSECURE_LOCALHOST") == "1"
    return BrokerClient(
        base_url=base_url,
        broker_token=broker_token,
        allow_insecure_localhost=allow_localhost,
    )


def create_app(client) -> PluginApp:
    app = PluginApp(client, logger=LOG)

    @app.on(NewMessageEvent)
    def handle_new_message(event: NewMessageEvent) -> None:
        LOG.info(
            "new message chat=%s author=%s text=%r",
            event.chat_id,
            event.author_username or event.buyer_username,
            event.text,
        )

    @app.on(NewOrderEvent)
    def handle_new_order(event: NewOrderEvent) -> None:
        LOG.info("new order id=%s buyer=%s title=%r", event.order_id, event.buyer_username, event.title)

    @app.on(OrderConfirmedEvent)
    def handle_order_confirmed(event: OrderConfirmedEvent) -> None:
        LOG.info("order confirmed id=%s status=%s", event.order_id, event.new_status)

    @app.on(NewReviewEvent)
    def handle_new_review(event: NewReviewEvent) -> None:
        LOG.info("new review id=%s rating=%s text=%r", event.review_id, event.rating, event.text)

    return app


def run_once(client, *, limit: int, write_log_actions: bool = False) -> int:
    return create_app(client).process_once(
        limit=limit,
        write_log_actions=write_log_actions,
    )


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="seller_auto_reply")
    parser.add_argument("--fixtures", help="Run against local Broker event fixtures instead of the real API")
    parser.add_argument("--limit", type=int, default=50)
    parser.add_argument("--once", action="store_true", help="Process one poll batch and exit")
    parser.add_argument("--poll-interval", type=float, default=3.0, help="Seconds between empty production polls")
    parser.add_argument(
        "--write-log-actions",
        action="store_true",
        help="Submit logs.write actions after each processed event; requires logs:write in production",
    )
    args = parser.parse_args(argv)

    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")
    client = build_client(args)
    app = create_app(client)
    if args.fixtures or args.once:
        processed = app.process_once(
            limit=args.limit,
            write_log_actions=args.write_log_actions,
        )
        LOG.info("processed %s event(s)", processed)
    else:
        LOG.info("starting production poller")
        app.run_forever(
            limit=args.limit,
            poll_interval_seconds=args.poll_interval,
            write_log_actions=args.write_log_actions,
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
