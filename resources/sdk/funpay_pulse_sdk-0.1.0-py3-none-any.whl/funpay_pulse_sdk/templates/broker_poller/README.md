# seller_auto_reply

Local-first FunPay Pulse Broker polling plugin template.

Run against bundled fixtures:

```bash
python app.py --fixtures fixtures/events.json
```

Run fixtures and record local `logs.write` actions:

```bash
python app.py --fixtures fixtures/events.json --write-log-actions
```

Run against the real Broker API after installing the plugin in FunPay Pulse:

```bash
export FPP_BASE_URL=https://funpaypulse.com
export FPP_BROKER_TOKEN_FILE=/etc/funpay-pulse/plugins/seller-auto-reply/broker-token
python app.py
```

Production mode keeps polling. For a one-shot production smoke check:

```bash
python app.py --once
```

`--write-log-actions` requires `logs:write` in the installed manifest when used
against production. The template reads install config through `client.get_config()`
and skips processing when `enabled` is `false`.

Ack events only after your plugin has durably processed them. Do not commit raw
`fppb_...` tokens.
