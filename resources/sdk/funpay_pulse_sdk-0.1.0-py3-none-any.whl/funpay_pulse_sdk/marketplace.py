"""Marketplace preflight client for SDK publication workflows."""

from __future__ import annotations

import ipaddress
import json
import re
import base64
from dataclasses import dataclass
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.parse import quote, urljoin, urlparse
from urllib.request import HTTPRedirectHandler, Request, build_opener

DEFAULT_MARKETPLACE_BASE_URL = "https://funpaypulse.com"
MAX_MARKETPLACE_RESPONSE_BYTES = 2 * 1024 * 1024
MAX_MARKETPLACE_ERROR_BYTES = 16 * 1024

_SECRET_ASSIGNMENT_RE = re.compile(
    r"(?i)([\"']?(?:authorization|api[_-]?key|connection[_-]?token|cookie|"
    r"golden[_-]?key|password|secret|signing[_-]?secret|token)[\"']?\s*[:=]\s*[\"']?)"
    r"([^\"'&\s,}]{4,})"
)
_SECRET_QUERY_RE = re.compile(
    r"(?i)([?&](?:authorization|api[_-]?key|connection[_-]?token|cookie|"
    r"golden[_-]?key|password|secret|signing[_-]?secret|token)=)([^&\s\"']+)"
)
_BEARER_RE = re.compile(r"(?i)\bBearer\s+[A-Za-z0-9._~+/=-]{12,}")
_PULSE_TOKEN_RE = re.compile(r"\bfpp[bid]_[A-Za-z0-9_-]{8,}")


class MarketplaceClientError(RuntimeError):
    """Raised when marketplace preflight cannot be trusted."""


@dataclass(frozen=True)
class MarketplaceManifestValidation:
    """Server-side manifest validation result from marketplace dry-run API."""

    valid: bool
    errors: tuple[str, ...]
    warnings: tuple[str, ...]
    plugin_id: str | None
    version: str | None
    manifest_sha256: str | None
    scopes: tuple[str, ...]
    dangerous_scopes: tuple[str, ...]
    dry_run: bool
    raw: dict[str, Any]


@dataclass(frozen=True)
class MarketplacePrivateProductRegistration:
    """Authenticated SDK private product registration result."""

    product_public_id: str
    plugin_id: str
    version: str | None
    manifest_sha256: str | None
    raw: dict[str, Any]


@dataclass(frozen=True)
class MarketplacePrivatePackageUpload:
    """Authenticated SDK private package upload result."""

    product_public_id: str
    plugin_id: str
    version: str | None
    package_sha256: str
    package_size_bytes: int
    package_file_count: int
    broker_token: None
    raw: dict[str, Any]


@dataclass(frozen=True)
class MarketplacePublicReviewSubmission:
    """Authenticated SDK public marketplace review submission result."""

    product_public_id: str
    plugin_id: str
    pricing_type: str
    price_rub: int
    access_duration_days: int | None
    trial_days: int
    submitted: bool
    raw: dict[str, Any]


class MarketplaceClient:
    """Small dependency-free client for public marketplace SDK preflight APIs."""

    def __init__(
        self,
        *,
        base_url: str = DEFAULT_MARKETPLACE_BASE_URL,
        timeout_seconds: int = 10,
        allow_insecure_localhost: bool = False,
        opener: Any | None = None,
    ) -> None:
        _validate_base_url(base_url, allow_insecure_localhost=allow_insecure_localhost)
        if not isinstance(timeout_seconds, int) or isinstance(timeout_seconds, bool):
            raise ValueError("timeout_seconds must be an integer")
        if timeout_seconds < 1 or timeout_seconds > 60:
            raise ValueError("timeout_seconds must be between 1 and 60")
        self.base_url = base_url.rstrip("/") + "/"
        self.timeout_seconds = timeout_seconds
        self._opener = opener or build_opener(_NoRedirectHandler)

    def validate_manifest(
        self,
        manifest: dict[str, Any],
        *,
        allow_localhost: bool = False,
        allow_dangerous_scopes: bool = False,
        allow_future_scopes: bool = False,
        trusted: bool = False,
    ) -> MarketplaceManifestValidation:
        """Run the server's public dry-run manifest validator."""

        if not isinstance(manifest, dict):
            raise ValueError("manifest must be a JSON object")
        payload = {
            "manifest": manifest,
            "allow_localhost": bool(allow_localhost),
            "allow_dangerous_scopes": bool(allow_dangerous_scopes),
            "allow_future_scopes": bool(allow_future_scopes),
            "trusted": bool(trusted),
        }
        data = self._request_json(
            "POST",
            "/api/v2/plugin-marketplace/products/validate",
            body=json.dumps(
                payload,
                ensure_ascii=False,
                sort_keys=True,
                separators=(",", ":"),
            ).encode("utf-8"),
        )
        return marketplace_manifest_validation_from_dict(data)

    def register_private_product(
        self,
        manifest: dict[str, Any],
        *,
        developer_token: str,
    ) -> MarketplacePrivateProductRegistration:
        """Register a private product through the SDK developer-token API."""

        if not isinstance(manifest, dict):
            raise ValueError("manifest must be a JSON object")
        data = self._request_json(
            "POST",
            "/api/v2/plugin-marketplace/sdk/products/private",
            body=json.dumps(
                {"manifest": manifest},
                ensure_ascii=False,
                sort_keys=True,
                separators=(",", ":"),
            ).encode("utf-8"),
            developer_token=developer_token,
        )
        return marketplace_private_product_registration_from_dict(data)

    def upload_private_package(
        self,
        product_public_id: str,
        package_bytes: bytes,
        *,
        package_sha256: str,
        developer_token: str,
    ) -> MarketplacePrivatePackageUpload:
        """Upload a local `.fppkg` artifact through the SDK developer-token API."""

        if not isinstance(product_public_id, str) or not product_public_id.strip():
            raise ValueError("product_public_id is required")
        if not isinstance(package_bytes, bytes) or not package_bytes:
            raise ValueError("package_bytes must be non-empty bytes")
        if not isinstance(package_sha256, str) or not re.fullmatch(r"[a-f0-9]{64}", package_sha256):
            raise ValueError("package_sha256 must be a SHA-256 hex digest")
        data = self._request_json(
            "POST",
            f"/api/v2/plugin-marketplace/sdk/products/{quote(product_public_id.strip(), safe='')}/versions/package",
            body=json.dumps(
                {
                    "package_base64": base64.b64encode(package_bytes).decode("ascii"),
                    "package_sha256": package_sha256,
                },
                ensure_ascii=False,
                sort_keys=True,
                separators=(",", ":"),
            ).encode("utf-8"),
            developer_token=developer_token,
        )
        return marketplace_private_package_upload_from_dict(data)

    def submit_public_review(
        self,
        product_public_id: str,
        *,
        developer_token: str,
        pricing_type: str | None = None,
        price_rub: int = 0,
        access_duration_days: int | None = None,
        trial_days: int = 0,
    ) -> MarketplacePublicReviewSubmission:
        """Submit an uploaded SDK package for public marketplace review."""

        if not isinstance(product_public_id, str) or not product_public_id.strip():
            raise ValueError("product_public_id is required")
        payload = _public_review_payload(
            pricing_type=pricing_type,
            price_rub=price_rub,
            access_duration_days=access_duration_days,
            trial_days=trial_days,
        )
        data = self._request_json(
            "POST",
            f"/api/v2/plugin-marketplace/sdk/products/{quote(product_public_id.strip(), safe='')}/public-review",
            body=json.dumps(
                payload,
                ensure_ascii=False,
                sort_keys=True,
                separators=(",", ":"),
            ).encode("utf-8"),
            developer_token=developer_token,
        )
        return marketplace_public_review_submission_from_dict(data)

    def _request_json(
        self,
        method: str,
        path: str,
        *,
        body: bytes,
        developer_token: str | None = None,
    ) -> dict[str, Any]:
        headers = {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "User-Agent": "funpay-pulse-sdk/0.1",
        }
        if developer_token is not None:
            headers["Authorization"] = _developer_authorization_header(developer_token)
        request = Request(
            urljoin(self.base_url, path),
            data=body,
            method=method,
            headers=headers,
        )
        try:
            with self._opener.open(request, timeout=self.timeout_seconds) as response:
                response_body = _read_limited(
                    response,
                    MAX_MARKETPLACE_RESPONSE_BYTES,
                )
        except HTTPError as exc:
            detail = _decode_error_body(exc)
            raise MarketplaceClientError(
                f"Marketplace API returned HTTP {exc.code}: {detail}"
            ) from exc
        except URLError as exc:
            raise MarketplaceClientError(
                f"Marketplace API request failed: {exc.reason}"
            ) from exc
        except OSError as exc:
            raise MarketplaceClientError(f"Marketplace API request failed: {exc}") from exc

        try:
            data = json.loads(response_body.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise MarketplaceClientError("Marketplace API returned invalid JSON") from exc
        if not isinstance(data, dict):
            raise MarketplaceClientError("Marketplace API response must be a JSON object")
        return data


def marketplace_manifest_validation_from_dict(
    data: dict[str, Any],
) -> MarketplaceManifestValidation:
    """Parse a marketplace manifest validation response."""

    if not isinstance(data, dict):
        raise MarketplaceClientError("manifest validation response must be an object")
    valid = data.get("valid")
    if not isinstance(valid, bool):
        raise MarketplaceClientError("manifest validation response missing valid")
    return MarketplaceManifestValidation(
        valid=valid,
        errors=_string_tuple(data.get("errors"), "errors"),
        warnings=_string_tuple(data.get("warnings"), "warnings"),
        plugin_id=_optional_string(data.get("plugin_id"), "plugin_id"),
        version=_optional_string(data.get("version"), "version"),
        manifest_sha256=_optional_string(data.get("manifest_sha256"), "manifest_sha256"),
        scopes=_string_tuple(data.get("scopes"), "scopes"),
        dangerous_scopes=_string_tuple(data.get("dangerous_scopes"), "dangerous_scopes"),
        dry_run=data.get("dry_run") is True,
        raw=data,
    )


def marketplace_private_product_registration_from_dict(
    data: dict[str, Any],
) -> MarketplacePrivateProductRegistration:
    """Parse an authenticated private product registration response."""
    product = _object_field(data, "product")
    current_version = product.get("current_version")
    if current_version is not None and not isinstance(current_version, dict):
        raise MarketplaceClientError("private product response invalid current_version")
    return MarketplacePrivateProductRegistration(
        product_public_id=_required_string(product.get("public_id"), "product.public_id"),
        plugin_id=_required_string(product.get("plugin_id"), "product.plugin_id"),
        version=_optional_string(
            current_version.get("version") if current_version else None,
            "product.current_version.version",
        ),
        manifest_sha256=_optional_string(
            current_version.get("manifest_sha256") if current_version else None,
            "product.current_version.manifest_sha256",
        ),
        raw=data,
    )


def marketplace_private_package_upload_from_dict(
    data: dict[str, Any],
) -> MarketplacePrivatePackageUpload:
    """Parse an authenticated private package upload response."""
    product = _object_field(data, "product")
    version = data.get("version")
    if version is not None and not isinstance(version, dict):
        raise MarketplaceClientError("private package upload response invalid version")
    broker_token = data.get("broker_token")
    if broker_token is not None:
        raise MarketplaceClientError("private package upload unexpectedly returned broker_token")
    return MarketplacePrivatePackageUpload(
        product_public_id=_required_string(product.get("public_id"), "product.public_id"),
        plugin_id=_required_string(product.get("plugin_id"), "product.plugin_id"),
        version=_optional_string(version.get("version") if version else None, "version.version"),
        package_sha256=_required_string(data.get("package_sha256"), "package_sha256"),
        package_size_bytes=_non_negative_int(data.get("package_size_bytes"), "package_size_bytes"),
        package_file_count=_non_negative_int(data.get("package_file_count"), "package_file_count"),
        broker_token=None,
        raw=data,
    )


def marketplace_public_review_submission_from_dict(
    data: dict[str, Any],
) -> MarketplacePublicReviewSubmission:
    """Parse an authenticated public-review submission response."""

    product = _object_field(data, "product")
    return MarketplacePublicReviewSubmission(
        product_public_id=_required_string(product.get("public_id"), "product.public_id"),
        plugin_id=_required_string(product.get("plugin_id"), "product.plugin_id"),
        pricing_type=_required_string(product.get("pricing_type"), "product.pricing_type"),
        price_rub=_non_negative_int(product.get("price_rub"), "product.price_rub"),
        access_duration_days=_optional_positive_int(
            product.get("access_duration_days"),
            "product.access_duration_days",
        ),
        trial_days=_non_negative_int(product.get("trial_days"), "product.trial_days"),
        submitted=data.get("submitted") is True,
        raw=data,
    )


def _object_field(data: dict[str, Any], field: str) -> dict[str, Any]:
    value = data.get(field)
    if not isinstance(value, dict):
        raise MarketplaceClientError(f"response missing {field}")
    return value


def _required_string(value: Any, field: str) -> str:
    if not isinstance(value, str) or not value:
        raise MarketplaceClientError(f"response missing {field}")
    return value


def _non_negative_int(value: Any, field: str) -> int:
    if not isinstance(value, int) or isinstance(value, bool) or value < 0:
        raise MarketplaceClientError(f"response invalid {field}")
    return value


def _optional_positive_int(value: Any, field: str) -> int | None:
    if value is None:
        return None
    if not isinstance(value, int) or isinstance(value, bool) or value < 1:
        raise MarketplaceClientError(f"response invalid {field}")
    return value


def _public_review_payload(
    *,
    pricing_type: str | None,
    price_rub: int,
    access_duration_days: int | None,
    trial_days: int,
) -> dict[str, Any]:
    if not isinstance(price_rub, int) or isinstance(price_rub, bool) or price_rub < 0:
        raise ValueError("price_rub must be a non-negative integer")
    if access_duration_days is not None and (
        not isinstance(access_duration_days, int)
        or isinstance(access_duration_days, bool)
        or access_duration_days < 1
    ):
        raise ValueError("access_duration_days must be a positive integer")
    if not isinstance(trial_days, int) or isinstance(trial_days, bool) or trial_days < 0:
        raise ValueError("trial_days must be a non-negative integer")

    normalized_type = pricing_type.strip().lower() if isinstance(pricing_type, str) else ""
    if pricing_type is not None and not normalized_type:
        raise ValueError("pricing_type must not be blank")
    if normalized_type and normalized_type not in {"free", "one_time", "subscription", "trial"}:
        raise ValueError("pricing_type must be free, one_time, subscription or trial")

    payload: dict[str, Any] = {
        "price_rub": price_rub,
        "trial_days": trial_days,
    }
    if normalized_type:
        payload["pricing_type"] = normalized_type
    if access_duration_days is not None:
        payload["access_duration_days"] = access_duration_days
    return payload


def _string_tuple(value: Any, field: str) -> tuple[str, ...]:
    if value is None:
        return ()
    if not isinstance(value, list):
        raise MarketplaceClientError(f"manifest validation response invalid {field}")
    items: list[str] = []
    for item in value:
        if not isinstance(item, str):
            raise MarketplaceClientError(f"manifest validation response invalid {field}")
        items.append(item)
    return tuple(items)


def _optional_string(value: Any, field: str) -> str | None:
    if value is None:
        return None
    if not isinstance(value, str):
        raise MarketplaceClientError(f"manifest validation response invalid {field}")
    return value


def _developer_authorization_header(developer_token: str) -> str:
    if not isinstance(developer_token, str):
        raise ValueError("developer_token must be a string")
    normalized = developer_token.strip()
    if normalized != developer_token or not re.fullmatch(r"fppd_[A-Za-z0-9_-]{32,}", normalized):
        raise ValueError("developer_token must be a well-formed fppd_ token")
    return f"Bearer {normalized}"


class _NoRedirectHandler(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def _validate_base_url(base_url: str, *, allow_insecure_localhost: bool) -> None:
    parsed = urlparse(base_url)
    if parsed.username or parsed.password:
        raise ValueError("base_url must not contain userinfo")
    if parsed.query or parsed.fragment:
        raise ValueError("base_url must not contain query or fragment")
    if not parsed.scheme or not parsed.hostname:
        raise ValueError("base_url must be an absolute URL")
    if parsed.scheme == "https":
        return
    if (
        allow_insecure_localhost
        and parsed.scheme == "http"
        and _is_localhost(parsed.hostname)
    ):
        return
    raise ValueError("base_url must use https; http is allowed only for localhost dev mode")


def _is_localhost(host: str) -> bool:
    normalized = host.lower().strip("[]")
    if normalized == "localhost":
        return True
    try:
        return ipaddress.ip_address(normalized).is_loopback
    except ValueError:
        return False


def _read_limited(response: Any, max_bytes: int) -> bytes:
    body = response.read(max_bytes + 1)
    if len(body) > max_bytes:
        raise MarketplaceClientError("Marketplace API response body too large")
    return body


def _decode_error_body(exc: HTTPError) -> str:
    try:
        body = _read_limited(exc, MAX_MARKETPLACE_ERROR_BYTES).decode("utf-8")
    except MarketplaceClientError:
        return "error body too large"
    except Exception:
        return "unreadable error body"
    if not body:
        return "empty error body"
    return _redact_error_detail(body)[:500]


def _redact_error_detail(body: str) -> str:
    redacted = _BEARER_RE.sub("Bearer <redacted>", body)
    redacted = _PULSE_TOKEN_RE.sub("<redacted-pulse-token>", redacted)
    redacted = _SECRET_QUERY_RE.sub(r"\1<redacted>", redacted)
    return _SECRET_ASSIGNMENT_RE.sub(r"\1<redacted>", redacted)
