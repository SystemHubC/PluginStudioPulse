"""High-level app helpers for FunPay Pulse Broker plugins."""

from __future__ import annotations

import asyncio
import inspect
import logging
import time
from dataclasses import dataclass
from typing import Any, Callable, TypeVar

from .events import PluginEvent, TypedPluginEvent, parse_broker_event


EventT = TypeVar("EventT", bound=PluginEvent)
EventHandler = Callable[..., Any]


class PluginAppError(RuntimeError):
    """Raised when the high-level plugin dispatcher cannot safely continue."""


@dataclass(frozen=True)
class PluginContext:
    """Per-poll context passed to handlers that accept a second argument."""

    client: Any
    config: dict[str, Any]
    config_revision: int


class PluginApp:
    """Small dispatcher for Broker polling plugins.

    Handlers are acknowledged only after all matching handlers complete. If a
    handler raises, the delivery is left unacked so the Broker can redeliver it
    after the visibility timeout.
    """

    def __init__(
        self,
        client: Any,
        *,
        logger: logging.Logger | None = None,
    ):
        self.client = client
        self.logger = logger or logging.getLogger("funpay_pulse_sdk.plugin")
        self._handlers: list[tuple[type[PluginEvent], EventHandler]] = []

    def on(self, event_class: type[EventT]) -> Callable[[EventHandler], EventHandler]:
        """Register a handler for a typed event class.

        The handler may accept either one argument (`event`) or two arguments
        (`event, context`).
        """

        if not isinstance(event_class, type) or not issubclass(event_class, PluginEvent):
            raise ValueError("event_class must be a PluginEvent subclass")

        def decorator(handler: EventHandler) -> EventHandler:
            if not callable(handler):
                raise ValueError("handler must be callable")
            self._handlers.append((event_class, handler))
            return handler

        return decorator

    def process_once(
        self,
        *,
        limit: int = 50,
        write_log_actions: bool = False,
        ack: bool = True,
    ) -> int:
        """Poll one batch, dispatch handlers, and ack successfully processed events."""

        _reject_async_handlers(self._handlers)
        context = self._build_context()
        if context.config.get("enabled") is False:
            self.logger.info("plugin disabled by config revision=%s", context.config_revision)
            return 0

        processed = 0
        for raw_event in self.client.poll_events(limit=limit):
            typed_event = parse_broker_event(raw_event)
            matched_handlers = self._matching_handlers(typed_event)
            if not matched_handlers:
                self.logger.debug(
                    "no handler for event_type=%s delivery=%s",
                    typed_event.event_type,
                    typed_event.delivery_id,
                )
            for handler in matched_handlers:
                _call_handler(handler, typed_event, context)
            if write_log_actions:
                self.client.write_log(
                    "processed broker event",
                    level="info",
                    context={
                        "delivery_id": typed_event.delivery_id,
                        "event_type": typed_event.event_type,
                    },
                    idempotency_key=f"log-{typed_event.delivery_id}",
                )
            if ack:
                self.client.ack_event(typed_event.delivery_id)
            processed += 1
        return processed

    async def process_once_async(
        self,
        *,
        limit: int = 50,
        write_log_actions: bool = False,
        ack: bool = True,
    ) -> int:
        """Async variant of process_once for async handlers."""

        context = self._build_context()
        if context.config.get("enabled") is False:
            self.logger.info("plugin disabled by config revision=%s", context.config_revision)
            return 0

        processed = 0
        for raw_event in self.client.poll_events(limit=limit):
            typed_event = parse_broker_event(raw_event)
            matched_handlers = self._matching_handlers(typed_event)
            if not matched_handlers:
                self.logger.debug(
                    "no handler for event_type=%s delivery=%s",
                    typed_event.event_type,
                    typed_event.delivery_id,
                )
            for handler in matched_handlers:
                await _call_handler_async(handler, typed_event, context)
            if write_log_actions:
                self.client.write_log(
                    "processed broker event",
                    level="info",
                    context={
                        "delivery_id": typed_event.delivery_id,
                        "event_type": typed_event.event_type,
                    },
                    idempotency_key=f"log-{typed_event.delivery_id}",
                )
            if ack:
                self.client.ack_event(typed_event.delivery_id)
            processed += 1
        return processed

    def run_forever(
        self,
        *,
        limit: int = 50,
        poll_interval_seconds: float = 3.0,
        write_log_actions: bool = False,
        stop_after_empty_polls: int | None = None,
    ) -> int:
        """Keep polling until interrupted or until the optional empty-poll limit."""

        interval = float(poll_interval_seconds)
        if interval < 0:
            raise ValueError("poll_interval_seconds must be non-negative")
        if stop_after_empty_polls is not None and stop_after_empty_polls < 1:
            raise ValueError("stop_after_empty_polls must be positive")

        total_processed = 0
        empty_polls = 0
        while True:
            processed = self.process_once(
                limit=limit,
                write_log_actions=write_log_actions,
            )
            total_processed += processed
            if processed == 0:
                empty_polls += 1
                if (
                    stop_after_empty_polls is not None
                    and empty_polls >= stop_after_empty_polls
                ):
                    return total_processed
            else:
                empty_polls = 0
            if interval:
                time.sleep(interval)

    async def run_forever_async(
        self,
        *,
        limit: int = 50,
        poll_interval_seconds: float = 3.0,
        write_log_actions: bool = False,
        stop_after_empty_polls: int | None = None,
    ) -> int:
        """Async polling loop for async handlers."""

        interval = float(poll_interval_seconds)
        if interval < 0:
            raise ValueError("poll_interval_seconds must be non-negative")
        if stop_after_empty_polls is not None and stop_after_empty_polls < 1:
            raise ValueError("stop_after_empty_polls must be positive")

        total_processed = 0
        empty_polls = 0
        while True:
            processed = await self.process_once_async(
                limit=limit,
                write_log_actions=write_log_actions,
            )
            total_processed += processed
            if processed == 0:
                empty_polls += 1
                if (
                    stop_after_empty_polls is not None
                    and empty_polls >= stop_after_empty_polls
                ):
                    return total_processed
            else:
                empty_polls = 0
            if interval:
                await asyncio.sleep(interval)

    def _build_context(self) -> PluginContext:
        config = self.client.get_config()
        return PluginContext(
            client=self.client,
            config=dict(config.config),
            config_revision=config.config_revision,
        )

    def _matching_handlers(self, event: TypedPluginEvent) -> list[EventHandler]:
        return [
            handler
            for event_class, handler in self._handlers
            if isinstance(event, event_class)
        ]


def _call_handler(
    handler: EventHandler,
    event: TypedPluginEvent,
    context: PluginContext,
) -> None:
    if _handler_accepts_context(handler):
        result = handler(event, context)
    else:
        result = handler(event)
    if inspect.isawaitable(result):
        _close_awaitable(result)
        raise PluginAppError(
            "async handlers require process_once_async() or run_forever_async()"
        )


async def _call_handler_async(
    handler: EventHandler,
    event: TypedPluginEvent,
    context: PluginContext,
) -> None:
    if _handler_accepts_context(handler):
        result = handler(event, context)
    else:
        result = handler(event)
    if inspect.isawaitable(result):
        await result


def _handler_accepts_context(handler: EventHandler) -> bool:
    try:
        signature = inspect.signature(handler)
    except (TypeError, ValueError):
        return True

    positional_count = 0
    for parameter in signature.parameters.values():
        if parameter.kind == inspect.Parameter.VAR_POSITIONAL:
            return True
        if parameter.kind in {
            inspect.Parameter.POSITIONAL_ONLY,
            inspect.Parameter.POSITIONAL_OR_KEYWORD,
        }:
            positional_count += 1
    return positional_count >= 2


def _reject_async_handlers(
    handlers: list[tuple[type[PluginEvent], EventHandler]],
) -> None:
    if any(inspect.iscoroutinefunction(handler) for _event_class, handler in handlers):
        raise PluginAppError(
            "async handlers require process_once_async() or run_forever_async()"
        )


def _close_awaitable(value: Any) -> None:
    close = getattr(value, "close", None)
    if callable(close):
        close()
