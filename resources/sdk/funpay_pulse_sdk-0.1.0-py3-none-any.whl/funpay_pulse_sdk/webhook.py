"""Webhook signature helpers for FunPay Pulse SDK v1."""

from __future__ import annotations

import hmac
import time
from hashlib import sha256
from typing import Mapping

SIGNATURE_HEADER = "X-FPP-Signature"
TIMESTAMP_HEADER = "X-FPP-Timestamp"
NONCE_HEADER = "X-FPP-Nonce"
DEFAULT_TOLERANCE_SECONDS = 300


class WebhookSignatureError(ValueError):
    """Raised when a webhook signature cannot be trusted."""


def sign_webhook_body(secret: str | bytes, timestamp: str | int, nonce: str, body: bytes) -> str:
    """Return hex HMAC-SHA256 over `timestamp.nonce.raw_body`."""

    secret_bytes = secret.encode("utf-8") if isinstance(secret, str) else secret
    signed_payload = b".".join([str(timestamp).encode("ascii"), nonce.encode("utf-8"), body])
    return hmac.new(secret_bytes, signed_payload, sha256).hexdigest()


def verify_webhook_signature(
    *,
    secret: str | bytes,
    body: bytes,
    headers: Mapping[str, str],
    tolerance_seconds: int = DEFAULT_TOLERANCE_SECONDS,
    now: int | None = None,
) -> bool:
    """Verify webhook HMAC signature and timestamp freshness.

    Header names are matched case-insensitively. Nonce replay storage belongs to
    the consuming app; this helper validates the cryptographic envelope.
    """

    normalized_headers = {key.lower(): value for key, value in headers.items()}
    signature = normalized_headers.get(SIGNATURE_HEADER.lower())
    timestamp = normalized_headers.get(TIMESTAMP_HEADER.lower())
    nonce = normalized_headers.get(NONCE_HEADER.lower())

    if not signature:
        raise WebhookSignatureError("missing X-FPP-Signature")
    if not timestamp:
        raise WebhookSignatureError("missing X-FPP-Timestamp")
    if not nonce:
        raise WebhookSignatureError("missing X-FPP-Nonce")

    try:
        timestamp_int = int(timestamp)
    except ValueError as exc:
        raise WebhookSignatureError("X-FPP-Timestamp must be an integer unix timestamp") from exc

    now_int = int(time.time()) if now is None else int(now)
    if abs(now_int - timestamp_int) > tolerance_seconds:
        raise WebhookSignatureError("webhook timestamp is outside tolerance")

    expected = sign_webhook_body(secret, timestamp, nonce, body)
    if not hmac.compare_digest(expected, signature):
        raise WebhookSignatureError("invalid webhook signature")

    return True
