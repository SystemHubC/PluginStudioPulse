"""Polling client for the FunPay Pulse Plugin Broker API."""

from __future__ import annotations

import ipaddress
import hashlib
import json
import math
import re
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.parse import quote, urlencode, urljoin, urlparse
from urllib.request import HTTPRedirectHandler, Request, build_opener


DEFAULT_TIMEOUT_SECONDS = 10
MAX_RESPONSE_BYTES = 2 * 1024 * 1024
MAX_ERROR_BYTES = 16 * 1024
MAX_PACKAGE_DOWNLOAD_BYTES = 5 * 1024 * 1024
PACKAGE_MEDIA_TYPE = "application/vnd.funpay-pulse.plugin-package+zip"
IDEMPOTENCY_KEY_RE = re.compile(r"^[A-Za-z0-9._:-]{8,128}$")
SHA256_RE = re.compile(r"^[a-f0-9]{64}$")
BROKER_TOKEN_RE = re.compile(r"fppb_[A-Za-z0-9_-]+")
PLUGIN_INVITE_TOKEN_RE = re.compile(r"fppi_[A-Za-z0-9_-]+")
CONNECTION_TOKEN_RE = re.compile(r"\bfp_[A-Fa-f0-9]{32}\b")
WEBHOOK_SECRET_RE = re.compile(r"^fppwh_[a-f0-9]{64}$")
SECRET_VALUE_PATTERNS = (
    re.compile(r"\bBearer\s+[A-Za-z0-9._~+/=-]{12,}", re.I),
    re.compile(r"\bsk_(?:live|test)_[A-Za-z0-9_-]{8,}", re.I),
    re.compile(r"\bghp_[A-Za-z0-9_]{20,}", re.I),
    re.compile(r"\b[A-Za-z0-9_-]{32,}\.[A-Za-z0-9_-]{16,}\.[A-Za-z0-9_-]{16,}\b"),
)
MAX_LOT_PRICE_VALUE = Decimal("10000000")
SUPPORTED_ACTION_TYPES = frozenset(
    {
        "logs.write",
        "orders.get",
        "orders.list",
        "orders.refund",
        "orders.review.reply",
        "lots.get",
        "lots.list",
        "messages.send",
        "lots.active.set",
        "lots.price.set",
        "lots.raise",
        "blacklist.add",
        "blacklist.remove",
    }
)
INTERNAL_SECRET_KEY_MARKERS = (
    "broker_token",
    "connection_token",
    "csrf",
    "fppb",
    "fppi",
    "funpay",
    "golden_key",
    "session_cookie",
    "signing_secret",
)
ORDER_ID_RE = re.compile(r"^[A-Za-z0-9]{3,64}$")
SENSITIVE_IDEMPOTENCY_KEY_MARKERS = (
    "authorization",
    "api_key",
    "connection_token",
    "cookie",
    "database",
    "db_path",
    "golden_key",
    "password",
    "secret",
    "signing_secret",
    "token",
)


class BrokerClientError(RuntimeError):
    """Raised when the Broker API request or response cannot be trusted."""


@dataclass(frozen=True)
class BrokerEvent:
    """Read-only event delivery returned by the Broker polling API."""

    delivery_id: str
    event_id: str
    event_type: str
    payload: dict[str, Any]
    created_at: str
    delivered_at: str | None = None


@dataclass(frozen=True)
class BrokerAction:
    """Action queue item accepted by the Broker actions API."""

    action_id: str
    action_type: str
    status: str
    created: bool
    created_at: str
    idempotency_key_hash: str = ""
    idempotency_key: str | None = None


@dataclass(frozen=True)
class BrokerOrderReview:
    """Safe review subset returned inside an order action result."""

    stars: int | float | None = None
    text: str | None = None
    hidden: bool | None = None
    has_reply: bool | None = None


@dataclass(frozen=True)
class BrokerOrderSummary:
    """Safe order summary returned by `orders.get` and `orders.list`."""

    account_id: str | None = None
    order_id: str | None = None
    status: str | None = None
    buyer_id: str | None = None
    buyer_username: str | None = None
    chat_id: str | None = None
    lot_id: str | None = None
    title: str | None = None
    category: str | None = None
    subcategory_id: str | None = None
    occurred_at: str | None = None
    subcategory_type: str | None = None
    price: int | float | None = None
    quantity: int | float | None = None
    has_review: bool | None = None
    review_hidden: bool | None = None
    review_stars: int | float | None = None
    review_text: str | None = None
    review: BrokerOrderReview | None = None


@dataclass(frozen=True)
class BrokerLotSummary:
    """Safe lot summary returned by `lots.get` and `lots.list`."""

    account_id: str | None = None
    lot_id: str | None = None
    title: str | None = None
    price: int | float | None = None
    currency: str | None = None
    active: bool | None = None
    auto_delivery: bool | None = None
    amount: int | float | None = None
    subcategory_id: str | None = None
    subcategory_name: str | None = None
    game_id: str | None = None
    category_name: str | None = None
    lot_type: str | None = None
    last_raised: str | None = None
    next_raise_available: str | None = None


@dataclass(frozen=True)
class BrokerOrdersPage:
    """Paginated safe order list returned by `orders.list`."""

    items: tuple[BrokerOrderSummary, ...]
    count: int
    has_more: bool
    next_cursor: str | None


@dataclass(frozen=True)
class BrokerOrderRefundResult:
    """Safe result returned by a trusted `orders.refund` action."""

    order_id: str
    refunded: bool
    status: str | None = None
    already_refunded: bool | None = None


@dataclass(frozen=True)
class BrokerOrderReviewReplyResult:
    """Safe result returned by a trusted `orders.review.reply` action."""

    order_id: str
    replied: bool
    rating: int | float | None = None
    already_replied: bool | None = None


@dataclass(frozen=True)
class BrokerMessageSendResult:
    """Safe result returned by a trusted `messages.send` action."""

    message_id: str | None = None


@dataclass(frozen=True)
class BrokerLotActiveSetResult:
    """Safe result returned by a trusted `lots.active.set` action."""

    lot_id: str
    active: bool
    previous_active: bool | None = None
    already_set: bool | None = None


@dataclass(frozen=True)
class BrokerLotPriceSetResult:
    """Safe result returned by a trusted `lots.price.set` action."""

    lot_id: str
    price: int | float
    previous_price: int | float | None = None
    already_set: bool | None = None


@dataclass(frozen=True)
class BrokerLotsRaiseResult:
    """Safe result returned by a trusted `lots.raise` action."""

    lot_id: str
    subcategory_id: str | None = None
    raised: bool = False
    wait_time_seconds: int | float | None = None
    next_raise_available: str | None = None
    already_on_cooldown: bool | None = None


@dataclass(frozen=True)
class BrokerBlacklistAddResult:
    """Safe result returned by a trusted `blacklist.add` action."""

    account_id: str
    username: str
    buyer_id: str | None = None
    added: bool = False
    already_present: bool | None = None
    expires_at: str | None = None


@dataclass(frozen=True)
class BrokerBlacklistRemoveResult:
    """Safe result returned by a trusted `blacklist.remove` action."""

    account_id: str
    username: str
    buyer_id: str | None = None
    removed: bool = False
    already_absent: bool | None = None
    removed_count: int | float | None = None


@dataclass(frozen=True)
class BrokerLotsPage:
    """Paginated safe lot list returned by `lots.list`."""

    items: tuple[BrokerLotSummary, ...]
    count: int
    has_more: bool
    next_cursor: str | None


@dataclass(frozen=True)
class BrokerActionStatus:
    """Safe status/result view for a previously submitted Broker action."""

    action_id: str
    action_type: str
    status: str
    attempt_count: int
    created_at: str
    updated_at: str
    result: dict[str, Any]
    idempotency_key_hash: str = ""
    idempotency_key: str | None = None
    claimed_at: str | None = None
    lease_until: str | None = None
    completed_at: str | None = None
    error_code: str | None = None
    error_message: str | None = None

    def require_succeeded(self) -> "BrokerActionStatus":
        """Return self only for terminal successful actions."""

        if self.status != "succeeded":
            raise BrokerClientError(
                f"Broker action {self.action_id} is not succeeded: {self.status}"
            )
        return self

    def order_result(self) -> BrokerOrderSummary:
        """Parse a succeeded `orders.get` result."""

        self._require_action_type("orders.get")
        self.require_succeeded()
        return broker_order_summary_from_dict(self.result)

    def orders_page_result(self) -> BrokerOrdersPage:
        """Parse a succeeded `orders.list` result."""

        self._require_action_type("orders.list")
        self.require_succeeded()
        return broker_orders_page_from_dict(self.result)

    def order_refund_result(self) -> BrokerOrderRefundResult:
        """Parse a succeeded `orders.refund` result."""

        self._require_action_type("orders.refund")
        self.require_succeeded()
        return broker_order_refund_result_from_dict(self.result)

    def order_review_reply_result(self) -> BrokerOrderReviewReplyResult:
        """Parse a succeeded `orders.review.reply` result."""

        self._require_action_type("orders.review.reply")
        self.require_succeeded()
        return broker_order_review_reply_result_from_dict(self.result)

    def message_send_result(self) -> BrokerMessageSendResult:
        """Parse a succeeded `messages.send` result."""

        self._require_action_type("messages.send")
        self.require_succeeded()
        return broker_message_send_result_from_dict(self.result)

    def lot_result(self) -> BrokerLotSummary:
        """Parse a succeeded `lots.get` result."""

        self._require_action_type("lots.get")
        self.require_succeeded()
        return broker_lot_summary_from_dict(self.result)

    def lots_page_result(self) -> BrokerLotsPage:
        """Parse a succeeded `lots.list` result."""

        self._require_action_type("lots.list")
        self.require_succeeded()
        return broker_lots_page_from_dict(self.result)

    def lot_active_result(self) -> BrokerLotActiveSetResult:
        """Parse a succeeded `lots.active.set` result."""

        self._require_action_type("lots.active.set")
        self.require_succeeded()
        return broker_lot_active_set_result_from_dict(self.result)

    def lot_price_result(self) -> BrokerLotPriceSetResult:
        """Parse a succeeded `lots.price.set` result."""

        self._require_action_type("lots.price.set")
        self.require_succeeded()
        return broker_lot_price_set_result_from_dict(self.result)

    def lots_raise_result(self) -> BrokerLotsRaiseResult:
        """Parse a succeeded `lots.raise` result."""

        self._require_action_type("lots.raise")
        self.require_succeeded()
        return broker_lots_raise_result_from_dict(self.result)

    def blacklist_add_result(self) -> BrokerBlacklistAddResult:
        """Parse a succeeded `blacklist.add` result."""

        self._require_action_type("blacklist.add")
        self.require_succeeded()
        return broker_blacklist_add_result_from_dict(self.result)

    def blacklist_remove_result(self) -> BrokerBlacklistRemoveResult:
        """Parse a succeeded `blacklist.remove` result."""

        self._require_action_type("blacklist.remove")
        self.require_succeeded()
        return broker_blacklist_remove_result_from_dict(self.result)

    def _require_action_type(self, expected: str) -> None:
        if self.action_type != expected:
            raise BrokerClientError(
                f"Broker action {self.action_id} is {self.action_type}, not {expected}"
            )


@dataclass(frozen=True)
class BrokerConfig:
    """Installation config returned by the Broker config API."""

    config: dict[str, Any]
    config_revision: int


@dataclass(frozen=True)
class BrokerWebhookSecret:
    """Webhook HMAC secret returned by the Broker webhook-secret API."""

    webhook_secret: str
    installation_id: str
    signature_header: str
    timestamp_header: str
    nonce_header: str


@dataclass(frozen=True)
class BrokerPackageManifest:
    """Installed package metadata returned by the Broker package manifest API."""

    installation_id: str
    product_public_id: str
    plugin_id: str
    plugin_name: str
    version: str
    runtime_type: str
    manifest_sha256: str
    manifest: dict[str, Any]
    scopes: tuple[str, ...]
    config_revision: int
    install_revision: int
    package_sha256: str
    package_size_bytes: int
    package_file_count: int
    package_metadata: dict[str, Any]


@dataclass(frozen=True)
class BrokerDownloadedPackage:
    """Integrity-checked `.fppkg` bytes returned by the Broker download API."""

    package_bytes: bytes
    package_sha256: str
    package_size_bytes: int
    plugin_id: str | None = None
    plugin_version: str | None = None


@dataclass(frozen=True)
class BrokerStorageItem:
    """Plugin-owned storage item returned by the Broker storage API."""

    key: str
    value: Any
    created: bool
    updated_at: str


@dataclass(frozen=True)
class BrokerStorageLimits:
    """Storage limits advertised by the Broker capabilities API."""

    max_items: int
    max_key_length: int
    max_value_bytes: int
    max_total_bytes: int


@dataclass(frozen=True)
class BrokerSecretLimits:
    """Secret storage limits advertised by the Broker capabilities API."""

    max_items: int
    max_key_length: int
    max_value_bytes: int
    max_total_bytes: int


@dataclass(frozen=True)
class BrokerCapabilities:
    """Runtime capabilities for the authenticated Broker installation."""

    broker_events_enabled: bool
    broker_actions_enabled: bool
    broker_storage_enabled: bool
    broker_secrets_enabled: bool
    broker_package_download_enabled: bool
    scopes: tuple[str, ...]
    supported_actions: tuple[str, ...]
    storage_authorized: bool
    storage_limits: BrokerStorageLimits
    secret_storage_authorized: bool
    secret_storage_limits: BrokerSecretLimits
    config_revision: int


@dataclass(frozen=True)
class BrokerSecretItem:
    """Plugin-owned secret item returned by the Broker secrets API."""

    key: str
    value: str | None
    value_size_bytes: int
    created: bool
    updated_at: str


class BrokerClient:
    """Small dependency-free client for plugin-side event polling and ack."""

    def __init__(
        self,
        *,
        base_url: str,
        broker_token: str,
        timeout_seconds: int = DEFAULT_TIMEOUT_SECONDS,
        allow_insecure_localhost: bool = False,
        opener: Any | None = None,
    ):
        if not isinstance(base_url, str) or not base_url.strip():
            raise ValueError("base_url is required")
        _validate_base_url(base_url, allow_insecure_localhost=allow_insecure_localhost)
        if not isinstance(broker_token, str) or BROKER_TOKEN_RE.fullmatch(broker_token) is None:
            raise ValueError("broker_token must be a well-formed fppb_ token")
        if int(timeout_seconds) <= 0:
            raise ValueError("timeout_seconds must be positive")

        self.base_url = base_url.rstrip("/") + "/"
        self.broker_token = broker_token
        self.timeout_seconds = int(timeout_seconds)
        self._opener = opener or build_opener(_NoRedirectHandler)

    def poll_events(self, limit: int = 50) -> list[BrokerEvent]:
        """Return current non-acked Broker event deliveries."""

        limit = _bounded_limit(limit)
        response = self._request_json(
            "GET",
            f"api/v2/broker/events?{urlencode({'limit': limit})}",
        )
        items = response.get("items")
        if not isinstance(items, list):
            raise BrokerClientError("Broker poll response missing items list")
        return [_parse_event(item) for item in items]

    def ack_event(self, delivery_id: str) -> dict[str, Any]:
        """Acknowledge a delivered Broker event."""

        if not isinstance(delivery_id, str) or not delivery_id.strip():
            raise ValueError("delivery_id is required")
        response = self._request_json(
            "POST",
            f"api/v2/broker/events/{quote(delivery_id.strip(), safe='')}/ack",
        )
        if response.get("success") is not True:
            raise BrokerClientError("Broker ack response was not successful")
        return response

    def get_config(self) -> BrokerConfig:
        """Return config for this Broker token's installation."""

        response = self._request_json("GET", "api/v2/broker/config")
        return _parse_config(response)

    def get_webhook_secret(self) -> BrokerWebhookSecret:
        """Return the HMAC secret for verifying pushed webhook deliveries."""

        response = self._request_json("GET", "api/v2/broker/webhook/secret")
        return _parse_webhook_secret(response)

    def get_capabilities(self) -> BrokerCapabilities:
        """Return runtime capabilities for this Broker token's installation."""

        response = self._request_json("GET", "api/v2/broker/capabilities")
        return _parse_capabilities(response)

    def get_package_manifest(self) -> BrokerPackageManifest:
        """Return installed package metadata for this Broker token's installation."""

        response = self._request_json("GET", "api/v2/broker/package/manifest")
        return _parse_package_manifest(response)

    def download_package(
        self,
        *,
        expected_sha256: str | None = None,
    ) -> BrokerDownloadedPackage:
        """Download the installed `.fppkg` and verify Broker integrity headers."""

        normalized_expected_sha256 = _optional_sha256(
            expected_sha256,
            field_name="expected_sha256",
        )
        package_bytes, headers = self._request_bytes(
            "GET",
            "api/v2/broker/package/download",
            max_bytes=MAX_PACKAGE_DOWNLOAD_BYTES,
            extra_headers={"Accept": PACKAGE_MEDIA_TYPE},
        )
        header_sha256 = _required_header_sha256(headers, "X-Package-SHA256")
        if (
            normalized_expected_sha256 is not None
            and header_sha256 != normalized_expected_sha256
        ):
            raise BrokerClientError("Broker package sha256 mismatch")

        header_size = _required_header_non_negative_int(headers, "X-Package-Size-Bytes")
        if len(package_bytes) != header_size:
            raise BrokerClientError("Broker package size mismatch")

        actual_sha256 = hashlib.sha256(package_bytes).hexdigest()
        if actual_sha256 != header_sha256:
            raise BrokerClientError("Broker package sha256 mismatch")

        return BrokerDownloadedPackage(
            package_bytes=package_bytes,
            package_sha256=header_sha256,
            package_size_bytes=header_size,
            plugin_id=_optional_header(headers, "X-Plugin-ID"),
            plugin_version=_optional_header(headers, "X-Plugin-Version"),
        )

    def get_storage_item(self, key: str) -> BrokerStorageItem:
        """Return one plugin-owned storage item."""

        storage_key = quote(_validate_storage_key(key), safe="")
        response = self._request_json("GET", f"api/v2/broker/storage/{storage_key}")
        return _parse_storage_item(response)

    def set_storage_item(self, key: str, value: Any) -> BrokerStorageItem:
        """Create or replace one plugin-owned non-secret JSON storage item."""

        storage_key = quote(_validate_storage_key(key), safe="")
        body = json.dumps(
            {"value": value},
            sort_keys=True,
            separators=(",", ":"),
            ensure_ascii=False,
        ).encode("utf-8")
        response = self._request_json(
            "PUT",
            f"api/v2/broker/storage/{storage_key}",
            body=body,
            extra_headers={"Content-Type": "application/json"},
        )
        return _parse_storage_item(response)

    def delete_storage_item(self, key: str) -> bool:
        """Delete one plugin-owned storage item."""

        storage_key = quote(_validate_storage_key(key), safe="")
        response = self._request_json("DELETE", f"api/v2/broker/storage/{storage_key}")
        deleted = response.get("deleted")
        if not isinstance(deleted, bool):
            raise BrokerClientError("Broker storage delete response missing deleted flag")
        return deleted

    def get_secret_item(self, key: str) -> BrokerSecretItem:
        """Return one plugin-owned secret value."""

        secret_key = quote(_validate_secret_key(key), safe="")
        response = self._request_json("GET", f"api/v2/broker/secrets/{secret_key}")
        return _parse_secret_item(response, expect_value=True)

    def set_secret_item(self, key: str, value: str) -> BrokerSecretItem:
        """Create or replace one plugin-owned encrypted secret."""

        secret_key = quote(_validate_secret_key(key), safe="")
        secret_value = _validate_secret_value(key, value)
        body = json.dumps(
            {"value": secret_value},
            sort_keys=True,
            separators=(",", ":"),
            ensure_ascii=False,
        ).encode("utf-8")
        response = self._request_json(
            "PUT",
            f"api/v2/broker/secrets/{secret_key}",
            body=body,
            extra_headers={"Content-Type": "application/json"},
        )
        return _parse_secret_item(response, expect_value=False)

    def delete_secret_item(self, key: str) -> bool:
        """Delete one plugin-owned secret item."""

        secret_key = quote(_validate_secret_key(key), safe="")
        response = self._request_json("DELETE", f"api/v2/broker/secrets/{secret_key}")
        deleted = response.get("deleted")
        if not isinstance(deleted, bool):
            raise BrokerClientError("Broker secret delete response missing deleted flag")
        return deleted

    def submit_action(
        self,
        action_type: str,
        action_input: dict[str, Any],
        *,
        idempotency_key: str,
    ) -> BrokerAction:
        """Submit an allowlisted action to the Broker actions API."""

        if not isinstance(action_type, str) or not action_type.strip():
            raise ValueError("action_type is required")
        normalized_type = action_type.strip()
        if normalized_type not in SUPPORTED_ACTION_TYPES:
            raise BrokerClientError(f"unsupported action_type: {normalized_type}")
        if not isinstance(action_input, dict):
            raise ValueError("action_input must be a JSON object")
        if normalized_type == "logs.write":
            action_input = _normalize_logs_write_input(action_input)
        elif normalized_type == "orders.get":
            action_input = _normalize_orders_get_input(action_input)
        elif normalized_type == "orders.list":
            action_input = _normalize_orders_list_input(action_input)
        elif normalized_type == "orders.refund":
            action_input = _normalize_orders_refund_input(action_input)
        elif normalized_type == "orders.review.reply":
            action_input = _normalize_orders_review_reply_input(action_input)
        elif normalized_type == "lots.get":
            action_input = _normalize_lots_get_input(action_input)
        elif normalized_type == "lots.list":
            action_input = _normalize_lots_list_input(action_input)
        elif normalized_type == "messages.send":
            action_input = _normalize_messages_send_input(action_input)
        elif normalized_type == "lots.active.set":
            action_input = _normalize_lots_active_set_input(action_input)
        elif normalized_type == "lots.price.set":
            action_input = _normalize_lots_price_set_input(action_input)
        elif normalized_type == "lots.raise":
            action_input = _normalize_lots_raise_input(action_input)
        elif normalized_type == "blacklist.add":
            action_input = _normalize_blacklist_add_input(action_input)
        elif normalized_type == "blacklist.remove":
            action_input = _normalize_blacklist_remove_input(action_input)
        normalized_key = _validate_idempotency_key(idempotency_key)
        body = json.dumps(
            {"type": normalized_type, "input": action_input},
            sort_keys=True,
            separators=(",", ":"),
            ensure_ascii=False,
        ).encode("utf-8")
        response = self._request_json(
            "POST",
            "api/v2/broker/actions",
            body=body,
            extra_headers={
                "Content-Type": "application/json",
                "Idempotency-Key": normalized_key,
            },
        )
        return _parse_action(response)

    def write_log(
        self,
        message: str,
        *,
        level: str = "info",
        context: dict[str, Any] | None = None,
        idempotency_key: str,
    ) -> BrokerAction:
        """Convenience wrapper for the safe `logs.write` action."""

        if not isinstance(message, str) or not message.strip():
            raise ValueError("message is required")
        if not isinstance(level, str) or not level.strip():
            raise ValueError("level is required")
        if context is not None and not isinstance(context, dict):
            raise ValueError("context must be a JSON object")
        payload: dict[str, Any] = _normalize_logs_write_input(
            {
                "message": message,
                "level": level,
                "context": context or {},
            }
        )
        return self.submit_action(
            "logs.write",
            payload,
            idempotency_key=idempotency_key,
        )

    def get_order(
        self,
        *,
        account_id: str | int,
        order_id: str,
        delivery_id: str,
        idempotency_key: str,
    ) -> BrokerAction:
        """Queue a delivery-bound read-only `orders.get` query action."""

        payload = _normalize_orders_get_input(
            {
                "account_id": account_id,
                "order_id": order_id,
                "delivery_id": delivery_id,
            }
        )
        return self.submit_action(
            "orders.get",
            payload,
            idempotency_key=idempotency_key,
        )

    def list_orders(
        self,
        *,
        account_id: str | int,
        delivery_id: str,
        status: str = "paid",
        limit: int = 25,
        cursor: str | int | None = None,
        idempotency_key: str,
    ) -> BrokerAction:
        """Queue a read-only `orders.list` query for cached account orders."""

        payload = _normalize_orders_list_input(
            {
                "account_id": account_id,
                "delivery_id": delivery_id,
                "status": status,
                "limit": limit,
                "cursor": cursor,
            }
        )
        return self.submit_action(
            "orders.list",
            payload,
            idempotency_key=idempotency_key,
        )

    def refund_order(
        self,
        *,
        account_id: str | int,
        order_id: str,
        delivery_id: str,
        idempotency_key: str,
    ) -> BrokerAction:
        """Queue a trusted delivery-bound `orders.refund` action when supported."""

        payload = _normalize_orders_refund_input(
            {
                "account_id": account_id,
                "order_id": order_id,
                "delivery_id": delivery_id,
            }
        )
        return self.submit_action(
            "orders.refund",
            payload,
            idempotency_key=idempotency_key,
        )

    def reply_to_review(
        self,
        *,
        account_id: str | int,
        order_id: str,
        delivery_id: str,
        text: str,
        idempotency_key: str,
    ) -> BrokerAction:
        """Queue a trusted delivery-bound `orders.review.reply` action when supported.

        The SDK never accepts a rating here. FunPay Pulse injects the immutable
        rating from the bound `events:new_review` delivery before the Worker sees
        the action.
        """

        payload = _normalize_orders_review_reply_input(
            {
                "account_id": account_id,
                "order_id": order_id,
                "delivery_id": delivery_id,
                "text": text,
            }
        )
        return self.submit_action(
            "orders.review.reply",
            payload,
            idempotency_key=idempotency_key,
        )

    def get_lot(
        self,
        *,
        account_id: str | int,
        lot_id: str | int,
        delivery_id: str,
        idempotency_key: str,
    ) -> BrokerAction:
        """Queue a delivery-bound read-only `lots.get` query action."""

        payload = _normalize_lots_get_input(
            {
                "account_id": account_id,
                "lot_id": lot_id,
                "delivery_id": delivery_id,
            }
        )
        return self.submit_action(
            "lots.get",
            payload,
            idempotency_key=idempotency_key,
        )

    def list_lots(
        self,
        *,
        account_id: str | int,
        delivery_id: str,
        limit: int = 50,
        cursor: str | int | None = None,
        idempotency_key: str,
    ) -> BrokerAction:
        """Queue a read-only `lots.list` query for cached account lots."""

        payload = _normalize_lots_list_input(
            {
                "account_id": account_id,
                "delivery_id": delivery_id,
                "limit": limit,
                "cursor": cursor,
            }
        )
        return self.submit_action(
            "lots.list",
            payload,
            idempotency_key=idempotency_key,
        )

    def send_message(
        self,
        *,
        account_id: str | int,
        chat_id: str | int,
        delivery_id: str,
        text: str,
        idempotency_key: str,
    ) -> BrokerAction:
        """Queue a `messages.send` action when the installation supports it."""

        payload = _normalize_messages_send_input(
            {
                "account_id": account_id,
                "chat_id": chat_id,
                "delivery_id": delivery_id,
                "text": text,
            }
        )
        return self.submit_action(
            "messages.send",
            payload,
            idempotency_key=idempotency_key,
        )

    def get_action(self, action_id: str) -> BrokerActionStatus:
        """Return safe status/result fields for a submitted Broker action."""

        normalized_action_id = _required_display_string(
            action_id,
            "action_id",
            max_length=128,
        )
        response = self._request_json(
            "GET",
            f"api/v2/broker/actions/{quote(normalized_action_id, safe='')}",
        )
        return _parse_action_status(response)

    def set_lot_active(
        self,
        *,
        account_id: str | int,
        lot_id: str | int,
        enabled: bool,
        delivery_id: str,
        idempotency_key: str,
    ) -> BrokerAction:
        """Queue a trusted `lots.active.set` action when supported."""

        payload = _normalize_lots_active_set_input(
            {
                "account_id": account_id,
                "lot_id": lot_id,
                "enabled": enabled,
                "delivery_id": delivery_id,
            }
        )
        return self.submit_action(
            "lots.active.set",
            payload,
            idempotency_key=idempotency_key,
        )

    def set_lot_price(
        self,
        *,
        account_id: str | int,
        lot_id: str | int,
        price: str | int | float,
        delivery_id: str,
        idempotency_key: str,
    ) -> BrokerAction:
        """Queue a trusted `lots.price.set` action when supported."""

        payload = _normalize_lots_price_set_input(
            {
                "account_id": account_id,
                "lot_id": lot_id,
                "price": price,
                "delivery_id": delivery_id,
            }
        )
        return self.submit_action(
            "lots.price.set",
            payload,
            idempotency_key=idempotency_key,
        )

    def raise_lots(
        self,
        *,
        account_id: str | int,
        lot_id: str | int,
        delivery_id: str,
        idempotency_key: str,
    ) -> BrokerAction:
        """Queue a trusted `lots.raise` action when supported.

        The plugin supplies the delivery-bound lot id. FunPay Pulse derives the
        subcategory/category server-side and never accepts raw FunPay form fields.
        """

        payload = _normalize_lots_raise_input(
            {
                "account_id": account_id,
                "lot_id": lot_id,
                "delivery_id": delivery_id,
            }
        )
        return self.submit_action(
            "lots.raise",
            payload,
            idempotency_key=idempotency_key,
        )

    def add_to_blacklist(
        self,
        *,
        account_id: str | int,
        username: str,
        delivery_id: str,
        buyer_id: str | int | None = None,
        reason: str | None = None,
        block_messages: bool = True,
        block_delivery: bool = True,
        block_review_reply: bool = True,
        block_notifications: bool = False,
        expires_at: str | None = None,
        idempotency_key: str,
    ) -> BrokerAction:
        """Queue a trusted delivery-bound `blacklist.add` action when supported."""

        payload = _normalize_blacklist_add_input(
            {
                "account_id": account_id,
                "username": username,
                "buyer_id": buyer_id,
                "delivery_id": delivery_id,
                "reason": reason,
                "block_messages": block_messages,
                "block_delivery": block_delivery,
                "block_review_reply": block_review_reply,
                "block_notifications": block_notifications,
                "expires_at": expires_at,
            }
        )
        return self.submit_action(
            "blacklist.add",
            payload,
            idempotency_key=idempotency_key,
        )

    def remove_from_blacklist(
        self,
        *,
        account_id: str | int,
        username: str,
        delivery_id: str,
        buyer_id: str | int | None = None,
        idempotency_key: str,
    ) -> BrokerAction:
        """Queue a trusted delivery-bound `blacklist.remove` action when supported."""

        payload = _normalize_blacklist_remove_input(
            {
                "account_id": account_id,
                "username": username,
                "buyer_id": buyer_id,
                "delivery_id": delivery_id,
            }
        )
        return self.submit_action(
            "blacklist.remove",
            payload,
            idempotency_key=idempotency_key,
        )

    def _request_json(
        self,
        method: str,
        path: str,
        *,
        body: bytes | None = None,
        extra_headers: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        headers = {
            "Authorization": f"Bearer {self.broker_token}",
            "Accept": "application/json",
            "User-Agent": "funpay-pulse-sdk/0.1",
        }
        if extra_headers:
            headers.update(extra_headers)
        request = Request(
            urljoin(self.base_url, path),
            data=(
                body
                if body is not None
                else (b"" if method in {"POST", "PUT", "DELETE"} else None)
            ),
            method=method,
            headers=headers,
        )
        try:
            with self._opener.open(request, timeout=self.timeout_seconds) as response:
                body = _read_limited(response, MAX_RESPONSE_BYTES)
        except HTTPError as exc:
            detail = _decode_error_body(exc)
            raise BrokerClientError(
                f"Broker API returned HTTP {exc.code}: {detail}"
            ) from exc
        except URLError as exc:
            raise BrokerClientError(f"Broker API request failed: {exc.reason}") from exc
        except OSError as exc:
            raise BrokerClientError(f"Broker API request failed: {exc}") from exc

        try:
            data = json.loads(body.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise BrokerClientError("Broker API returned invalid JSON") from exc
        if not isinstance(data, dict):
            raise BrokerClientError("Broker API response must be a JSON object")
        return data

    def _request_bytes(
        self,
        method: str,
        path: str,
        *,
        max_bytes: int,
        extra_headers: dict[str, str] | None = None,
    ) -> tuple[bytes, Any]:
        headers = {
            "Authorization": f"Bearer {self.broker_token}",
            "Accept": "*/*",
            "User-Agent": "funpay-pulse-sdk/0.1",
        }
        if extra_headers:
            headers.update(extra_headers)
        request = Request(
            urljoin(self.base_url, path),
            method=method,
            headers=headers,
        )
        try:
            with self._opener.open(request, timeout=self.timeout_seconds) as response:
                body = _read_limited(response, max_bytes)
                response_headers = getattr(response, "headers", {})
        except HTTPError as exc:
            detail = _decode_error_body(exc)
            raise BrokerClientError(
                f"Broker API returned HTTP {exc.code}: {detail}"
            ) from exc
        except URLError as exc:
            raise BrokerClientError(f"Broker API request failed: {exc.reason}") from exc
        except OSError as exc:
            raise BrokerClientError(f"Broker API request failed: {exc}") from exc
        return body, response_headers


def _bounded_limit(limit: int) -> int:
    if isinstance(limit, bool):
        raise ValueError("limit must be an integer")
    try:
        parsed = int(limit)
    except (TypeError, ValueError) as exc:
        raise ValueError("limit must be an integer") from exc
    if parsed < 1 or parsed > 100:
        raise ValueError("limit must be between 1 and 100")
    return parsed


def _validate_idempotency_key(value: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ValueError("Idempotency-Key is required")
    normalized = value.strip()
    if not IDEMPOTENCY_KEY_RE.fullmatch(normalized):
        raise ValueError("Idempotency-Key must be 8..128 chars: A-Z a-z 0-9 . _ : -")
    if (
        BROKER_TOKEN_RE.search(normalized)
        or PLUGIN_INVITE_TOKEN_RE.search(normalized)
        or CONNECTION_TOKEN_RE.search(normalized)
        or _looks_like_secret_value(normalized)
    ):
        raise ValueError("Idempotency-Key must not contain a token")
    normalized_key = normalized.lower().replace("-", "_")
    compact_key = normalized_key.replace("_", "")
    if any(
        marker in normalized_key or marker.replace("_", "") in compact_key
        for marker in SENSITIVE_IDEMPOTENCY_KEY_MARKERS
    ):
        raise ValueError("Idempotency-Key must not contain sensitive key names")
    return normalized


def _idempotency_key_hash(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def _looks_like_secret_value(value: str) -> bool:
    return any(pattern.search(value) for pattern in SECRET_VALUE_PATTERNS)


def _validate_storage_key(value: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ValueError("storage key is required")
    normalized = value.strip()
    if not re.fullmatch(r"^[A-Za-z0-9._:-]{1,128}$", normalized):
        raise ValueError("storage key must be 1..128 chars: A-Z a-z 0-9 . _ : -")
    normalized_key = normalized.lower().replace("-", "_")
    compact_key = normalized_key.replace("_", "")
    if any(
        marker in normalized_key or marker.replace("_", "") in compact_key
        for marker in SENSITIVE_IDEMPOTENCY_KEY_MARKERS
    ):
        raise ValueError("storage key must not contain sensitive key names")
    return normalized


def _validate_secret_key(value: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ValueError("secret key is required")
    normalized = value.strip()
    if not re.fullmatch(r"^[A-Za-z0-9._:-]{1,128}$", normalized):
        raise ValueError("secret key must be 1..128 chars: A-Z a-z 0-9 . _ : -")
    compact = re.sub(r"[^a-z0-9]+", "", normalized.lower())
    if any(
        re.sub(r"[^a-z0-9]+", "", marker.lower()) in compact
        for marker in INTERNAL_SECRET_KEY_MARKERS
    ):
        raise ValueError("secret key must not reference Pulse or FunPay internals")
    return normalized


def _validate_secret_value(key: str, value: str) -> str:
    _validate_secret_key(key)
    if not isinstance(value, str):
        raise ValueError("secret value must be a string")
    if not value.strip():
        raise ValueError("secret value is required")
    if len(value.encode("utf-8")) > 16 * 1024:
        raise ValueError("secret value exceeds 16384 bytes")
    if BROKER_TOKEN_RE.search(value) or PLUGIN_INVITE_TOKEN_RE.search(value):
        raise ValueError("secret value must not contain Plugin Broker tokens")
    if CONNECTION_TOKEN_RE.search(value):
        raise ValueError("secret value must not contain Pulse connection tokens")
    return value


def _normalize_logs_write_input(action_input: dict[str, Any]) -> dict[str, Any]:
    message = action_input.get("message")
    if not isinstance(message, str) or not message.strip():
        raise ValueError("message is required")
    normalized_message = message.strip()
    if len(normalized_message) > 4096:
        raise ValueError("message is too long")
    level = action_input.get("level", "info")
    if not isinstance(level, str):
        raise ValueError("level must be a string")
    normalized_level = level.strip().lower() or "info"
    if normalized_level not in {"debug", "info", "warning", "error"}:
        raise ValueError("level is invalid")
    context = action_input.get("context") or {}
    if not isinstance(context, dict):
        raise ValueError("context must be a JSON object")
    return {
        "level": normalized_level,
        "message": normalized_message,
        "context": context,
    }


def _normalize_orders_get_input(action_input: dict[str, Any]) -> dict[str, Any]:
    account_id = _normalize_action_id(action_input.get("account_id"), "account_id")
    order_id = _normalize_order_id(action_input.get("order_id"), "order_id")
    delivery_id = _required_display_string(
        action_input.get("delivery_id"),
        "delivery_id",
        max_length=128,
    )
    return {
        "account_id": account_id,
        "order_id": order_id,
        "delivery_id": delivery_id,
    }


def _normalize_orders_list_input(action_input: dict[str, Any]) -> dict[str, Any]:
    account_id = _normalize_action_id(action_input.get("account_id"), "account_id")
    delivery_id = _required_display_string(
        action_input.get("delivery_id"),
        "delivery_id",
        max_length=128,
    )
    status = action_input.get("status", "paid")
    if not isinstance(status, str) or not status.strip():
        raise ValueError("status is required")
    normalized_status = status.strip().lower()
    if normalized_status not in {"paid", "closed"}:
        raise ValueError("status is invalid")
    limit = _bounded_action_limit(action_input.get("limit", 25), max_limit=50)
    cursor = _optional_action_id(action_input.get("cursor"), "cursor")
    payload: dict[str, Any] = {
        "account_id": account_id,
        "delivery_id": delivery_id,
        "status": normalized_status,
        "limit": limit,
    }
    if cursor is not None:
        payload["cursor"] = cursor
    return payload


def _normalize_orders_refund_input(action_input: dict[str, Any]) -> dict[str, Any]:
    account_id = _normalize_action_id(action_input.get("account_id"), "account_id")
    order_id = _normalize_order_id(action_input.get("order_id"), "order_id")
    delivery_id = _required_display_string(
        action_input.get("delivery_id"),
        "delivery_id",
        max_length=128,
    )
    return {
        "account_id": account_id,
        "order_id": order_id,
        "delivery_id": delivery_id,
    }


def _normalize_orders_review_reply_input(action_input: dict[str, Any]) -> dict[str, Any]:
    _reject_unknown_action_fields(
        action_input,
        {"account_id", "order_id", "delivery_id", "text"},
        action_type="orders.review.reply",
    )
    account_id = _normalize_action_id(action_input.get("account_id"), "account_id")
    order_id = _normalize_order_id(action_input.get("order_id"), "order_id")
    delivery_id = _required_display_string(
        action_input.get("delivery_id"),
        "delivery_id",
        max_length=128,
    )
    text = action_input.get("text")
    if not isinstance(text, str) or not text.strip():
        raise ValueError("text is required")
    normalized_text = text.strip()
    if len(normalized_text) > 1000:
        raise ValueError("text is too long")
    if (
        BROKER_TOKEN_RE.search(normalized_text)
        or PLUGIN_INVITE_TOKEN_RE.search(normalized_text)
        or CONNECTION_TOKEN_RE.search(normalized_text)
        or _looks_like_secret_value(normalized_text)
    ):
        raise ValueError("text must not contain a token or secret")
    return {
        "account_id": account_id,
        "order_id": order_id,
        "delivery_id": delivery_id,
        "text": normalized_text,
    }


def _normalize_lots_get_input(action_input: dict[str, Any]) -> dict[str, Any]:
    account_id = _normalize_action_id(action_input.get("account_id"), "account_id")
    lot_id = _normalize_action_id(action_input.get("lot_id"), "lot_id")
    delivery_id = _required_display_string(
        action_input.get("delivery_id"),
        "delivery_id",
        max_length=128,
    )
    return {
        "account_id": account_id,
        "lot_id": lot_id,
        "delivery_id": delivery_id,
    }


def _normalize_lots_list_input(action_input: dict[str, Any]) -> dict[str, Any]:
    account_id = _normalize_action_id(action_input.get("account_id"), "account_id")
    delivery_id = _required_display_string(
        action_input.get("delivery_id"),
        "delivery_id",
        max_length=128,
    )
    limit = _bounded_limit(action_input.get("limit", 50))
    cursor = _optional_action_id(action_input.get("cursor"), "cursor")
    payload: dict[str, Any] = {
        "account_id": account_id,
        "delivery_id": delivery_id,
        "limit": limit,
    }
    if cursor is not None:
        payload["cursor"] = cursor
    return payload


def _bounded_action_limit(limit: int, *, max_limit: int) -> int:
    if isinstance(limit, bool):
        raise ValueError("limit must be an integer")
    try:
        parsed = int(limit)
    except (TypeError, ValueError) as exc:
        raise ValueError("limit must be an integer") from exc
    if parsed < 1 or parsed > max_limit:
        raise ValueError(f"limit must be between 1 and {max_limit}")
    return parsed


def _normalize_messages_send_input(action_input: dict[str, Any]) -> dict[str, Any]:
    account_id = _normalize_action_id(action_input.get("account_id"), "account_id")
    chat_id = _normalize_action_id(action_input.get("chat_id"), "chat_id")
    delivery_id = _required_display_string(
        action_input.get("delivery_id"),
        "delivery_id",
        max_length=128,
    )
    text = action_input.get("text")
    if not isinstance(text, str) or not text.strip():
        raise ValueError("text is required")
    normalized_text = text.strip()
    if len(normalized_text) > 2000:
        raise ValueError("text is too long")
    if BROKER_TOKEN_RE.search(normalized_text):
        raise ValueError("text must not contain a broker token")
    return {
        "account_id": account_id,
        "chat_id": chat_id,
        "delivery_id": delivery_id,
        "text": normalized_text,
    }


def _normalize_lots_active_set_input(action_input: dict[str, Any]) -> dict[str, Any]:
    account_id = _normalize_action_id(action_input.get("account_id"), "account_id")
    lot_id = _normalize_action_id(action_input.get("lot_id"), "lot_id")
    enabled = action_input.get("enabled")
    if not isinstance(enabled, bool):
        raise ValueError("enabled must be a boolean")
    delivery_id = _required_display_string(
        action_input.get("delivery_id"),
        "delivery_id",
        max_length=128,
    )
    return {
        "account_id": account_id,
        "lot_id": lot_id,
        "enabled": enabled,
        "delivery_id": delivery_id,
    }


def _normalize_lots_price_set_input(action_input: dict[str, Any]) -> dict[str, Any]:
    account_id = _normalize_action_id(action_input.get("account_id"), "account_id")
    lot_id = _normalize_action_id(action_input.get("lot_id"), "lot_id")
    price = _normalize_lot_price(action_input.get("price"))
    delivery_id = _required_display_string(
        action_input.get("delivery_id"),
        "delivery_id",
        max_length=128,
    )
    return {
        "account_id": account_id,
        "lot_id": lot_id,
        "price": price,
        "delivery_id": delivery_id,
    }


def _normalize_lots_raise_input(action_input: dict[str, Any]) -> dict[str, Any]:
    _reject_unknown_action_fields(
        action_input,
        {"account_id", "lot_id", "delivery_id"},
        action_type="lots.raise",
    )
    account_id = _normalize_action_id(action_input.get("account_id"), "account_id")
    lot_id = _normalize_action_id(action_input.get("lot_id"), "lot_id")
    delivery_id = _required_display_string(
        action_input.get("delivery_id"),
        "delivery_id",
        max_length=128,
    )
    return {
        "account_id": account_id,
        "lot_id": lot_id,
        "delivery_id": delivery_id,
    }


def _normalize_blacklist_add_input(action_input: dict[str, Any]) -> dict[str, Any]:
    _reject_unknown_action_fields(
        action_input,
        {
            "account_id",
            "delivery_id",
            "username",
            "buyer_id",
            "reason",
            "block_messages",
            "block_delivery",
            "block_review_reply",
            "block_notifications",
            "expires_at",
        },
        action_type="blacklist.add",
    )
    account_id = _normalize_action_id(action_input.get("account_id"), "account_id")
    delivery_id = _required_display_string(
        action_input.get("delivery_id"),
        "delivery_id",
        max_length=128,
    )
    username = _normalize_username(action_input.get("username"))
    buyer_id = _optional_action_id(action_input.get("buyer_id"), "buyer_id")
    reason = _optional_display_string(action_input.get("reason"), "reason", max_length=256)
    expires_at = _optional_display_string(
        action_input.get("expires_at"),
        "expires_at",
        max_length=64,
    )
    payload: dict[str, Any] = {
        "account_id": account_id,
        "delivery_id": delivery_id,
        "username": username,
        "block_messages": _optional_bool_field(
            action_input.get("block_messages"),
            default=True,
        ),
        "block_delivery": _optional_bool_field(
            action_input.get("block_delivery"),
            default=True,
        ),
        "block_review_reply": _optional_bool_field(
            action_input.get("block_review_reply"),
            default=True,
        ),
        "block_notifications": _optional_bool_field(
            action_input.get("block_notifications"),
            default=False,
        ),
    }
    if buyer_id is not None:
        payload["buyer_id"] = buyer_id
    if reason is not None:
        payload["reason"] = reason
    if expires_at is not None:
        payload["expires_at"] = expires_at
    return payload


def _normalize_blacklist_remove_input(action_input: dict[str, Any]) -> dict[str, Any]:
    _reject_unknown_action_fields(
        action_input,
        {"account_id", "delivery_id", "username", "buyer_id"},
        action_type="blacklist.remove",
    )
    account_id = _normalize_action_id(action_input.get("account_id"), "account_id")
    delivery_id = _required_display_string(
        action_input.get("delivery_id"),
        "delivery_id",
        max_length=128,
    )
    username = _normalize_username(action_input.get("username"))
    buyer_id = _optional_action_id(action_input.get("buyer_id"), "buyer_id")
    payload: dict[str, Any] = {
        "account_id": account_id,
        "delivery_id": delivery_id,
        "username": username,
    }
    if buyer_id is not None:
        payload["buyer_id"] = buyer_id
    return payload


def _reject_unknown_action_fields(
    action_input: dict[str, Any],
    allowed_fields: set[str],
    *,
    action_type: str,
) -> None:
    unknown = sorted(str(key) for key in action_input if key not in allowed_fields)
    if unknown:
        raise ValueError(f"{action_type} input has unsupported fields: {', '.join(unknown[:5])}")


def _normalize_lot_price(value: Any) -> float:
    if isinstance(value, bool) or value is None:
        raise ValueError("price must be a positive number")
    if isinstance(value, str):
        normalized = value.strip()
        if not re.fullmatch(r"\d+(?:\.\d{1,2})?", normalized):
            raise ValueError("price must have at most two decimals")
    elif isinstance(value, (int, float)):
        if isinstance(value, float) and not math.isfinite(value):
            raise ValueError("price must be finite")
        normalized = str(value)
    else:
        raise ValueError("price must be a positive number")
    try:
        price = Decimal(normalized)
    except (InvalidOperation, ValueError) as exc:
        raise ValueError("price must be a positive number") from exc
    if price <= 0:
        raise ValueError("price must be positive")
    if price > MAX_LOT_PRICE_VALUE:
        raise ValueError("price is too large")
    if abs(price.as_tuple().exponent) > 2:
        raise ValueError("price must have at most two decimals")
    return float(price.quantize(Decimal("0.01")))


def _normalize_action_id(value: Any, field_name: str) -> str:
    if isinstance(value, int) and not isinstance(value, bool) and value > 0:
        return str(value)
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{field_name} is required")
    normalized = value.strip()
    if len(normalized) > 64:
        raise ValueError(f"{field_name} is too long")
    if not normalized.isdecimal() or int(normalized) <= 0:
        raise ValueError(f"{field_name} must be a positive integer id")
    return normalized


def _optional_action_id(value: Any, field_name: str) -> str | None:
    if value is None:
        return None
    if isinstance(value, str) and not value.strip():
        return None
    return _normalize_action_id(value, field_name)


def _normalize_order_id(value: Any, field_name: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{field_name} is required")
    normalized = value.strip().upper()
    if not ORDER_ID_RE.fullmatch(normalized):
        raise ValueError(f"{field_name} is invalid")
    return normalized


def _required_display_string(value: Any, field_name: str, *, max_length: int) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{field_name} is required")
    normalized = value.strip()
    if len(normalized) > max_length:
        raise ValueError(f"{field_name} is too long")
    if BROKER_TOKEN_RE.search(normalized):
        raise ValueError(f"{field_name} must not contain a broker token")
    return normalized


def _optional_display_string(value: Any, field_name: str, *, max_length: int) -> str | None:
    if value is None:
        return None
    if isinstance(value, str) and not value.strip():
        return None
    return _required_display_string(value, field_name, max_length=max_length)


def _normalize_username(value: Any) -> str:
    return _required_display_string(value, "username", max_length=128).lower()


def _optional_bool_field(value: Any, *, default: bool) -> bool:
    if value is None:
        return default
    if not isinstance(value, bool):
        raise ValueError("boolean flag is invalid")
    return value


def broker_event_from_dict(item: Any) -> BrokerEvent:
    """Parse one Broker delivery object.

    This is public so local SDK fixtures can reuse the exact same validation as
    the real polling client.
    """

    return _parse_event(item)


def broker_action_from_dict(item: Any) -> BrokerAction:
    """Parse one Broker action response object."""

    return _parse_action(item)


def broker_action_status_from_dict(item: Any) -> BrokerActionStatus:
    """Parse one Broker action status response object."""

    return _parse_action_status(item)


def broker_order_summary_from_dict(item: Any) -> BrokerOrderSummary:
    """Parse a safe order result object returned by `orders.get`."""

    return _parse_order_summary(item)


def broker_orders_page_from_dict(item: Any) -> BrokerOrdersPage:
    """Parse a safe order page returned by `orders.list`."""

    return _parse_orders_page(item)


def broker_order_refund_result_from_dict(item: Any) -> BrokerOrderRefundResult:
    """Parse a safe refund result returned by `orders.refund`."""

    return _parse_order_refund_result(item)


def broker_order_review_reply_result_from_dict(
    item: Any,
) -> BrokerOrderReviewReplyResult:
    """Parse a safe review reply result returned by `orders.review.reply`."""

    return _parse_order_review_reply_result(item)


def broker_message_send_result_from_dict(item: Any) -> BrokerMessageSendResult:
    """Parse a safe message-send result returned by `messages.send`."""

    return _parse_message_send_result(item)


def broker_lot_summary_from_dict(item: Any) -> BrokerLotSummary:
    """Parse a safe lot result object returned by `lots.get`."""

    return _parse_lot_summary(item)


def broker_lots_page_from_dict(item: Any) -> BrokerLotsPage:
    """Parse a safe lot page returned by `lots.list`."""

    return _parse_lots_page(item)


def broker_lot_active_set_result_from_dict(item: Any) -> BrokerLotActiveSetResult:
    """Parse a safe lot active toggle result returned by `lots.active.set`."""

    return _parse_lot_active_set_result(item)


def broker_lot_price_set_result_from_dict(item: Any) -> BrokerLotPriceSetResult:
    """Parse a safe lot price result returned by `lots.price.set`."""

    return _parse_lot_price_set_result(item)


def broker_lots_raise_result_from_dict(item: Any) -> BrokerLotsRaiseResult:
    """Parse a safe lot raise result returned by `lots.raise`."""

    return _parse_lots_raise_result(item)


def broker_blacklist_add_result_from_dict(item: Any) -> BrokerBlacklistAddResult:
    """Parse a safe blacklist add result returned by `blacklist.add`."""

    return _parse_blacklist_add_result(item)


def broker_blacklist_remove_result_from_dict(item: Any) -> BrokerBlacklistRemoveResult:
    """Parse a safe blacklist remove result returned by `blacklist.remove`."""

    return _parse_blacklist_remove_result(item)


def broker_config_from_dict(item: Any) -> BrokerConfig:
    """Parse one Broker config response object."""

    return _parse_config(item)


def broker_webhook_secret_from_dict(item: Any) -> BrokerWebhookSecret:
    """Parse one Broker webhook-secret response object."""

    return _parse_webhook_secret(item)


def broker_storage_item_from_dict(item: Any) -> BrokerStorageItem:
    """Parse one Broker storage item response object."""

    return _parse_storage_item(item)


def broker_secret_item_from_dict(item: Any) -> BrokerSecretItem:
    """Parse one Broker secret metadata/value response object."""

    return _parse_secret_item(item, expect_value="value" in item if isinstance(item, dict) else False)


def broker_capabilities_from_dict(item: Any) -> BrokerCapabilities:
    """Parse one Broker capabilities response object."""

    return _parse_capabilities(item)


def broker_package_manifest_from_dict(item: Any) -> BrokerPackageManifest:
    """Parse one Broker package manifest response object."""

    return _parse_package_manifest(item)


class _NoRedirectHandler(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def _validate_base_url(base_url: str, *, allow_insecure_localhost: bool) -> None:
    parsed = urlparse(base_url)
    if parsed.username or parsed.password:
        raise ValueError("base_url must not contain userinfo")
    if parsed.query or parsed.fragment:
        raise ValueError("base_url must not contain query or fragment")
    if not parsed.scheme or not parsed.hostname:
        raise ValueError("base_url must be an absolute URL")
    if parsed.scheme == "https":
        return
    if (
        allow_insecure_localhost
        and parsed.scheme == "http"
        and _is_localhost(parsed.hostname)
    ):
        return
    raise ValueError("base_url must use https; http is allowed only for localhost dev mode")


def _is_localhost(host: str) -> bool:
    normalized = host.lower().strip("[]")
    if normalized == "localhost":
        return True
    try:
        return ipaddress.ip_address(normalized).is_loopback
    except ValueError:
        return False


def _parse_event(item: Any) -> BrokerEvent:
    if not isinstance(item, dict):
        raise BrokerClientError("Broker event item must be an object")
    payload = item.get("payload")
    if not isinstance(payload, dict):
        raise BrokerClientError("Broker event payload must be an object")
    return BrokerEvent(
        delivery_id=_required_string(item, "delivery_id"),
        event_id=_required_string(item, "event_id"),
        event_type=_required_string(item, "event_type"),
        payload=payload,
        created_at=_required_string(item, "created_at"),
        delivered_at=_optional_string(item, "delivered_at"),
    )


def _parse_action(item: Any) -> BrokerAction:
    if not isinstance(item, dict):
        raise BrokerClientError("Broker action response must be an object")
    if item.get("success") is not True:
        raise BrokerClientError("Broker action response was not successful")
    created = item.get("created")
    if not isinstance(created, bool):
        raise BrokerClientError("Broker action response missing created flag")
    return BrokerAction(
        action_id=_required_action_string(item, "action_id"),
        action_type=_required_action_string(item, "action_type"),
        status=_required_action_string(item, "status"),
        idempotency_key_hash=_optional_string(item, "idempotency_key_hash")
        or _idempotency_key_hash(_required_action_string(item, "idempotency_key")),
        created=created,
        created_at=_required_action_string(item, "created_at"),
        idempotency_key=_optional_string(item, "idempotency_key"),
    )


def _parse_action_status(item: Any) -> BrokerActionStatus:
    if not isinstance(item, dict):
        raise BrokerClientError("Broker action status response must be an object")
    if item.get("success") is not True:
        raise BrokerClientError("Broker action status response was not successful")
    result = item.get("result")
    if not isinstance(result, dict):
        raise BrokerClientError("Broker action status response missing result object")
    attempt_count = item.get("attempt_count")
    if (
        not isinstance(attempt_count, int)
        or isinstance(attempt_count, bool)
        or attempt_count < 0
    ):
        raise BrokerClientError("Broker action status response missing attempt_count")
    return BrokerActionStatus(
        action_id=_required_action_string(item, "action_id"),
        action_type=_required_action_string(item, "action_type"),
        status=_required_action_string(item, "status"),
        idempotency_key_hash=_optional_string(item, "idempotency_key_hash")
        or _idempotency_key_hash(_required_action_string(item, "idempotency_key")),
        attempt_count=attempt_count,
        created_at=_required_action_string(item, "created_at"),
        updated_at=_required_action_string(item, "updated_at"),
        idempotency_key=_optional_string(item, "idempotency_key"),
        claimed_at=_optional_string(item, "claimed_at"),
        lease_until=_optional_string(item, "lease_until"),
        completed_at=_optional_string(item, "completed_at"),
        result=result,
        error_code=_optional_string(item, "error_code"),
        error_message=_optional_string(item, "error_message"),
    )


def _parse_order_review(item: Any) -> BrokerOrderReview | None:
    if item is None:
        return None
    if not isinstance(item, dict):
        raise BrokerClientError("Broker order review result must be an object")
    return BrokerOrderReview(
        stars=_optional_result_number(item, "stars"),
        text=_optional_result_string(item, "text"),
        hidden=_optional_result_bool(item, "hidden"),
        has_reply=_optional_result_bool(item, "has_reply"),
    )


def _parse_order_summary(item: Any) -> BrokerOrderSummary:
    if not isinstance(item, dict):
        raise BrokerClientError("Broker order result must be an object")
    return BrokerOrderSummary(
        account_id=_optional_result_string(item, "account_id"),
        order_id=_required_result_string(item, "order_id"),
        status=_optional_result_string(item, "status"),
        buyer_id=_optional_result_string(item, "buyer_id"),
        buyer_username=_optional_result_string(item, "buyer_username"),
        chat_id=_optional_result_string(item, "chat_id"),
        lot_id=_optional_result_string(item, "lot_id"),
        title=_optional_result_string(item, "title"),
        category=_optional_result_string(item, "category"),
        subcategory_id=_optional_result_string(item, "subcategory_id"),
        occurred_at=_optional_result_string(item, "occurred_at"),
        subcategory_type=_optional_result_string(item, "subcategory_type"),
        price=_optional_result_number(item, "price"),
        quantity=_optional_result_number(item, "quantity"),
        has_review=_optional_result_bool(item, "has_review"),
        review_hidden=_optional_result_bool(item, "review_hidden"),
        review_stars=_optional_result_number(item, "review_stars"),
        review_text=_optional_result_string(item, "review_text"),
        review=_parse_order_review(item.get("review")),
    )


def _parse_lot_summary(item: Any) -> BrokerLotSummary:
    if not isinstance(item, dict):
        raise BrokerClientError("Broker lot result must be an object")
    return BrokerLotSummary(
        account_id=_optional_result_string(item, "account_id"),
        lot_id=_required_result_string(item, "lot_id"),
        title=_optional_result_string(item, "title"),
        price=_optional_result_number(item, "price"),
        currency=_optional_result_string(item, "currency"),
        active=_optional_result_bool(item, "active"),
        auto_delivery=_optional_result_bool(item, "auto_delivery"),
        amount=_optional_result_number(item, "amount"),
        subcategory_id=_optional_result_string(item, "subcategory_id"),
        subcategory_name=_optional_result_string(item, "subcategory_name"),
        game_id=_optional_result_string(item, "game_id"),
        category_name=_optional_result_string(item, "category_name"),
        lot_type=_optional_result_string(item, "lot_type"),
        last_raised=_optional_result_string(item, "last_raised"),
        next_raise_available=_optional_result_string(item, "next_raise_available"),
    )


def _parse_orders_page(item: Any) -> BrokerOrdersPage:
    if not isinstance(item, dict):
        raise BrokerClientError("Broker orders page result must be an object")
    return BrokerOrdersPage(
        items=_parse_result_items(item, "items", _parse_order_summary),
        count=_required_result_count(item, "count"),
        has_more=_required_result_bool(item, "has_more"),
        next_cursor=_optional_result_string(item, "next_cursor"),
    )


def _parse_order_refund_result(item: Any) -> BrokerOrderRefundResult:
    if not isinstance(item, dict):
        raise BrokerClientError("Broker order refund result must be an object")
    return BrokerOrderRefundResult(
        order_id=_required_result_string(item, "order_id"),
        refunded=_required_result_bool(item, "refunded"),
        status=_optional_result_string(item, "status"),
        already_refunded=_optional_result_bool(item, "already_refunded"),
    )


def _parse_order_review_reply_result(item: Any) -> BrokerOrderReviewReplyResult:
    if not isinstance(item, dict):
        raise BrokerClientError("Broker order review reply result must be an object")
    return BrokerOrderReviewReplyResult(
        order_id=_required_result_string(item, "order_id"),
        replied=_required_result_bool(item, "replied"),
        rating=_optional_result_number(item, "rating"),
        already_replied=_optional_result_bool(item, "already_replied"),
    )


def _parse_message_send_result(item: Any) -> BrokerMessageSendResult:
    if not isinstance(item, dict):
        raise BrokerClientError("Broker message send result must be an object")
    return BrokerMessageSendResult(
        message_id=_optional_result_string(item, "message_id"),
    )


def _parse_lots_page(item: Any) -> BrokerLotsPage:
    if not isinstance(item, dict):
        raise BrokerClientError("Broker lots page result must be an object")
    return BrokerLotsPage(
        items=_parse_result_items(item, "items", _parse_lot_summary),
        count=_required_result_count(item, "count"),
        has_more=_required_result_bool(item, "has_more"),
        next_cursor=_optional_result_string(item, "next_cursor"),
    )


def _parse_lot_active_set_result(item: Any) -> BrokerLotActiveSetResult:
    if not isinstance(item, dict):
        raise BrokerClientError("Broker lot active result must be an object")
    return BrokerLotActiveSetResult(
        lot_id=_required_result_string(item, "lot_id"),
        active=_required_result_bool(item, "active"),
        previous_active=_optional_result_bool(item, "previous_active"),
        already_set=_optional_result_bool(item, "already_set"),
    )


def _parse_lot_price_set_result(item: Any) -> BrokerLotPriceSetResult:
    if not isinstance(item, dict):
        raise BrokerClientError("Broker lot price result must be an object")
    return BrokerLotPriceSetResult(
        lot_id=_required_result_string(item, "lot_id"),
        price=_required_result_number(item, "price"),
        previous_price=_optional_result_number(item, "previous_price"),
        already_set=_optional_result_bool(item, "already_set"),
    )


def _parse_lots_raise_result(item: Any) -> BrokerLotsRaiseResult:
    if not isinstance(item, dict):
        raise BrokerClientError("Broker lot raise result must be an object")
    return BrokerLotsRaiseResult(
        lot_id=_required_result_string(item, "lot_id"),
        subcategory_id=_optional_result_string(item, "subcategory_id"),
        raised=_required_result_bool(item, "raised"),
        wait_time_seconds=_optional_result_number(item, "wait_time_seconds"),
        next_raise_available=_optional_result_string(item, "next_raise_available"),
        already_on_cooldown=_optional_result_bool(item, "already_on_cooldown"),
    )


def _parse_blacklist_add_result(item: Any) -> BrokerBlacklistAddResult:
    if not isinstance(item, dict):
        raise BrokerClientError("Broker blacklist add result must be an object")
    return BrokerBlacklistAddResult(
        account_id=_required_result_string(item, "account_id"),
        username=_required_result_string(item, "username"),
        buyer_id=_optional_result_string(item, "buyer_id"),
        added=_required_result_bool(item, "added"),
        already_present=_optional_result_bool(item, "already_present"),
        expires_at=_optional_result_string(item, "expires_at"),
    )


def _parse_blacklist_remove_result(item: Any) -> BrokerBlacklistRemoveResult:
    if not isinstance(item, dict):
        raise BrokerClientError("Broker blacklist remove result must be an object")
    return BrokerBlacklistRemoveResult(
        account_id=_required_result_string(item, "account_id"),
        username=_required_result_string(item, "username"),
        buyer_id=_optional_result_string(item, "buyer_id"),
        removed=_required_result_bool(item, "removed"),
        already_absent=_optional_result_bool(item, "already_absent"),
        removed_count=_optional_result_number(item, "removed_count"),
    )


def _parse_result_items(item: dict[str, Any], key: str, parser: Any) -> tuple[Any, ...]:
    value = item.get(key)
    if not isinstance(value, list):
        raise BrokerClientError(f"Broker page result missing {key} list")
    return tuple(parser(child) for child in value)


def _optional_result_string(item: dict[str, Any], key: str) -> str | None:
    value = item.get(key)
    if value is None:
        return None
    if not isinstance(value, str):
        raise BrokerClientError(f"Broker result {key} must be a string")
    return value


def _required_result_string(item: dict[str, Any], key: str) -> str:
    value = _optional_result_string(item, key)
    if value is None or not value.strip():
        raise BrokerClientError(f"Broker result missing {key}")
    return value


def _optional_result_number(item: dict[str, Any], key: str) -> int | float | None:
    value = item.get(key)
    if value is None:
        return None
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise BrokerClientError(f"Broker result {key} must be a number")
    if isinstance(value, float) and not math.isfinite(value):
        raise BrokerClientError(f"Broker result {key} must be finite")
    return value


def _required_result_number(item: dict[str, Any], key: str) -> int | float:
    value = _optional_result_number(item, key)
    if value is None:
        raise BrokerClientError(f"Broker result missing {key}")
    return value


def _optional_result_bool(item: dict[str, Any], key: str) -> bool | None:
    value = item.get(key)
    if value is None:
        return None
    if not isinstance(value, bool):
        raise BrokerClientError(f"Broker result {key} must be a boolean")
    return value


def _required_result_bool(item: dict[str, Any], key: str) -> bool:
    value = _optional_result_bool(item, key)
    if value is None:
        raise BrokerClientError(f"Broker result missing {key}")
    return value


def _required_result_count(item: dict[str, Any], key: str) -> int:
    value = item.get(key)
    if not isinstance(value, int) or isinstance(value, bool) or value < 0:
        raise BrokerClientError(f"Broker result missing {key}")
    return value


def _parse_config(item: Any) -> BrokerConfig:
    if not isinstance(item, dict):
        raise BrokerClientError("Broker config response must be an object")
    config = item.get("config")
    if not isinstance(config, dict):
        raise BrokerClientError("Broker config response missing config object")
    revision = item.get("config_revision")
    if not isinstance(revision, int) or isinstance(revision, bool) or revision < 1:
        raise BrokerClientError("Broker config response missing config_revision")
    return BrokerConfig(config=config, config_revision=revision)


def _parse_webhook_secret(item: Any) -> BrokerWebhookSecret:
    if not isinstance(item, dict):
        raise BrokerClientError("Broker webhook secret response must be an object")
    webhook_secret = item.get("webhook_secret")
    if not isinstance(webhook_secret, str) or WEBHOOK_SECRET_RE.fullmatch(webhook_secret) is None:
        raise BrokerClientError("Broker webhook secret response missing webhook_secret")
    installation_id = item.get("installation_id")
    if not isinstance(installation_id, str) or not installation_id.startswith("pli_"):
        raise BrokerClientError("Broker webhook secret response missing installation_id")
    signature_header = item.get("signature_header")
    timestamp_header = item.get("timestamp_header")
    nonce_header = item.get("nonce_header")
    if not isinstance(signature_header, str) or signature_header != "X-FPP-Signature":
        raise BrokerClientError("Broker webhook secret response missing signature_header")
    if not isinstance(timestamp_header, str) or timestamp_header != "X-FPP-Timestamp":
        raise BrokerClientError("Broker webhook secret response missing timestamp_header")
    if not isinstance(nonce_header, str) or nonce_header != "X-FPP-Nonce":
        raise BrokerClientError("Broker webhook secret response missing nonce_header")
    return BrokerWebhookSecret(
        webhook_secret=webhook_secret,
        installation_id=installation_id,
        signature_header=signature_header,
        timestamp_header=timestamp_header,
        nonce_header=nonce_header,
    )


def _parse_package_manifest(item: Any) -> BrokerPackageManifest:
    if not isinstance(item, dict):
        raise BrokerClientError("Broker package manifest response must be an object")
    _reject_package_internal_fields(item)
    manifest = item.get("manifest")
    if not isinstance(manifest, dict):
        raise BrokerClientError("Broker package manifest response missing manifest object")
    scopes = item.get("scopes")
    if not isinstance(scopes, list) or not all(isinstance(scope, str) for scope in scopes):
        raise BrokerClientError("Broker package manifest response missing scopes")
    package_metadata = item.get("package_metadata")
    if not isinstance(package_metadata, dict):
        raise BrokerClientError(
            "Broker package manifest response missing package_metadata object"
        )
    manifest_sha256 = _required_package_sha256(item, "manifest_sha256")
    package_sha256 = _required_package_sha256(item, "package_sha256")
    return BrokerPackageManifest(
        installation_id=_required_package_string(item, "installation_id"),
        product_public_id=_required_package_string(item, "product_public_id"),
        plugin_id=_required_package_string(item, "plugin_id"),
        plugin_name=_required_package_string(item, "plugin_name"),
        version=_required_package_string(item, "version"),
        runtime_type=_required_package_string(item, "runtime_type"),
        manifest_sha256=manifest_sha256,
        manifest=manifest,
        scopes=tuple(scopes),
        config_revision=_required_package_positive_int(item, "config_revision"),
        install_revision=_required_package_positive_int(item, "install_revision"),
        package_sha256=package_sha256,
        package_size_bytes=_required_package_positive_int(item, "package_size_bytes"),
        package_file_count=_required_package_non_negative_int(
            item,
            "package_file_count",
        ),
        package_metadata=package_metadata,
    )


def _parse_capabilities(item: Any) -> BrokerCapabilities:
    if not isinstance(item, dict):
        raise BrokerClientError("Broker capabilities response must be an object")
    scopes = item.get("scopes")
    supported_actions = item.get("supported_actions")
    storage_limits = item.get("storage_limits")
    secret_storage_limits = item.get(
        "secret_storage_limits",
        {
            "max_items": 0,
            "max_key_length": 0,
            "max_value_bytes": 0,
            "max_total_bytes": 0,
        },
    )
    if not isinstance(scopes, list) or not all(isinstance(scope, str) for scope in scopes):
        raise BrokerClientError("Broker capabilities response missing scopes")
    if not isinstance(supported_actions, list) or not all(
        isinstance(action, str) for action in supported_actions
    ):
        raise BrokerClientError("Broker capabilities response missing supported_actions")
    if not isinstance(storage_limits, dict):
        raise BrokerClientError("Broker capabilities response missing storage_limits")
    if not isinstance(secret_storage_limits, dict):
        raise BrokerClientError("Broker capabilities response missing secret_storage_limits")
    revision = item.get("config_revision")
    if not isinstance(revision, int) or isinstance(revision, bool) or revision < 1:
        raise BrokerClientError("Broker capabilities response missing config_revision")
    return BrokerCapabilities(
        broker_events_enabled=_required_bool(item, "broker_events_enabled"),
        broker_actions_enabled=_required_bool(item, "broker_actions_enabled"),
        broker_storage_enabled=_required_bool(item, "broker_storage_enabled"),
        broker_secrets_enabled=_optional_bool(
            item,
            "broker_secrets_enabled",
            default=False,
        ),
        broker_package_download_enabled=_optional_bool(
            item,
            "broker_package_download_enabled",
            default=False,
        ),
        scopes=tuple(scopes),
        supported_actions=tuple(supported_actions),
        storage_authorized=_required_bool(item, "storage_authorized"),
        storage_limits=BrokerStorageLimits(
            max_items=_required_positive_int(storage_limits, "max_items"),
            max_key_length=_required_positive_int(storage_limits, "max_key_length"),
            max_value_bytes=_required_positive_int(storage_limits, "max_value_bytes"),
            max_total_bytes=_required_positive_int(storage_limits, "max_total_bytes"),
        ),
        secret_storage_authorized=_optional_bool(
            item,
            "secret_storage_authorized",
            default=False,
        ),
        secret_storage_limits=BrokerSecretLimits(
            max_items=_required_non_negative_int(secret_storage_limits, "max_items"),
            max_key_length=_required_non_negative_int(secret_storage_limits, "max_key_length"),
            max_value_bytes=_required_non_negative_int(secret_storage_limits, "max_value_bytes"),
            max_total_bytes=_required_non_negative_int(secret_storage_limits, "max_total_bytes"),
        ),
        config_revision=revision,
    )


def _parse_storage_item(item: Any) -> BrokerStorageItem:
    if not isinstance(item, dict):
        raise BrokerClientError("Broker storage response must be an object")
    created = item.get("created", False)
    if not isinstance(created, bool):
        raise BrokerClientError("Broker storage response missing created flag")
    if "value" not in item:
        raise BrokerClientError("Broker storage response missing value")
    return BrokerStorageItem(
        key=_required_action_string(item, "key"),
        value=item["value"],
        created=created,
        updated_at=_required_action_string(item, "updated_at"),
    )


def _parse_secret_item(item: Any, *, expect_value: bool) -> BrokerSecretItem:
    if not isinstance(item, dict):
        raise BrokerClientError("Broker secret response must be an object")
    created = item.get("created", False)
    if not isinstance(created, bool):
        raise BrokerClientError("Broker secret response missing created flag")
    value: str | None = None
    if expect_value:
        raw_value = item.get("value")
        if not isinstance(raw_value, str):
            raise BrokerClientError("Broker secret response missing value")
        value = raw_value
    elif "value" in item:
        raise BrokerClientError("Broker secret metadata response must not include value")
    value_size = item.get("value_size_bytes")
    if not isinstance(value_size, int) or isinstance(value_size, bool) or value_size < 0:
        raise BrokerClientError("Broker secret response missing value_size_bytes")
    return BrokerSecretItem(
        key=_required_action_string(item, "key"),
        value=value,
        value_size_bytes=value_size,
        created=created,
        updated_at=_required_action_string(item, "updated_at"),
    )


def _required_string(data: dict[str, Any], key: str) -> str:
    value = data.get(key)
    if not isinstance(value, str) or not value.strip():
        raise BrokerClientError(f"Broker event missing {key}")
    return value


def _required_action_string(data: dict[str, Any], key: str) -> str:
    value = data.get(key)
    if not isinstance(value, str) or not value.strip():
        raise BrokerClientError(f"Broker action response missing {key}")
    return value


def _optional_string(data: dict[str, Any], key: str) -> str | None:
    value = data.get(key)
    if value is None:
        return None
    if not isinstance(value, str):
        raise BrokerClientError(f"Broker event {key} must be a string")
    return value


def _required_bool(data: dict[str, Any], key: str) -> bool:
    value = data.get(key)
    if not isinstance(value, bool):
        raise BrokerClientError(f"Broker capabilities response missing {key}")
    return value


def _optional_bool(data: dict[str, Any], key: str, *, default: bool) -> bool:
    value = data.get(key, default)
    if not isinstance(value, bool):
        raise BrokerClientError(f"Broker capabilities response invalid {key}")
    return value


def _required_positive_int(data: dict[str, Any], key: str) -> int:
    value = data.get(key)
    if not isinstance(value, int) or isinstance(value, bool) or value < 1:
        raise BrokerClientError(f"Broker capabilities storage_limits missing {key}")
    return value


def _required_non_negative_int(data: dict[str, Any], key: str) -> int:
    value = data.get(key)
    if not isinstance(value, int) or isinstance(value, bool) or value < 0:
        raise BrokerClientError(f"Broker capabilities limits missing {key}")
    return value


def _reject_package_internal_fields(data: dict[str, Any]) -> None:
    internal_fields = {
        "buyer_license_id",
        "license_id",
        "package_storage_path",
        "payment_id",
        "provider_payload",
        "raw_broker_token",
        "token_hash",
    }
    if internal_fields.intersection(data):
        raise BrokerClientError("Broker package manifest leaked internal package path")


def _required_package_string(data: dict[str, Any], key: str) -> str:
    value = data.get(key)
    if not isinstance(value, str) or not value.strip():
        raise BrokerClientError(f"Broker package manifest response missing {key}")
    return value


def _required_package_sha256(data: dict[str, Any], key: str) -> str:
    value = _required_package_string(data, key).lower()
    if not SHA256_RE.fullmatch(value):
        raise BrokerClientError(f"Broker package manifest response invalid {key}")
    return value


def _required_package_positive_int(data: dict[str, Any], key: str) -> int:
    value = data.get(key)
    if not isinstance(value, int) or isinstance(value, bool) or value < 1:
        raise BrokerClientError(f"Broker package manifest response missing {key}")
    return value


def _required_package_non_negative_int(data: dict[str, Any], key: str) -> int:
    value = data.get(key)
    if not isinstance(value, int) or isinstance(value, bool) or value < 0:
        raise BrokerClientError(f"Broker package manifest response missing {key}")
    return value


def _optional_sha256(value: str | None, *, field_name: str) -> str | None:
    if value is None:
        return None
    if not isinstance(value, str):
        raise ValueError(f"{field_name} must be a lowercase SHA-256 hex string")
    normalized = value.strip().lower()
    if not SHA256_RE.fullmatch(normalized):
        raise ValueError(f"{field_name} must be a lowercase SHA-256 hex string")
    return normalized


def _header_value(headers: Any, name: str) -> str | None:
    if headers is None:
        return None
    candidates = (name, name.lower(), name.upper())
    getter = getattr(headers, "get", None)
    if callable(getter):
        for candidate in candidates:
            value = getter(candidate)
            if value is not None:
                return str(value)
    if isinstance(headers, dict):
        lowered = name.lower()
        for key, value in headers.items():
            if str(key).lower() == lowered:
                return str(value)
    return None


def _optional_header(headers: Any, name: str) -> str | None:
    value = _header_value(headers, name)
    if value is None:
        return None
    cleaned = value.strip()
    return cleaned or None


def _required_header_sha256(headers: Any, name: str) -> str:
    value = _optional_header(headers, name)
    if value is None or not SHA256_RE.fullmatch(value.lower()):
        raise BrokerClientError(f"Broker package download missing {name}")
    return value.lower()


def _required_header_non_negative_int(headers: Any, name: str) -> int:
    value = _optional_header(headers, name)
    if value is None:
        raise BrokerClientError(f"Broker package download missing {name}")
    try:
        parsed = int(value)
    except ValueError as exc:
        raise BrokerClientError(f"Broker package download invalid {name}") from exc
    if parsed < 0:
        raise BrokerClientError(f"Broker package download invalid {name}")
    return parsed


def _decode_error_body(exc: HTTPError) -> str:
    try:
        body = _read_limited(exc, MAX_ERROR_BYTES).decode("utf-8")
    except BrokerClientError:
        return "error body too large"
    except Exception:
        return "unreadable error body"
    if not body:
        return "empty error body"
    return BROKER_TOKEN_RE.sub("fppb_<redacted>", body[:500])


def _read_limited(response: Any, max_bytes: int) -> bytes:
    body = response.read(max_bytes + 1)
    if len(body) > max_bytes:
        raise BrokerClientError("Broker API response body too large")
    return body
