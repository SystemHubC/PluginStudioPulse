"""Manifest loading and validation for FunPay Pulse SDK v1."""

from __future__ import annotations

import json
import ipaddress
import re
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

from .permissions import CURRENT_ACTION_SCOPES, EVENT_SCOPES, TRUSTED_MUTATING_SCOPES, split_scopes

PLUGIN_ID_RE = re.compile(r"^[a-z][a-z0-9_]{2,63}$")
SEMVER_RE = re.compile(r"^(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)$")
RUNTIME_TYPES = frozenset({"broker-poller", "webhook"})

RESERVED_PREFIXES: tuple[str, ...] = ("pulse_", "funpay_", "admin_", "system_")
RESERVED_PLUGIN_IDS: frozenset[str] = frozenset(
    {
        "autoresponder",
        "autoticket",
        "copylots",
        "chatspam",
        "offline_activite",
        "trademanager",
        "rentsteam",
        "dota2_rental",
        "autosmm",
        "autosteamns",
        "viproblox",
        "autorobux",
        "autodiscordboost",
        "autostars",
        "emailcode",
        "autogift",
        "autoaiaccounts",
        "autodump",
        "approute_reseller",
    }
)

_UI_DANGEROUS_STRING_PATTERNS = (
    re.compile(r"<\s*/?\s*[a-z][a-z0-9-]*(\s|>|/)", re.I),
    re.compile(r"\bon[a-z]+\s*=", re.I),
    re.compile(r"\bjavascript\s*:", re.I),
    re.compile(r"\b(function\s*\(|eval\s*\(|document\.|window\.)", re.I),
    re.compile(r"=>"),
)
_CONFIG_SECRET_KEY_MARKERS = (
    "authorization",
    "api_key",
    "connection_token",
    "cookie",
    "database",
    "db_path",
    "golden_key",
    "password",
    "secret",
    "signing_secret",
    "token",
)


class ManifestValidationError(ValueError):
    """Raised when a plugin manifest fails validation."""

    def __init__(self, errors: list[str]):
        self.errors = errors
        super().__init__("; ".join(errors))


def load_manifest(path: str | Path) -> dict[str, Any]:
    """Load a manifest JSON file."""

    manifest_path = Path(path)
    with manifest_path.open("r", encoding="utf-8") as handle:
        data = json.load(handle)

    if not isinstance(data, dict):
        raise ManifestValidationError(["manifest must be a JSON object"])

    return data


def validate_manifest_file(
    path: str | Path,
    *,
    allow_localhost: bool = False,
    allow_dangerous_scopes: bool = False,
    allow_future_scopes: bool = False,
    trusted: bool = False,
) -> dict[str, Any]:
    """Load and validate a manifest JSON file."""

    return validate_manifest(
        load_manifest(path),
        allow_localhost=allow_localhost,
        allow_dangerous_scopes=allow_dangerous_scopes,
        allow_future_scopes=allow_future_scopes,
        trusted=trusted,
    )


def validate_manifest(
    manifest: dict[str, Any],
    *,
    allow_localhost: bool = False,
    allow_dangerous_scopes: bool = False,
    allow_future_scopes: bool = False,
    trusted: bool = False,
) -> dict[str, Any]:
    """Validate and return a shallow normalized manifest copy.

    SDK v1 canonical fields follow the implementation plan:
    `manifest_version`, `plugin_id`, `runtime.type`, `runtime.url`, and
    flat `events`/`scopes` arrays. The current implemented runtime is
    `broker-poller`; `webhook` remains accepted as forward-compatible metadata.
    """

    errors: list[str] = []
    if not isinstance(manifest, dict):
        raise ManifestValidationError(["manifest must be a JSON object"])

    if trusted:
        allow_dangerous_scopes = False
        allow_future_scopes = False

    normalized = dict(manifest)

    _validate_required_string(normalized, "manifest_version", errors)
    if normalized.get("manifest_version") != "1.0":
        errors.append("manifest_version must be '1.0'")

    plugin_id = _validate_required_string(normalized, "plugin_id", errors)
    if plugin_id is not None:
        _validate_plugin_id(plugin_id, errors)

    _validate_required_string(normalized, "name", errors)

    version = _validate_required_string(normalized, "version", errors)
    if version is not None and not SEMVER_RE.fullmatch(version):
        errors.append("version must use basic semver X.Y.Z")

    runtime = normalized.get("runtime")
    if not isinstance(runtime, dict):
        errors.append("runtime must be an object")
    else:
        _validate_runtime(runtime, allow_localhost=allow_localhost, errors=errors)

    _validate_event_list(normalized, errors=errors)
    _validate_scope_list(
        normalized,
        allow_dangerous_scopes=allow_dangerous_scopes,
        allow_future_scopes=allow_future_scopes,
        allow_trusted_mutating_scopes=trusted,
        errors=errors,
    )

    for object_field in ("config_schema", "ui_schema"):
        if object_field in normalized and not isinstance(normalized[object_field], dict):
            errors.append(f"{object_field} must be an object")

    config_schema = normalized.get("config_schema")
    if isinstance(config_schema, dict):
        _validate_config_schema_public_only(config_schema, errors)

    ui_schema = normalized.get("ui_schema")
    if isinstance(ui_schema, dict):
        _validate_ui_schema_strings(ui_schema, errors)

    if errors:
        raise ManifestValidationError(errors)

    normalized.setdefault("events", [])
    normalized.setdefault("scopes", [])
    normalized.setdefault("config_schema", {})
    normalized.setdefault("ui_schema", {})
    return normalized


def _validate_required_string(manifest: dict[str, Any], field: str, errors: list[str]) -> str | None:
    value = manifest.get(field)
    if not isinstance(value, str) or not value.strip():
        errors.append(f"{field} is required and must be a non-empty string")
        return None
    return value


def _validate_plugin_id(plugin_id: str, errors: list[str]) -> None:
    if not PLUGIN_ID_RE.fullmatch(plugin_id):
        errors.append("plugin_id must match ^[a-z][a-z0-9_]{2,63}$")

    if plugin_id.startswith(RESERVED_PREFIXES):
        errors.append("plugin_id uses a reserved prefix")

    if plugin_id in RESERVED_PLUGIN_IDS:
        errors.append("plugin_id is reserved for a first-party plugin")


def _validate_runtime(runtime: dict[str, Any], *, allow_localhost: bool, errors: list[str]) -> None:
    runtime_type = runtime.get("type")
    if runtime_type not in RUNTIME_TYPES:
        errors.append("runtime.type must be 'broker-poller' or 'webhook'")

    url = runtime.get("url")
    if not isinstance(url, str) or not url.strip():
        errors.append("runtime.url is required and must be a non-empty string")
        return

    parsed = urlparse(url)
    host = parsed.hostname
    if not parsed.scheme or not host:
        errors.append("runtime.url must be an absolute URL")
        return
    if parsed.username or parsed.password:
        errors.append("runtime.url must not include credentials")
        return
    try:
        parsed.port
    except ValueError:
        errors.append("runtime.url has invalid port")
        return

    if parsed.scheme == "https":
        return

    if allow_localhost and parsed.scheme == "http" and _is_localhost(host):
        return

    errors.append("runtime.url must use https; localhost http is allowed only with allow_localhost=True")


def _is_localhost(host: str) -> bool:
    normalized = host.lower().strip("[]")
    if normalized == "localhost":
        return True
    try:
        return ipaddress.ip_address(normalized).is_loopback
    except ValueError:
        return False


def _validate_event_list(
    manifest: dict[str, Any],
    *,
    errors: list[str],
) -> None:
    value = manifest.get("events", [])
    if not isinstance(value, list):
        errors.append("events must be an array")
        return

    invalid_items = [scope for scope in value if not isinstance(scope, str) or not scope]
    if invalid_items:
        errors.append("events must contain only non-empty strings")
        return

    unknown = [scope for scope in value if scope not in EVENT_SCOPES]
    if unknown:
        errors.append(f"events contains unknown event scope(s): {', '.join(unknown)}")


def _validate_scope_list(
    manifest: dict[str, Any],
    *,
    allow_dangerous_scopes: bool,
    allow_future_scopes: bool,
    allow_trusted_mutating_scopes: bool,
    errors: list[str],
) -> None:
    value = manifest.get("scopes", [])
    if not isinstance(value, list):
        errors.append("scopes must be an array")
        return

    invalid_items = [scope for scope in value if not isinstance(scope, str) or not scope]
    if invalid_items:
        errors.append("scopes must contain only non-empty strings")
        return
    trusted_mutating = [scope for scope in value if scope in TRUSTED_MUTATING_SCOPES]
    if trusted_mutating and not allow_trusted_mutating_scopes:
        errors.append(
            "some scopes require trusted plugin review: "
            + ", ".join(trusted_mutating)
            + "; pass trusted=True or use CLI --trusted"
        )
        return
    _safe, dangerous, unknown = split_scopes(value)
    blocked_dangerous = [
        scope for scope in dangerous if scope not in TRUSTED_MUTATING_SCOPES
    ]
    if (
        allow_trusted_mutating_scopes
        and blocked_dangerous
        and not allow_dangerous_scopes
    ):
        errors.append(
            f"scopes contains dangerous scope(s): {', '.join(blocked_dangerous)}"
        )
        return
    future_only = [
        scope
        for scope in value
        if scope not in CURRENT_ACTION_SCOPES and scope not in TRUSTED_MUTATING_SCOPES
    ]
    if future_only and not allow_future_scopes:
        errors.append(
            "some scopes are future-only in the current Broker MVP: "
            + ", ".join(future_only)
            + "; use events for event delivery, logs:write for plugin logs, "
            "or pass allow_future_scopes=True"
        )
        return

    if unknown:
        errors.append(f"scopes contains unknown scope(s): {', '.join(unknown)}")
    if blocked_dangerous and not allow_dangerous_scopes:
        errors.append(
            f"scopes contains dangerous scope(s): {', '.join(blocked_dangerous)}"
        )


def _validate_ui_schema_strings(value: Any, errors: list[str]) -> None:
    for path, string_value in _walk_strings(value):
        if _looks_like_arbitrary_ui_code(string_value):
            errors.append(f"ui_schema contains disallowed JS/HTML string at {path}")


def _validate_config_schema_public_only(
    value: Any,
    errors: list[str],
    path: str = "config_schema",
) -> None:
    if isinstance(value, dict):
        format_value = value.get("format")
        if isinstance(format_value, str) and format_value.lower() == "secret":
            errors.append(
                f"{path}.format=secret is not supported in install config; use Broker secret storage after install"
            )
        properties = value.get("properties")
        if isinstance(properties, dict):
            for property_name in properties:
                if _is_sensitive_config_key(str(property_name)):
                    errors.append(
                        (
                            f"{path}.properties.{property_name} looks like a secret field; "
                            "use Broker secret storage after install"
                        )
                    )
        for key, child in value.items():
            _validate_config_schema_public_only(child, errors, f"{path}.{key}")
    elif isinstance(value, list):
        for index, child in enumerate(value):
            _validate_config_schema_public_only(child, errors, f"{path}[{index}]")


def _is_sensitive_config_key(key: str) -> bool:
    compact = _compact_key(key)
    return any(
        _compact_key(marker) in compact
        for marker in _CONFIG_SECRET_KEY_MARKERS
    )


def _compact_key(key: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", key.lower())


def _walk_strings(value: Any, path: str = "ui_schema") -> list[tuple[str, str]]:
    if isinstance(value, str):
        return [(path, value)]
    if isinstance(value, dict):
        result: list[tuple[str, str]] = []
        for key, child in value.items():
            result.extend(_walk_strings(child, f"{path}.{key}"))
        return result
    if isinstance(value, list):
        result = []
        for index, child in enumerate(value):
            result.extend(_walk_strings(child, f"{path}[{index}]"))
        return result
    return []


def _looks_like_arbitrary_ui_code(value: str) -> bool:
    return any(pattern.search(value) for pattern in _UI_DANGEROUS_STRING_PATTERNS)
