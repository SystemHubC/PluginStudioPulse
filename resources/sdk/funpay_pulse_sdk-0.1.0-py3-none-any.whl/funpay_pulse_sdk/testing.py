"""Local testing helpers for FunPay Pulse plugin apps."""

from __future__ import annotations

import json
import hashlib
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

from .broker import (
    BrokerAction,
    BrokerActionStatus,
    BrokerCapabilities,
    BrokerClientError,
    BrokerConfig,
    BrokerEvent,
    BrokerStorageLimits,
    BrokerStorageItem,
    BrokerSecretLimits,
    BrokerSecretItem,
    _bounded_limit,
    _normalize_logs_write_input as _broker_normalize_logs_write_input,
    _normalize_orders_get_input as _broker_normalize_orders_get_input,
    _normalize_orders_list_input as _broker_normalize_orders_list_input,
    _normalize_orders_refund_input as _broker_normalize_orders_refund_input,
    _normalize_orders_review_reply_input as _broker_normalize_orders_review_reply_input,
    _normalize_lots_get_input as _broker_normalize_lots_get_input,
    _normalize_lots_list_input as _broker_normalize_lots_list_input,
    _normalize_messages_send_input as _broker_normalize_messages_send_input,
    _normalize_lots_active_set_input as _broker_normalize_lots_active_set_input,
    _normalize_lots_price_set_input as _broker_normalize_lots_price_set_input,
    _normalize_lots_raise_input as _broker_normalize_lots_raise_input,
    _normalize_blacklist_add_input as _broker_normalize_blacklist_add_input,
    _normalize_blacklist_remove_input as _broker_normalize_blacklist_remove_input,
    _validate_idempotency_key,
    _validate_storage_key as _broker_validate_storage_key,
    _validate_secret_key as _broker_validate_secret_key,
    _validate_secret_value as _broker_validate_secret_value,
    broker_event_from_dict,
)


READ_ACTION_SCOPES = frozenset({"orders:read", "orders:list", "lots:read"})
MAX_READ_QUERY_DELIVERY_AGE_SECONDS = 24 * 60 * 60
MAX_MESSAGE_SEND_DELIVERY_AGE_SECONDS = 24 * 60 * 60
MAX_ORDER_REFUND_DELIVERY_AGE_SECONDS = 60 * 60
MAX_ORDERS_REVIEW_REPLY_DELIVERY_AGE_SECONDS = 24 * 60 * 60
MAX_LOTS_ACTIVE_SET_DELIVERY_AGE_SECONDS = 24 * 60 * 60
MAX_LOTS_PRICE_SET_DELIVERY_AGE_SECONDS = 24 * 60 * 60
MAX_LOTS_RAISE_DELIVERY_AGE_SECONDS = 60 * 60
MAX_BLACKLIST_ADD_DELIVERY_AGE_SECONDS = 24 * 60 * 60
MAX_BLACKLIST_REMOVE_DELIVERY_AGE_SECONDS = 24 * 60 * 60
SENSITIVE_CONFIG_KEY_MARKERS = (
    "authorization",
    "api_key",
    "connection_token",
    "cookie",
    "database",
    "db_path",
    "golden_key",
    "password",
    "secret",
    "signing_secret",
    "token",
)
SECRET_VALUE_PATTERNS = (
    re.compile(r"\bfppb_[A-Za-z0-9_-]+"),
    re.compile(r"\bfppi_[A-Za-z0-9_-]+"),
    re.compile(r"\bfp_[A-Fa-f0-9]{32}\b"),
    re.compile(r"\bBearer\s+[A-Za-z0-9._~+/=-]{12,}", re.I),
    re.compile(r"\bsk_(?:live|test)_[A-Za-z0-9_-]{8,}", re.I),
    re.compile(r"\bghp_[A-Za-z0-9_]{20,}", re.I),
    re.compile(r"\b[A-Za-z0-9_-]{32,}\.[A-Za-z0-9_-]{16,}\.[A-Za-z0-9_-]{16,}\b"),
)


def load_event_fixtures(path: str | Path) -> list[BrokerEvent]:
    """Load Broker delivery fixtures from JSON.

    The file can contain either a normal Broker poll response object with
    `items`, or a plain array of delivery objects. Fixture timestamps may use
    `fixture:now` for local server-like freshness checks.
    """

    fixture_path = Path(path)
    try:
        data = json.loads(fixture_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise BrokerClientError(f"fixture file is not valid JSON: {fixture_path}") from exc

    if isinstance(data, dict):
        items = data.get("items")
    else:
        items = data

    if not isinstance(items, list):
        raise BrokerClientError("fixture file must contain an items list or a plain array")

    return [broker_event_from_dict(item) for item in items]


def _normalize_read_scopes(
    read_scopes: Iterable[str] | None,
    *,
    allow_all: bool,
) -> set[str]:
    if read_scopes is None:
        return set(READ_ACTION_SCOPES) if allow_all else set()
    normalized: set[str] = set()
    for scope in read_scopes:
        if not isinstance(scope, str):
            raise ValueError("read_scopes must contain strings")
        value = scope.strip()
        if value not in READ_ACTION_SCOPES:
            raise ValueError(f"unsupported read scope: {value}")
        normalized.add(value)
    return normalized


class FixtureBrokerClient:
    """In-memory BrokerClient-compatible fixture client for local development."""

    def __init__(
        self,
        events: Iterable[BrokerEvent | dict[str, Any]],
        *,
        config: dict[str, Any] | None = None,
        config_revision: int = 1,
        allow_read_actions: bool = False,
        read_scopes: Iterable[str] | None = None,
        allow_message_actions: bool = False,
        allow_order_refund_actions: bool = False,
        allow_order_review_reply_actions: bool = False,
        allow_lot_actions: bool = False,
        allow_lot_price_actions: bool = False,
        allow_lot_raise_actions: bool = False,
        allow_blacklist_add_actions: bool = False,
        allow_blacklist_remove_actions: bool = False,
        allow_secret_storage: bool = False,
    ):
        self._events: list[BrokerEvent] = [
            event if isinstance(event, BrokerEvent) else broker_event_from_dict(event)
            for event in events
        ]
        self._events_by_delivery_id = {event.delivery_id: event for event in self._events}
        if len(self._events_by_delivery_id) != len(self._events):
            raise BrokerClientError("fixture delivery_id values must be unique")
        self._acked_delivery_ids: set[str] = set()
        self._actions: list[BrokerAction] = []
        self._action_requests_by_key: dict[str, tuple[str, str, BrokerAction]] = {}
        self._storage: dict[str, tuple[Any, str]] = {}
        self._secrets: dict[str, tuple[str, str]] = {}
        self._read_scopes = _normalize_read_scopes(
            read_scopes,
            allow_all=bool(allow_read_actions),
        )
        self._allow_message_actions = bool(allow_message_actions)
        self._allow_order_refund_actions = bool(allow_order_refund_actions)
        self._allow_order_review_reply_actions = bool(allow_order_review_reply_actions)
        self._allow_lot_actions = bool(allow_lot_actions)
        self._allow_lot_price_actions = bool(allow_lot_price_actions)
        self._allow_lot_raise_actions = bool(allow_lot_raise_actions)
        self._allow_blacklist_add_actions = bool(allow_blacklist_add_actions)
        self._allow_blacklist_remove_actions = bool(allow_blacklist_remove_actions)
        self._allow_secret_storage = bool(allow_secret_storage)
        if config is not None and not isinstance(config, dict):
            raise ValueError("config must be a JSON object")
        if (
            not isinstance(config_revision, int)
            or isinstance(config_revision, bool)
            or config_revision < 1
        ):
            raise ValueError("config_revision must be a positive integer")
        self._config = _normalize_config(config or {})
        self._config_revision = config_revision

    @classmethod
    def from_file(
        cls,
        path: str | Path,
        *,
        config: dict[str, Any] | None = None,
        config_revision: int = 1,
        allow_read_actions: bool = False,
        read_scopes: Iterable[str] | None = None,
        allow_message_actions: bool = False,
        allow_order_refund_actions: bool = False,
        allow_order_review_reply_actions: bool = False,
        allow_lot_actions: bool = False,
        allow_lot_price_actions: bool = False,
        allow_lot_raise_actions: bool = False,
        allow_blacklist_add_actions: bool = False,
        allow_blacklist_remove_actions: bool = False,
        allow_secret_storage: bool = False,
    ) -> "FixtureBrokerClient":
        return cls(
            load_event_fixtures(path),
            config=config,
            config_revision=config_revision,
            allow_read_actions=allow_read_actions,
            read_scopes=read_scopes,
            allow_message_actions=allow_message_actions,
            allow_order_refund_actions=allow_order_refund_actions,
            allow_order_review_reply_actions=allow_order_review_reply_actions,
            allow_lot_actions=allow_lot_actions,
            allow_lot_price_actions=allow_lot_price_actions,
            allow_lot_raise_actions=allow_lot_raise_actions,
            allow_blacklist_add_actions=allow_blacklist_add_actions,
            allow_blacklist_remove_actions=allow_blacklist_remove_actions,
            allow_secret_storage=allow_secret_storage,
        )

    @property
    def acked_delivery_ids(self) -> tuple[str, ...]:
        return tuple(
            event.delivery_id
            for event in self._events
            if event.delivery_id in self._acked_delivery_ids
        )

    @property
    def submitted_actions(self) -> tuple[BrokerAction, ...]:
        return tuple(self._actions)

    def poll_events(self, limit: int = 50) -> list[BrokerEvent]:
        limit = _bounded_limit(limit)
        return [
            event
            for event in self._events
            if event.delivery_id not in self._acked_delivery_ids
        ][:limit]

    def ack_event(self, delivery_id: str) -> dict[str, Any]:
        if not isinstance(delivery_id, str) or not delivery_id.strip():
            raise ValueError("delivery_id is required")

        normalized = delivery_id.strip()
        if normalized not in self._events_by_delivery_id:
            raise BrokerClientError(f"unknown delivery fixture: {normalized}")

        self._acked_delivery_ids.add(normalized)
        return {
            "success": True,
            "delivery_id": normalized,
            "status": "acked",
        }

    def get_config(self) -> BrokerConfig:
        return BrokerConfig(
            config=dict(self._config),
            config_revision=self._config_revision,
        )

    def get_capabilities(self) -> BrokerCapabilities:
        scopes = ["logs:write", "storage:own"]
        supported_actions = ["logs.write"]
        if self._allow_secret_storage:
            scopes.append("secrets:own")
        if "orders:read" in self._read_scopes:
            scopes.append("orders:read")
            supported_actions.append("orders.get")
        if "orders:list" in self._read_scopes:
            scopes.append("orders:list")
            supported_actions.append("orders.list")
        if "lots:read" in self._read_scopes:
            scopes.append("lots:read")
            supported_actions.extend(["lots.get", "lots.list"])
        if self._allow_message_actions:
            scopes.append("messages:send")
            supported_actions.append("messages.send")
        if self._allow_order_refund_actions:
            scopes.append("orders:refund")
            supported_actions.append("orders.refund")
        if self._allow_order_review_reply_actions:
            scopes.append("orders:review")
            supported_actions.append("orders.review.reply")
        if self._allow_lot_actions:
            scopes.append("lots:active")
            supported_actions.append("lots.active.set")
        if self._allow_lot_price_actions:
            scopes.append("lots:price")
            supported_actions.append("lots.price.set")
        if self._allow_lot_raise_actions:
            scopes.append("lots:raise")
            supported_actions.append("lots.raise")
        if self._allow_blacklist_add_actions:
            scopes.append("blacklist:add")
            supported_actions.append("blacklist.add")
        if self._allow_blacklist_remove_actions:
            scopes.append("blacklist:remove")
            supported_actions.append("blacklist.remove")
        return BrokerCapabilities(
            broker_events_enabled=True,
            broker_actions_enabled=True,
            broker_storage_enabled=True,
            broker_secrets_enabled=self._allow_secret_storage,
            broker_package_download_enabled=False,
            scopes=tuple(scopes),
            supported_actions=tuple(sorted(supported_actions)),
            storage_authorized=True,
            storage_limits=BrokerStorageLimits(
                max_items=128,
                max_key_length=128,
                max_value_bytes=16 * 1024,
                max_total_bytes=256 * 1024,
            ),
            secret_storage_authorized=self._allow_secret_storage,
            secret_storage_limits=BrokerSecretLimits(
                max_items=64,
                max_key_length=128,
                max_value_bytes=16 * 1024,
                max_total_bytes=256 * 1024,
            ),
            config_revision=self._config_revision,
        )

    def get_storage_item(self, key: str) -> BrokerStorageItem:
        normalized_key = _broker_validate_storage_key(key)
        item = self._storage.get(normalized_key)
        if item is None:
            raise BrokerClientError(f"unknown storage fixture: {normalized_key}")
        value, updated_at = item
        return BrokerStorageItem(
            key=normalized_key,
            value=_copy_json_value(value),
            created=False,
            updated_at=updated_at,
        )

    def set_storage_item(self, key: str, value: Any) -> BrokerStorageItem:
        normalized_key = _broker_validate_storage_key(key)
        created = normalized_key not in self._storage
        normalized_value = _normalize_storage_value(value)
        updated_at = f"fixture-storage-{len(self._storage) + (1 if created else 0)}"
        self._storage[normalized_key] = (normalized_value, updated_at)
        return BrokerStorageItem(
            key=normalized_key,
            value=_copy_json_value(normalized_value),
            created=created,
            updated_at=updated_at,
        )

    def delete_storage_item(self, key: str) -> bool:
        normalized_key = _broker_validate_storage_key(key)
        return self._storage.pop(normalized_key, None) is not None

    def get_secret_item(self, key: str) -> BrokerSecretItem:
        self._ensure_secret_storage_allowed()
        normalized_key = _broker_validate_secret_key(key)
        item = self._secrets.get(normalized_key)
        if item is None:
            raise BrokerClientError(f"unknown secret fixture: {normalized_key}")
        value, updated_at = item
        return BrokerSecretItem(
            key=normalized_key,
            value=value,
            value_size_bytes=len(value.encode("utf-8")),
            created=False,
            updated_at=updated_at,
        )

    def set_secret_item(self, key: str, value: str) -> BrokerSecretItem:
        self._ensure_secret_storage_allowed()
        normalized_key = _broker_validate_secret_key(key)
        normalized_value = _broker_validate_secret_value(normalized_key, value)
        created = normalized_key not in self._secrets
        updated_at = f"fixture-secret-{len(self._secrets) + (1 if created else 0)}"
        self._secrets[normalized_key] = (normalized_value, updated_at)
        return BrokerSecretItem(
            key=normalized_key,
            value=None,
            value_size_bytes=len(normalized_value.encode("utf-8")),
            created=created,
            updated_at=updated_at,
        )

    def delete_secret_item(self, key: str) -> bool:
        self._ensure_secret_storage_allowed()
        normalized_key = _broker_validate_secret_key(key)
        return self._secrets.pop(normalized_key, None) is not None

    def _ensure_secret_storage_allowed(self) -> None:
        if not self._allow_secret_storage:
            raise BrokerClientError("secret storage is disabled in this fixture")

    def submit_action(
        self,
        action_type: str,
        action_input: dict[str, Any],
        *,
        idempotency_key: str,
    ) -> BrokerAction:
        if not isinstance(action_type, str) or not action_type.strip():
            raise ValueError("action_type is required")
        if not isinstance(action_input, dict):
            raise ValueError("action_input must be a JSON object")
        normalized_key = _validate_idempotency_key(idempotency_key)
        normalized_type = action_type.strip()
        if normalized_type == "logs.write":
            normalized_input = _normalize_logs_write_input(action_input)
        elif normalized_type == "orders.get" and "orders:read" in self._read_scopes:
            normalized_input = _normalize_orders_get_input(action_input)
            _ensure_orders_get_binding(self._events_by_delivery_id, normalized_input)
        elif normalized_type == "orders.list" and "orders:list" in self._read_scopes:
            normalized_input = _normalize_orders_list_input(action_input)
            _ensure_orders_list_binding(self._events_by_delivery_id, normalized_input)
        elif normalized_type in {"lots.get", "lots.list"} and "lots:read" in self._read_scopes:
            if normalized_type == "lots.get":
                normalized_input = _normalize_lots_get_input(action_input)
                _ensure_lots_get_binding(self._events_by_delivery_id, normalized_input)
            else:
                normalized_input = _normalize_lots_list_input(action_input)
                _ensure_lots_list_binding(self._events_by_delivery_id, normalized_input)
        elif normalized_type in {"orders.get", "orders.list", "lots.get", "lots.list"}:
            raise BrokerClientError(f"unsupported action_type: {normalized_type}")
        elif normalized_type == "messages.send" and self._allow_message_actions:
            normalized_input = _normalize_messages_send_input(action_input)
            _ensure_messages_send_binding(self._events_by_delivery_id, normalized_input)
        elif normalized_type == "orders.refund" and self._allow_order_refund_actions:
            normalized_input = _normalize_orders_refund_input(action_input)
            _ensure_orders_refund_binding(self._events_by_delivery_id, normalized_input)
        elif (
            normalized_type == "orders.review.reply"
            and self._allow_order_review_reply_actions
        ):
            normalized_input = _normalize_orders_review_reply_input(action_input)
            rating = _ensure_orders_review_reply_binding(
                self._events_by_delivery_id,
                normalized_input,
            )
            normalized_input = {**normalized_input, "rating": rating}
        elif normalized_type == "lots.active.set" and self._allow_lot_actions:
            normalized_input = _normalize_lots_active_set_input(action_input)
            _ensure_lots_active_set_binding(self._events_by_delivery_id, normalized_input)
        elif normalized_type == "lots.price.set" and self._allow_lot_price_actions:
            normalized_input = _normalize_lots_price_set_input(action_input)
            _ensure_lots_price_set_binding(self._events_by_delivery_id, normalized_input)
        elif normalized_type == "lots.raise" and self._allow_lot_raise_actions:
            normalized_input = _normalize_lots_raise_input(action_input)
            _ensure_lots_raise_binding(self._events_by_delivery_id, normalized_input)
        elif normalized_type == "blacklist.add" and self._allow_blacklist_add_actions:
            normalized_input = _normalize_blacklist_add_input(action_input)
            _ensure_blacklist_binding(
                self._events_by_delivery_id,
                normalized_input,
                action_type="blacklist.add",
                max_age_seconds=MAX_BLACKLIST_ADD_DELIVERY_AGE_SECONDS,
            )
        elif normalized_type == "blacklist.remove" and self._allow_blacklist_remove_actions:
            normalized_input = _normalize_blacklist_remove_input(action_input)
            _ensure_blacklist_binding(
                self._events_by_delivery_id,
                normalized_input,
                action_type="blacklist.remove",
                max_age_seconds=MAX_BLACKLIST_REMOVE_DELIVERY_AGE_SECONDS,
            )
        else:
            raise BrokerClientError(f"unsupported action_type: {normalized_type}")
        input_json = json.dumps(
            normalized_input,
            sort_keys=True,
            separators=(",", ":"),
            ensure_ascii=False,
        )
        existing = self._action_requests_by_key.get(normalized_key)
        if existing is not None:
            existing_type, existing_input_json, existing_action = existing
            if existing_type != normalized_type or existing_input_json != input_json:
                raise BrokerClientError(
                    "idempotency key reused with different action input"
                )
            return BrokerAction(
                action_id=existing_action.action_id,
                action_type=existing_action.action_type,
                status=existing_action.status,
                idempotency_key_hash=existing_action.idempotency_key_hash,
                idempotency_key=existing_action.idempotency_key,
                created=False,
                created_at=existing_action.created_at,
            )

        action = BrokerAction(
            action_id=f"fixture_action_{len(self._actions) + 1}",
            action_type=normalized_type,
            status="queued",
            idempotency_key_hash=_broker_idempotency_key_hash(normalized_key),
            idempotency_key=normalized_key,
            created=True,
            created_at="fixture",
        )
        self._actions.append(action)
        self._action_requests_by_key[normalized_key] = (
            normalized_type,
            input_json,
            action,
        )
        return action

    def write_log(
        self,
        message: str,
        *,
        level: str = "info",
        context: dict[str, Any] | None = None,
        idempotency_key: str,
    ) -> BrokerAction:
        payload: dict[str, Any] = {
            "message": message,
            "level": level,
        }
        if context is not None:
            payload["context"] = context
        return self.submit_action(
            "logs.write",
            payload,
            idempotency_key=idempotency_key,
        )

    def get_order(
        self,
        *,
        account_id: str | int,
        order_id: str,
        delivery_id: str,
        idempotency_key: str,
    ) -> BrokerAction:
        payload = {
            "account_id": account_id,
            "order_id": order_id,
            "delivery_id": delivery_id,
        }
        return self.submit_action(
            "orders.get",
            payload,
            idempotency_key=idempotency_key,
        )

    def get_lot(
        self,
        *,
        account_id: str | int,
        lot_id: str | int,
        delivery_id: str,
        idempotency_key: str,
    ) -> BrokerAction:
        payload = {
            "account_id": account_id,
            "lot_id": lot_id,
            "delivery_id": delivery_id,
        }
        return self.submit_action(
            "lots.get",
            payload,
            idempotency_key=idempotency_key,
        )

    def list_orders(
        self,
        *,
        account_id: str | int,
        delivery_id: str,
        status: str = "paid",
        limit: int = 25,
        cursor: str | int | None = None,
        idempotency_key: str,
    ) -> BrokerAction:
        payload = {
            "account_id": account_id,
            "delivery_id": delivery_id,
            "status": status,
            "limit": limit,
            "cursor": cursor,
        }
        return self.submit_action(
            "orders.list",
            payload,
            idempotency_key=idempotency_key,
        )

    def list_lots(
        self,
        *,
        account_id: str | int,
        delivery_id: str,
        limit: int = 50,
        cursor: str | int | None = None,
        idempotency_key: str,
    ) -> BrokerAction:
        payload = {
            "account_id": account_id,
            "delivery_id": delivery_id,
            "limit": limit,
            "cursor": cursor,
        }
        return self.submit_action(
            "lots.list",
            payload,
            idempotency_key=idempotency_key,
        )

    def send_message(
        self,
        *,
        account_id: str | int,
        chat_id: str | int,
        delivery_id: str,
        text: str,
        idempotency_key: str,
    ) -> BrokerAction:
        payload = {
            "account_id": account_id,
            "chat_id": chat_id,
            "delivery_id": delivery_id,
            "text": text,
        }
        return self.submit_action(
            "messages.send",
            payload,
            idempotency_key=idempotency_key,
        )

    def refund_order(
        self,
        *,
        account_id: str | int,
        order_id: str,
        delivery_id: str,
        idempotency_key: str,
    ) -> BrokerAction:
        payload = {
            "account_id": account_id,
            "order_id": order_id,
            "delivery_id": delivery_id,
        }
        return self.submit_action(
            "orders.refund",
            payload,
            idempotency_key=idempotency_key,
        )

    def reply_to_review(
        self,
        *,
        account_id: str | int,
        order_id: str,
        delivery_id: str,
        text: str,
        idempotency_key: str,
    ) -> BrokerAction:
        payload = {
            "account_id": account_id,
            "order_id": order_id,
            "delivery_id": delivery_id,
            "text": text,
        }
        return self.submit_action(
            "orders.review.reply",
            payload,
            idempotency_key=idempotency_key,
        )

    def get_action(self, action_id: str) -> BrokerActionStatus:
        if not isinstance(action_id, str) or not action_id.strip():
            raise ValueError("action_id is required")
        normalized_action_id = action_id.strip()
        for action in self._actions:
            if action.action_id == normalized_action_id:
                return BrokerActionStatus(
                    action_id=action.action_id,
                    action_type=action.action_type,
                    status=action.status,
                    idempotency_key_hash=action.idempotency_key_hash,
                    idempotency_key=action.idempotency_key,
                    attempt_count=0,
                    created_at=action.created_at,
                    updated_at=action.created_at,
                    result={},
                )
        raise BrokerClientError(f"unknown action fixture: {normalized_action_id}")

    def set_lot_active(
        self,
        *,
        account_id: str | int,
        lot_id: str | int,
        enabled: bool,
        delivery_id: str,
        idempotency_key: str,
    ) -> BrokerAction:
        payload = {
            "account_id": account_id,
            "lot_id": lot_id,
            "enabled": enabled,
            "delivery_id": delivery_id,
        }
        return self.submit_action(
            "lots.active.set",
            payload,
            idempotency_key=idempotency_key,
        )

    def set_lot_price(
        self,
        *,
        account_id: str | int,
        lot_id: str | int,
        price: str | int | float,
        delivery_id: str,
        idempotency_key: str,
    ) -> BrokerAction:
        payload = {
            "account_id": account_id,
            "lot_id": lot_id,
            "price": price,
            "delivery_id": delivery_id,
        }
        return self.submit_action(
            "lots.price.set",
            payload,
            idempotency_key=idempotency_key,
        )

    def raise_lots(
        self,
        *,
        account_id: str | int,
        lot_id: str | int,
        delivery_id: str,
        idempotency_key: str,
    ) -> BrokerAction:
        payload = {
            "account_id": account_id,
            "lot_id": lot_id,
            "delivery_id": delivery_id,
        }
        return self.submit_action(
            "lots.raise",
            payload,
            idempotency_key=idempotency_key,
        )

    def add_to_blacklist(
        self,
        *,
        account_id: str | int,
        username: str,
        delivery_id: str,
        buyer_id: str | int | None = None,
        reason: str | None = None,
        block_messages: bool = True,
        block_delivery: bool = True,
        block_review_reply: bool = True,
        block_notifications: bool = False,
        expires_at: str | None = None,
        idempotency_key: str,
    ) -> BrokerAction:
        payload = {
            "account_id": account_id,
            "username": username,
            "buyer_id": buyer_id,
            "delivery_id": delivery_id,
            "reason": reason,
            "block_messages": block_messages,
            "block_delivery": block_delivery,
            "block_review_reply": block_review_reply,
            "block_notifications": block_notifications,
            "expires_at": expires_at,
        }
        return self.submit_action(
            "blacklist.add",
            payload,
            idempotency_key=idempotency_key,
        )

    def remove_from_blacklist(
        self,
        *,
        account_id: str | int,
        username: str,
        delivery_id: str,
        buyer_id: str | int | None = None,
        idempotency_key: str,
    ) -> BrokerAction:
        payload = {
            "account_id": account_id,
            "username": username,
            "buyer_id": buyer_id,
            "delivery_id": delivery_id,
        }
        return self.submit_action(
            "blacklist.remove",
            payload,
            idempotency_key=idempotency_key,
        )


def _normalize_logs_write_input(action_input: dict[str, Any]) -> dict[str, Any]:
    try:
        return _broker_normalize_logs_write_input(action_input)
    except ValueError as exc:
        raise BrokerClientError(str(exc)) from exc


def _normalize_orders_get_input(action_input: dict[str, Any]) -> dict[str, Any]:
    try:
        return _broker_normalize_orders_get_input(action_input)
    except ValueError as exc:
        raise BrokerClientError(str(exc)) from exc


def _normalize_orders_list_input(action_input: dict[str, Any]) -> dict[str, Any]:
    try:
        return _broker_normalize_orders_list_input(action_input)
    except ValueError as exc:
        raise BrokerClientError(str(exc)) from exc


def _normalize_orders_refund_input(action_input: dict[str, Any]) -> dict[str, Any]:
    try:
        return _broker_normalize_orders_refund_input(action_input)
    except ValueError as exc:
        raise BrokerClientError(str(exc)) from exc


def _normalize_orders_review_reply_input(action_input: dict[str, Any]) -> dict[str, Any]:
    try:
        return _broker_normalize_orders_review_reply_input(action_input)
    except ValueError as exc:
        raise BrokerClientError(str(exc)) from exc


def _normalize_lots_get_input(action_input: dict[str, Any]) -> dict[str, Any]:
    try:
        return _broker_normalize_lots_get_input(action_input)
    except ValueError as exc:
        raise BrokerClientError(str(exc)) from exc


def _normalize_lots_list_input(action_input: dict[str, Any]) -> dict[str, Any]:
    try:
        return _broker_normalize_lots_list_input(action_input)
    except ValueError as exc:
        raise BrokerClientError(str(exc)) from exc


def _normalize_lots_raise_input(action_input: dict[str, Any]) -> dict[str, Any]:
    try:
        return _broker_normalize_lots_raise_input(action_input)
    except ValueError as exc:
        raise BrokerClientError(str(exc)) from exc


def _normalize_blacklist_add_input(action_input: dict[str, Any]) -> dict[str, Any]:
    try:
        return _broker_normalize_blacklist_add_input(action_input)
    except ValueError as exc:
        raise BrokerClientError(str(exc)) from exc


def _normalize_blacklist_remove_input(action_input: dict[str, Any]) -> dict[str, Any]:
    try:
        return _broker_normalize_blacklist_remove_input(action_input)
    except ValueError as exc:
        raise BrokerClientError(str(exc)) from exc


def _ensure_orders_get_binding(
    events_by_delivery_id: dict[str, BrokerEvent],
    input_data: dict[str, Any],
) -> None:
    event = _bound_event(events_by_delivery_id, input_data["delivery_id"], "orders.get")
    _ensure_recent_fixture_delivery(
        event,
        "orders.get",
        max_age_seconds=MAX_READ_QUERY_DELIVERY_AGE_SECONDS,
    )
    if event.event_type not in {
        "events:new_order",
        "events:order_confirmed",
        "events:new_review",
    }:
        raise BrokerClientError("orders.get requires an order delivery")
    payload = event.payload
    if str(payload.get("account_id") or "") != input_data["account_id"]:
        raise BrokerClientError("orders.get account_id is not delivery-bound")
    if _fixture_order_id(payload.get("order_id")) != input_data["order_id"]:
        raise BrokerClientError("orders.get order_id is not delivery-bound")


def _ensure_orders_list_binding(
    events_by_delivery_id: dict[str, BrokerEvent],
    input_data: dict[str, Any],
) -> None:
    event = _bound_event(events_by_delivery_id, input_data["delivery_id"], "orders.list")
    _ensure_recent_fixture_delivery(
        event,
        "orders.list",
        max_age_seconds=MAX_READ_QUERY_DELIVERY_AGE_SECONDS,
    )
    if event.event_type not in {
        "events:new_order",
        "events:order_confirmed",
        "events:new_review",
    }:
        raise BrokerClientError("orders.list requires an order delivery")
    payload = event.payload
    if str(payload.get("account_id") or "") != input_data["account_id"]:
        raise BrokerClientError("orders.list account_id is not delivery-bound")


def _ensure_orders_refund_binding(
    events_by_delivery_id: dict[str, BrokerEvent],
    input_data: dict[str, Any],
) -> None:
    event = _bound_event(events_by_delivery_id, input_data["delivery_id"], "orders.refund")
    _ensure_recent_fixture_delivery(
        event,
        "orders.refund",
        max_age_seconds=MAX_ORDER_REFUND_DELIVERY_AGE_SECONDS,
    )
    if event.event_type != "events:new_order":
        raise BrokerClientError("orders.refund requires a new order delivery")
    payload = event.payload
    if str(payload.get("account_id") or "") != input_data["account_id"]:
        raise BrokerClientError("orders.refund account_id is not delivery-bound")
    if _fixture_order_id(payload.get("order_id")) != input_data["order_id"]:
        raise BrokerClientError("orders.refund order_id is not delivery-bound")
    status = payload.get("status")
    if status is not None and str(status).strip().lower() not in {"paid", "new", "active"}:
        raise BrokerClientError("orders.refund order status is not refundable")


def _ensure_orders_review_reply_binding(
    events_by_delivery_id: dict[str, BrokerEvent],
    input_data: dict[str, Any],
) -> int:
    event = _bound_event(
        events_by_delivery_id,
        input_data["delivery_id"],
        "orders.review.reply",
    )
    _ensure_recent_fixture_delivery(
        event,
        "orders.review.reply",
        max_age_seconds=MAX_ORDERS_REVIEW_REPLY_DELIVERY_AGE_SECONDS,
    )
    if event.event_type != "events:new_review":
        raise BrokerClientError("orders.review.reply requires a new review delivery")
    payload = event.payload
    if str(payload.get("account_id") or "") != input_data["account_id"]:
        raise BrokerClientError("orders.review.reply account_id is not delivery-bound")
    if _fixture_order_id(payload.get("order_id")) != input_data["order_id"]:
        raise BrokerClientError("orders.review.reply order_id is not delivery-bound")
    if payload.get("has_reply") is True:
        raise BrokerClientError("orders.review.reply review already has a reply")
    return _fixture_review_rating(payload.get("rating"))


def _ensure_lots_get_binding(
    events_by_delivery_id: dict[str, BrokerEvent],
    input_data: dict[str, Any],
) -> None:
    event = _bound_event(events_by_delivery_id, input_data["delivery_id"], "lots.get")
    _ensure_recent_fixture_delivery(
        event,
        "lots.get",
        max_age_seconds=MAX_READ_QUERY_DELIVERY_AGE_SECONDS,
    )
    if event.event_type not in {"events:new_order", "events:order_confirmed"}:
        raise BrokerClientError("lots.get requires an order delivery")
    payload = event.payload
    if str(payload.get("account_id") or "") != input_data["account_id"]:
        raise BrokerClientError("lots.get account_id is not delivery-bound")
    if str(payload.get("lot_id") or "") != input_data["lot_id"]:
        raise BrokerClientError("lots.get lot_id is not delivery-bound")


def _ensure_lots_list_binding(
    events_by_delivery_id: dict[str, BrokerEvent],
    input_data: dict[str, Any],
) -> None:
    event = _bound_event(events_by_delivery_id, input_data["delivery_id"], "lots.list")
    _ensure_recent_fixture_delivery(
        event,
        "lots.list",
        max_age_seconds=MAX_READ_QUERY_DELIVERY_AGE_SECONDS,
    )
    payload = event.payload
    if str(payload.get("account_id") or "") != input_data["account_id"]:
        raise BrokerClientError("lots.list account_id is not delivery-bound")


def _ensure_messages_send_binding(
    events_by_delivery_id: dict[str, BrokerEvent],
    input_data: dict[str, Any],
) -> None:
    event = _bound_event(events_by_delivery_id, input_data["delivery_id"], "messages.send")
    _ensure_recent_fixture_delivery(
        event,
        "messages.send",
        max_age_seconds=MAX_MESSAGE_SEND_DELIVERY_AGE_SECONDS,
    )
    payload = event.payload
    if str(payload.get("account_id") or "") != input_data["account_id"]:
        raise BrokerClientError("messages.send account_id is not delivery-bound")
    if str(payload.get("chat_id") or "") != input_data["chat_id"]:
        raise BrokerClientError("messages.send chat_id is not delivery-bound")


def _ensure_lots_active_set_binding(
    events_by_delivery_id: dict[str, BrokerEvent],
    input_data: dict[str, Any],
) -> None:
    event = _bound_event(events_by_delivery_id, input_data["delivery_id"], "lots.active.set")
    _ensure_recent_fixture_delivery(
        event,
        "lots.active.set",
        max_age_seconds=MAX_LOTS_ACTIVE_SET_DELIVERY_AGE_SECONDS,
    )
    if event.event_type not in {"events:new_order", "events:order_confirmed"}:
        raise BrokerClientError("lots.active.set requires an order delivery")
    payload = event.payload
    if str(payload.get("account_id") or "") != input_data["account_id"]:
        raise BrokerClientError("lots.active.set account_id is not delivery-bound")
    if str(payload.get("lot_id") or "") != input_data["lot_id"]:
        raise BrokerClientError("lots.active.set lot_id is not delivery-bound")


def _ensure_lots_price_set_binding(
    events_by_delivery_id: dict[str, BrokerEvent],
    input_data: dict[str, Any],
) -> None:
    event = _bound_event(events_by_delivery_id, input_data["delivery_id"], "lots.price.set")
    _ensure_recent_fixture_delivery(
        event,
        "lots.price.set",
        max_age_seconds=MAX_LOTS_PRICE_SET_DELIVERY_AGE_SECONDS,
    )
    if event.event_type not in {"events:new_order", "events:order_confirmed"}:
        raise BrokerClientError("lots.price.set requires an order delivery")
    payload = event.payload
    if str(payload.get("account_id") or "") != input_data["account_id"]:
        raise BrokerClientError("lots.price.set account_id is not delivery-bound")
    if str(payload.get("lot_id") or "") != input_data["lot_id"]:
        raise BrokerClientError("lots.price.set lot_id is not delivery-bound")


def _ensure_lots_raise_binding(
    events_by_delivery_id: dict[str, BrokerEvent],
    input_data: dict[str, Any],
) -> None:
    event = _bound_event(events_by_delivery_id, input_data["delivery_id"], "lots.raise")
    _ensure_recent_fixture_delivery(
        event,
        "lots.raise",
        max_age_seconds=MAX_LOTS_RAISE_DELIVERY_AGE_SECONDS,
    )
    if event.event_type not in {"events:new_order", "events:order_confirmed"}:
        raise BrokerClientError("lots.raise requires an order delivery")
    payload = event.payload
    if str(payload.get("account_id") or "") != input_data["account_id"]:
        raise BrokerClientError("lots.raise account_id is not delivery-bound")
    if str(payload.get("lot_id") or "") != input_data["lot_id"]:
        raise BrokerClientError("lots.raise lot_id is not delivery-bound")


def _ensure_blacklist_binding(
    events_by_delivery_id: dict[str, BrokerEvent],
    input_data: dict[str, Any],
    *,
    action_type: str,
    max_age_seconds: int,
) -> None:
    event = _bound_event(events_by_delivery_id, input_data["delivery_id"], action_type)
    _ensure_recent_fixture_delivery(
        event,
        action_type,
        max_age_seconds=max_age_seconds,
    )
    if event.event_type not in {
        "events:new_message",
        "events:new_order",
        "events:order_confirmed",
        "events:new_review",
    }:
        raise BrokerClientError(f"{action_type} requires a buyer delivery")
    payload = event.payload
    if str(payload.get("account_id") or "") != input_data["account_id"]:
        raise BrokerClientError(f"{action_type} account_id is not delivery-bound")
    if event.event_type == "events:new_message":
        if payload.get("is_own") is True or payload.get("is_system") is True:
            raise BrokerClientError(f"{action_type} requires a buyer delivery")
    username = input_data["username"].lower()
    usernames = {
        str(payload.get(key)).strip().lower()
        for key in ("buyer_username", "author_username", "username", "buyer_name", "author")
        if payload.get(key)
    }
    if username not in usernames:
        raise BrokerClientError(f"{action_type} username is not delivery-bound")
    buyer_id = input_data.get("buyer_id")
    if buyer_id is not None:
        buyer_ids = {
            str(payload.get(key)).strip()
            for key in ("buyer_id", "author_id")
            if payload.get(key)
        }
        if buyer_ids and buyer_id not in buyer_ids:
            raise BrokerClientError(f"{action_type} buyer_id is not delivery-bound")


def _bound_event(
    events_by_delivery_id: dict[str, BrokerEvent],
    delivery_id: str,
    action_type: str,
) -> BrokerEvent:
    event = events_by_delivery_id.get(delivery_id)
    if event is None:
        raise BrokerClientError(f"{action_type} must be bound to a fixture delivery")
    return event


def _ensure_recent_fixture_delivery(
    event: BrokerEvent,
    action_type: str,
    *,
    max_age_seconds: int,
) -> None:
    created_at = _fixture_event_timestamp(event.created_at)
    age_seconds = (datetime.now(timezone.utc) - created_at).total_seconds()
    if age_seconds > max_age_seconds:
        raise BrokerClientError(f"{action_type} delivery is too old")


def _fixture_order_id(value: Any) -> str | None:
    if not isinstance(value, str) or not value.strip():
        return None
    return value.strip().upper()


def _fixture_review_rating(value: Any) -> int:
    if isinstance(value, bool) or value is None:
        raise BrokerClientError("orders.review.reply rating is not delivery-bound")
    try:
        if isinstance(value, float) and not value.is_integer():
            raise ValueError
        parsed = int(value)
    except (TypeError, ValueError) as exc:
        raise BrokerClientError(
            "orders.review.reply rating is not delivery-bound"
        ) from exc
    if parsed < 1 or parsed > 5:
        raise BrokerClientError("orders.review.reply rating is not delivery-bound")
    return parsed


def _fixture_event_timestamp(value: str | None) -> datetime:
    if not isinstance(value, str) or not value.strip():
        raise BrokerClientError("fixture delivery timestamp is required")
    normalized = value.strip()
    if normalized in {"now", "fixture:now"}:
        return datetime.now(timezone.utc)
    if normalized.endswith("Z"):
        normalized = normalized[:-1] + "+00:00"
    try:
        parsed = datetime.fromisoformat(normalized)
    except ValueError as exc:
        raise BrokerClientError("fixture delivery timestamp is invalid") from exc
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


def _normalize_messages_send_input(action_input: dict[str, Any]) -> dict[str, Any]:
    try:
        return _broker_normalize_messages_send_input(action_input)
    except ValueError as exc:
        raise BrokerClientError(str(exc)) from exc


def _normalize_lots_active_set_input(action_input: dict[str, Any]) -> dict[str, Any]:
    try:
        return _broker_normalize_lots_active_set_input(action_input)
    except ValueError as exc:
        raise BrokerClientError(str(exc)) from exc


def _normalize_lots_price_set_input(action_input: dict[str, Any]) -> dict[str, Any]:
    try:
        return _broker_normalize_lots_price_set_input(action_input)
    except ValueError as exc:
        raise BrokerClientError(str(exc)) from exc


def _copy_json_value(value: Any) -> Any:
    try:
        return json.loads(json.dumps(value, ensure_ascii=False))
    except (TypeError, ValueError) as exc:
        raise BrokerClientError("storage value must be JSON-serializable") from exc


def _normalize_storage_value(value: Any) -> Any:
    copied = _copy_json_value(value)
    _reject_sensitive_storage_value(copied, path="value", depth=0)
    return copied


def _normalize_config(value: dict[str, Any]) -> dict[str, Any]:
    copied = _copy_json_value(value)
    if not isinstance(copied, dict):
        raise BrokerClientError("config must be a JSON object")
    _reject_sensitive_config_value(copied, path="config", depth=0)
    return copied


def _reject_sensitive_config_value(value: Any, path: str, depth: int) -> None:
    if depth > 8:
        raise BrokerClientError("config value is too deeply nested")
    if isinstance(value, dict):
        for key, child in value.items():
            key_text = str(key)
            if _is_sensitive_config_key(key_text):
                raise BrokerClientError(f"{path}.{key_text} looks like a secret field")
            _reject_sensitive_config_value(
                child,
                path=f"{path}.{key_text}",
                depth=depth + 1,
            )
        return
    if isinstance(value, list):
        for index, item in enumerate(value):
            _reject_sensitive_config_value(
                item,
                path=f"{path}[{index}]",
                depth=depth + 1,
            )
        return
    if isinstance(value, str) and _looks_like_secret_value(value):
        raise BrokerClientError(f"{path} looks like a secret value")


def _reject_sensitive_storage_value(value: Any, path: str, depth: int) -> None:
    if depth > 8:
        raise BrokerClientError("storage value is too deeply nested")
    if isinstance(value, dict):
        for key, child in value.items():
            try:
                _broker_validate_storage_key(str(key))
            except ValueError as exc:
                raise BrokerClientError(str(exc)) from exc
            _reject_sensitive_storage_value(
                child,
                path=f"{path}.{key}",
                depth=depth + 1,
            )
        return
    if isinstance(value, list):
        for index, item in enumerate(value):
            _reject_sensitive_storage_value(
                item,
                path=f"{path}[{index}]",
                depth=depth + 1,
            )
        return
    if isinstance(value, str) and _looks_like_secret_value(value):
        raise BrokerClientError(f"{path} looks like a secret value")


def _is_sensitive_config_key(key: str) -> bool:
    compact = _compact_key(key)
    return any(
        _compact_key(marker) in compact
        for marker in SENSITIVE_CONFIG_KEY_MARKERS
    )


def _compact_key(key: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", key.lower())


def _broker_idempotency_key_hash(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def _looks_like_secret_value(value: str) -> bool:
    return any(pattern.search(value) for pattern in SECRET_VALUE_PATTERNS)
