"""Marketplace metadata helpers for SDK publication workflows."""

from __future__ import annotations

import json
from urllib.parse import urlparse, urlunparse
from dataclasses import dataclass
from pathlib import Path
from typing import Any

DEFAULT_MARKETPLACE_METADATA_FILE = "funpay-pulse.marketplace.json"
MAX_MARKETPLACE_METADATA_BYTES = 64 * 1024
SUPPORTED_PRICING_TYPES = frozenset({"free", "one_time", "subscription", "trial"})
SUPPORTED_TOP_LEVEL_FIELDS = frozenset(
    {
        "pricing_type",
        "price_rub",
        "access_duration_days",
        "trial_days",
        "category",
        "summary",
        "publisher",
        "support",
        "support_url",
        "privacy_url",
        "refund_policy",
    }
)
SUPPORTED_PUBLISHER_FIELDS = frozenset({"name", "url"})
SUPPORTED_SUPPORT_FIELDS = frozenset({"telegram", "email", "url"})


class MarketplaceMetadataError(ValueError):
    """Raised when marketplace metadata cannot be trusted."""


@dataclass(frozen=True)
class MarketplaceMetadata:
    """Parsed `funpay-pulse.marketplace.json` metadata."""

    path: Path
    raw: dict[str, Any]
    pricing_type: str | None
    price_rub: int | None
    access_duration_days: int | None
    trial_days: int | None

    def pricing_defaults(self) -> dict[str, Any]:
        """Return fields that can seed the public-review pricing payload."""

        payload: dict[str, Any] = {}
        if self.pricing_type is not None:
            payload["pricing_type"] = self.pricing_type
        if self.price_rub is not None:
            payload["price_rub"] = self.price_rub
        if self.access_duration_days is not None:
            payload["access_duration_days"] = self.access_duration_days
        if self.trial_days is not None:
            payload["trial_days"] = self.trial_days
        return payload


def load_marketplace_metadata(plugin_dir: Path) -> MarketplaceMetadata | None:
    """Load optional marketplace metadata from a plugin root directory."""

    path = plugin_dir / DEFAULT_MARKETPLACE_METADATA_FILE
    if not path.exists():
        return None
    if not path.is_file():
        raise MarketplaceMetadataError(f"{DEFAULT_MARKETPLACE_METADATA_FILE} must be a file")
    if path.stat().st_size > MAX_MARKETPLACE_METADATA_BYTES:
        raise MarketplaceMetadataError(
            f"{DEFAULT_MARKETPLACE_METADATA_FILE} is too large; max 64 KiB"
        )

    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise MarketplaceMetadataError(
            f"{DEFAULT_MARKETPLACE_METADATA_FILE} is not valid JSON: {exc.msg}"
        ) from exc

    if not isinstance(data, dict):
        raise MarketplaceMetadataError(
            f"{DEFAULT_MARKETPLACE_METADATA_FILE} must contain a JSON object"
        )
    _validate_top_level_fields(data)
    _validate_optional_string(data, "category", max_length=80)
    _validate_optional_string(data, "summary", max_length=280)
    _validate_optional_url(data, "support_url")
    _validate_optional_url(data, "privacy_url")
    _validate_optional_string(data, "refund_policy", max_length=500)
    _validate_publisher(data.get("publisher"))
    _validate_support(data.get("support"))

    pricing_type = data.get("pricing_type")
    if pricing_type is not None:
        if not isinstance(pricing_type, str):
            raise MarketplaceMetadataError("pricing_type must be a string")
        if pricing_type not in SUPPORTED_PRICING_TYPES:
            raise MarketplaceMetadataError(
                "pricing_type must be free, one_time, subscription or trial"
            )

    return MarketplaceMetadata(
        path=path,
        raw=data,
        pricing_type=pricing_type,
        price_rub=_optional_int(data, "price_rub"),
        access_duration_days=_optional_int(data, "access_duration_days"),
        trial_days=_optional_int(data, "trial_days"),
    )


def _validate_top_level_fields(data: dict[str, Any]) -> None:
    unknown = sorted(set(data) - SUPPORTED_TOP_LEVEL_FIELDS)
    if unknown:
        fields = ", ".join(unknown)
        raise MarketplaceMetadataError(f"unsupported marketplace metadata fields: {fields}")


def _validate_optional_string(data: dict[str, Any], key: str, *, max_length: int) -> None:
    value = data.get(key)
    if value is None:
        return
    if not isinstance(value, str):
        raise MarketplaceMetadataError(f"{key} must be a string")
    if len(value.strip()) > max_length:
        raise MarketplaceMetadataError(f"{key} must be at most {max_length} characters")
    data[key] = value.strip()


def _validate_optional_url(data: dict[str, Any], key: str) -> None:
    value = data.get(key)
    if value is None:
        return
    if not isinstance(value, str):
        raise MarketplaceMetadataError(f"{key} must be a string")
    cleaned = value.strip()
    if not cleaned or len(cleaned) > 512:
        raise MarketplaceMetadataError(f"{key} must be a non-empty HTTPS URL")
    parsed = urlparse(cleaned)
    if (
        parsed.scheme != "https"
        or not parsed.netloc
        or parsed.username
        or parsed.password
    ):
        raise MarketplaceMetadataError(f"{key} must be a non-empty HTTPS URL")
    data[key] = urlunparse(
        (parsed.scheme, parsed.netloc, parsed.path or "", "", parsed.query, "")
    )


def _validate_publisher(value: Any) -> None:
    if value is None:
        return
    if not isinstance(value, dict):
        raise MarketplaceMetadataError("publisher must be a JSON object")
    unknown = sorted(set(value) - SUPPORTED_PUBLISHER_FIELDS)
    if unknown:
        fields = ", ".join(unknown)
        raise MarketplaceMetadataError(f"unsupported publisher fields: {fields}")

    name = value.get("name")
    if not isinstance(name, str) or not name.strip():
        raise MarketplaceMetadataError("publisher.name must be a non-empty string")
    cleaned_name = name.strip()
    if len(cleaned_name) > 80:
        raise MarketplaceMetadataError("publisher.name must be at most 80 characters")
    value["name"] = cleaned_name

    url = value.get("url")
    if url is None:
        return
    if not isinstance(url, str):
        raise MarketplaceMetadataError("publisher.url must be a string")
    cleaned_url = url.strip()
    if not cleaned_url or len(cleaned_url) > 512:
        raise MarketplaceMetadataError("publisher.url must be a non-empty HTTPS URL")
    parsed = urlparse(cleaned_url)
    if (
        parsed.scheme != "https"
        or not parsed.netloc
        or parsed.username
        or parsed.password
    ):
        raise MarketplaceMetadataError("publisher.url must be a non-empty HTTPS URL")
    value["url"] = urlunparse(
        (parsed.scheme, parsed.netloc, parsed.path or "", "", parsed.query, "")
    )


def _validate_support(value: Any) -> None:
    if value is None:
        return
    if not isinstance(value, dict):
        raise MarketplaceMetadataError("support must be a JSON object")
    unknown = sorted(set(value) - SUPPORTED_SUPPORT_FIELDS)
    if unknown:
        fields = ", ".join(unknown)
        raise MarketplaceMetadataError(f"unsupported support fields: {fields}")
    for key, item in value.items():
        if item is None:
            continue
        if not isinstance(item, str):
            raise MarketplaceMetadataError(f"support.{key} must be a string")
        if len(item.strip()) > 200:
            raise MarketplaceMetadataError(f"support.{key} must be at most 200 characters")


def _optional_int(data: dict[str, Any], key: str) -> int | None:
    value = data.get(key)
    if value is None:
        return None
    if not isinstance(value, int) or isinstance(value, bool):
        raise MarketplaceMetadataError(f"{key} must be an integer")
    return value
