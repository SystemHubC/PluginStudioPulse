"""Typed helpers for public FunPay Pulse Broker events."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from .broker import BrokerEvent


class EventParseError(ValueError):
    """Raised when a Broker event cannot be mapped to the public typed model."""


@dataclass(frozen=True)
class PluginEvent:
    """Base wrapper around a Broker delivery."""

    raw: BrokerEvent

    @property
    def delivery_id(self) -> str:
        return self.raw.delivery_id

    @property
    def event_id(self) -> str:
        return self.raw.event_id

    @property
    def event_type(self) -> str:
        return self.raw.event_type

    @property
    def payload(self) -> dict[str, Any]:
        return self.raw.payload

    @property
    def occurred_at(self) -> str | None:
        return _optional_string(self.payload, "occurred_at")


@dataclass(frozen=True)
class NewMessageEvent(PluginEvent):
    account_id: str | None
    chat_id: str
    message_id: str
    buyer_id: str | None
    buyer_username: str | None
    author_id: str | None
    author_username: str | None
    text: str | None
    is_own: bool
    is_system: bool
    sender_type: str


@dataclass(frozen=True)
class NewOrderEvent(PluginEvent):
    account_id: str | None
    order_id: str
    buyer_id: str | None
    buyer_username: str | None
    chat_id: str | None
    lot_id: str | None
    subcategory_id: str | None
    quantity: int | float | str | None
    amount: int | float | str | None
    title: str | None
    status: str


@dataclass(frozen=True)
class OrderConfirmedEvent(PluginEvent):
    account_id: str | None
    order_id: str
    buyer_id: str | None
    buyer_username: str | None
    chat_id: str | None
    lot_id: str | None
    subcategory_id: str | None
    title: str | None
    old_status: str | None
    new_status: str


@dataclass(frozen=True)
class NewReviewEvent(PluginEvent):
    account_id: str | None
    review_id: str
    order_id: str | None
    author_username: str | None
    rating: int | float | str | None
    text: str | None
    has_reply: bool


TypedPluginEvent = NewMessageEvent | NewOrderEvent | OrderConfirmedEvent | NewReviewEvent


def parse_broker_event(event: BrokerEvent) -> TypedPluginEvent:
    """Convert a raw Broker delivery into a typed public event object."""

    if not isinstance(event, BrokerEvent):
        raise EventParseError("event must be a BrokerEvent")

    if event.event_type == "events:new_message":
        return NewMessageEvent(
            raw=event,
            account_id=_optional_string(event.payload, "account_id"),
            chat_id=_required_string(event.payload, "chat_id"),
            message_id=_required_string(event.payload, "message_id"),
            buyer_id=_optional_string(event.payload, "buyer_id"),
            buyer_username=_optional_string(event.payload, "buyer_username"),
            author_id=_optional_string(event.payload, "author_id"),
            author_username=_optional_string(event.payload, "author_username"),
            text=_optional_string(event.payload, "text"),
            is_own=_optional_bool(event.payload, "is_own", default=False),
            is_system=_optional_bool(event.payload, "is_system", default=False),
            sender_type=_optional_string(event.payload, "sender_type") or "buyer",
        )

    if event.event_type == "events:new_order":
        return NewOrderEvent(
            raw=event,
            account_id=_optional_string(event.payload, "account_id"),
            order_id=_required_string(event.payload, "order_id"),
            buyer_id=_optional_string(event.payload, "buyer_id"),
            buyer_username=_optional_string(event.payload, "buyer_username"),
            chat_id=_optional_string(event.payload, "chat_id"),
            lot_id=_optional_string(event.payload, "lot_id"),
            subcategory_id=_optional_string(event.payload, "subcategory_id"),
            quantity=_optional_number(event.payload, "quantity"),
            amount=_optional_number(event.payload, "amount"),
            title=_optional_string(event.payload, "title"),
            status=_optional_string(event.payload, "status") or "paid",
        )

    if event.event_type == "events:order_confirmed":
        return OrderConfirmedEvent(
            raw=event,
            account_id=_optional_string(event.payload, "account_id"),
            order_id=_required_string(event.payload, "order_id"),
            buyer_id=_optional_string(event.payload, "buyer_id"),
            buyer_username=_optional_string(event.payload, "buyer_username"),
            chat_id=_optional_string(event.payload, "chat_id"),
            lot_id=_optional_string(event.payload, "lot_id"),
            subcategory_id=_optional_string(event.payload, "subcategory_id"),
            title=_optional_string(event.payload, "title"),
            old_status=_optional_string(event.payload, "old_status"),
            new_status=_optional_string(event.payload, "new_status") or "closed",
        )

    if event.event_type == "events:new_review":
        return NewReviewEvent(
            raw=event,
            account_id=_optional_string(event.payload, "account_id"),
            review_id=_required_string(event.payload, "review_id"),
            order_id=_optional_string(event.payload, "order_id"),
            author_username=_optional_string(event.payload, "author_username"),
            rating=_optional_number(event.payload, "rating"),
            text=_optional_string(event.payload, "text"),
            has_reply=_optional_bool(event.payload, "has_reply", default=False),
        )

    raise EventParseError(f"unsupported Broker event type: {event.event_type}")


def _required_string(payload: dict[str, Any], key: str) -> str:
    value = payload.get(key)
    if not isinstance(value, str) or not value.strip():
        raise EventParseError(f"Broker event payload missing {key}")
    return value


def _optional_string(payload: dict[str, Any], key: str) -> str | None:
    value = payload.get(key)
    if value is None:
        return None
    if not isinstance(value, str):
        return str(value)
    return value


def _optional_number(payload: dict[str, Any], key: str) -> int | float | str | None:
    value = payload.get(key)
    if value is None:
        return None
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float, str)):
        return value
    return str(value)


def _optional_bool(payload: dict[str, Any], key: str, *, default: bool) -> bool:
    value = payload.get(key)
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        return value.strip().lower() in {"1", "true", "yes", "on"}
    return bool(value)
