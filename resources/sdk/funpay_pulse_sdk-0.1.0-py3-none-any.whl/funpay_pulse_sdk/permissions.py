"""Permission scope definitions for Custom Plugin Platform SDK v1."""

from __future__ import annotations

EVENT_SCOPES: frozenset[str] = frozenset(
    {
        "events:new_order",
        "events:new_message",
        "events:new_review",
        "events:order_confirmed",
    }
)

CURRENT_ACTION_SCOPES: frozenset[str] = frozenset(
    {"logs:write", "storage:own", "secrets:own", "orders:read", "orders:list", "lots:read"}
)

TRUSTED_MUTATING_SCOPES: frozenset[str] = frozenset(
    {
        "messages:send",
        "orders:refund",
        "orders:review",
        "lots:active",
        "lots:price",
        "lots:raise",
        "blacklist:add",
        "blacklist:remove",
    }
)

FUTURE_SAFE_SCOPES: frozenset[str] = frozenset(
    {
        "ui:render",
        "config:read",
        "config:write",
    }
)

SAFE_SCOPES: frozenset[str] = EVENT_SCOPES | CURRENT_ACTION_SCOPES | FUTURE_SAFE_SCOPES
DANGEROUS_SCOPES: frozenset[str] = frozenset(
    {
        "lots:write",
        "delivery:approve",
        "delivery:reject",
        "blacklist:write",
        "public_chat:send",
        "accounts:read_sensitive",
    }
)

ALLOWED_SCOPES: frozenset[str] = SAFE_SCOPES | TRUSTED_MUTATING_SCOPES | DANGEROUS_SCOPES


def split_scopes(scopes: list[str]) -> tuple[list[str], list[str], list[str]]:
    """Return safe, dangerous and unknown scopes preserving input order."""

    safe: list[str] = []
    dangerous: list[str] = []
    unknown: list[str] = []

    for scope in scopes:
        if scope in SAFE_SCOPES:
            safe.append(scope)
        elif scope in TRUSTED_MUTATING_SCOPES or scope in DANGEROUS_SCOPES:
            dangerous.append(scope)
        else:
            unknown.append(scope)

    return safe, dangerous, unknown
