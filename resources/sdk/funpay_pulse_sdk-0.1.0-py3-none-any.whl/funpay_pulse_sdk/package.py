"""Local package builder for FunPay Pulse plugin source archives."""

from __future__ import annotations

import hashlib
import json
import re
import zipfile
from dataclasses import dataclass
from pathlib import Path, PurePosixPath
from typing import Any

from .broker import BrokerClientError
from .events import EventParseError, parse_broker_event
from .manifest import validate_manifest_file
from .testing import load_event_fixtures

PACKAGE_FORMAT = "funpay-pulse-plugin-package"
PACKAGE_VERSION = 1
PACKAGE_METADATA_NAME = "funpay-pulse-package.json"

MAX_PACKAGE_FILES = 128
MAX_PACKAGE_BYTES = 5 * 1024 * 1024
MAX_FILE_BYTES = 1024 * 1024
ZIP_TIMESTAMP = (1980, 1, 1, 0, 0, 0)

IGNORED_DIRECTORIES = frozenset(
    {
        "__pycache__",
        ".git",
        ".hg",
        ".mypy_cache",
        ".pytest_cache",
        ".ruff_cache",
        ".svn",
        ".tox",
        ".venv",
        "build",
        "dist",
        "node_modules",
        "venv",
    }
)
IGNORED_FILENAMES = frozenset(
    {
        ".DS_Store",
        "Thumbs.db",
    }
)
REJECTED_SUFFIXES = (
    ".db",
    ".dll",
    ".dylib",
    ".exe",
    ".key",
    ".p12",
    ".pfx",
    ".pyc",
    ".pyd",
    ".pyo",
    ".sqlite",
    ".sqlite3",
    ".so",
)
SECRET_FILENAME_MARKERS = (
    "authorization",
    "connection_token",
    "cookie",
    "golden_key",
    "id_rsa",
    "password",
    "private_key",
    "secret",
    "token",
)
PULSE_TOKEN_PATTERN = re.compile(r"fpp[bid]_[A-Za-z0-9_\-]{8,}")
SECRET_TEXT_PATTERNS = (
    PULSE_TOKEN_PATTERN,
    re.compile(r"\bsk_(?:live|test)_[A-Za-z0-9_\-]{16,}"),
    re.compile(r"\bgh[opusr]_[A-Za-z0-9_]{20,}"),
    re.compile(r"\bBearer\s+[A-Za-z0-9._~+/=-]{20,}", re.I),
    re.compile(
        r"\beyJ[A-Za-z0-9_\-]{10,}\.[A-Za-z0-9_\-]{10,}\.[A-Za-z0-9_\-]{10,}\b"
    ),
    re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----"),
    re.compile(
        r"\b(?:api[_-]?key|apikey|access[_-]?token|auth[_-]?token|broker[_-]?token|"
        r"client[_-]?secret|connection[_-]?token|golden[_-]?key|password|passwd|"
        r"refresh[_-]?token|secret|token)\b\s*[:=]\s*['\"][^'\"]{12,}",
        re.I,
    ),
)


class PluginPackageError(ValueError):
    """Raised when a local plugin package cannot be built safely."""


@dataclass(frozen=True)
class PluginPackageResult:
    """Metadata returned after building a local plugin package."""

    package_path: Path
    package_sha256: str
    package_bytes: int
    plugin_id: str
    plugin_version: str
    manifest_sha256: str
    file_count: int


@dataclass(frozen=True)
class _PackageFile:
    relative_path: str
    source_path: Path
    size: int
    sha256: str


def build_plugin_package(
    plugin_dir: str | Path,
    *,
    out: str | Path | None = None,
    allow_localhost: bool = False,
    allow_dangerous_scopes: bool = False,
    allow_future_scopes: bool = False,
    trusted: bool = False,
    fixture_path: str = "fixtures/events.json",
    require_fixtures: bool = False,
) -> PluginPackageResult:
    """Validate and package a local plugin directory as a deterministic `.fppkg`."""

    root = Path(plugin_dir).resolve()
    if not root.exists() or not root.is_dir():
        raise PluginPackageError(f"plugin directory does not exist: {root}")

    manifest_path = root / "funpay-pulse.plugin.json"
    manifest = validate_manifest_file(
        manifest_path,
        allow_localhost=allow_localhost,
        allow_dangerous_scopes=allow_dangerous_scopes,
        allow_future_scopes=allow_future_scopes,
        trusted=trusted,
    )
    fixture_relative_path = _validate_fixtures(
        root,
        fixture_path=fixture_path,
        require_fixtures=require_fixtures,
    )

    package_path = _package_output_path(root, manifest, out)
    if package_path.is_symlink():
        raise PluginPackageError(f"package output path is a symlink: {package_path}")
    package_path.parent.mkdir(parents=True, exist_ok=True)

    files = _collect_package_files(root, output_path=package_path.resolve())
    if not files:
        raise PluginPackageError("package has no files")
    if fixture_relative_path is not None:
        packaged_paths = {file.relative_path for file in files}
        if fixture_relative_path not in packaged_paths:
            raise PluginPackageError(
                f"fixtures: file is excluded from package: {fixture_relative_path}"
            )

    manifest_sha256 = _sha256_bytes(manifest_path.read_bytes())
    metadata = _package_metadata(
        manifest=manifest,
        manifest_sha256=manifest_sha256,
        files=files,
    )
    metadata_bytes = json.dumps(
        metadata,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")

    _write_zip(package_path, metadata_bytes=metadata_bytes, files=files)
    package_bytes = package_path.stat().st_size
    if package_bytes > MAX_PACKAGE_BYTES:
        package_path.unlink(missing_ok=True)
        raise PluginPackageError(
            f"package exceeds {MAX_PACKAGE_BYTES} bytes after compression"
        )

    return PluginPackageResult(
        package_path=package_path,
        package_sha256=_sha256_bytes(package_path.read_bytes()),
        package_bytes=package_bytes,
        plugin_id=str(manifest["plugin_id"]),
        plugin_version=str(manifest["version"]),
        manifest_sha256=manifest_sha256,
        file_count=len(files),
    )


def _validate_fixtures(
    root: Path,
    *,
    fixture_path: str,
    require_fixtures: bool,
) -> str | None:
    fixture_file = _resolve_fixture_path(root, fixture_path)
    if not fixture_file.exists():
        if require_fixtures:
            raise PluginPackageError(f"fixtures: missing {fixture_file}")
        return None
    if fixture_file.is_symlink():
        raise PluginPackageError(f"fixtures: symlink is not allowed: {fixture_path}")
    try:
        events = load_event_fixtures(fixture_file)
        for event in events:
            parse_broker_event(event)
    except (BrokerClientError, EventParseError, OSError) as exc:
        raise PluginPackageError(f"fixtures: invalid: {exc}") from exc
    return fixture_file.relative_to(root).as_posix()


def _resolve_fixture_path(root: Path, fixture_path: str) -> Path:
    requested_path = Path(fixture_path)
    if requested_path.is_absolute() or ".." in requested_path.parts:
        raise PluginPackageError(
            "fixtures: path must be a relative file inside plugin directory"
        )
    resolved_path = (root / requested_path).resolve()
    try:
        resolved_path.relative_to(root)
    except ValueError as exc:
        raise PluginPackageError(
            "fixtures: path must be a relative file inside plugin directory"
        ) from exc
    return resolved_path


def _package_output_path(
    root: Path,
    manifest: dict[str, Any],
    out: str | Path | None,
) -> Path:
    if out is not None:
        requested_path = Path(out).expanduser()
        if not requested_path.is_absolute():
            requested_path = Path.cwd() / requested_path
        return requested_path.parent.resolve() / requested_path.name
    filename = f"{manifest['plugin_id']}-{manifest['version']}.fppkg"
    return (root / "dist" / filename).resolve()


def _collect_package_files(root: Path, *, output_path: Path) -> list[_PackageFile]:
    files: list[_PackageFile] = []
    total_size = 0
    for path in sorted(root.rglob("*"), key=lambda item: _relative_posix(root, item)):
        if path.resolve() == output_path:
            continue
        if _is_ignored_path(root, path):
            continue
        if path.is_symlink():
            raise PluginPackageError(f"symlink is not allowed: {_relative_posix(root, path)}")
        if not path.is_file():
            continue
        relative_path = _relative_posix(root, path)
        _validate_package_path(relative_path)
        size = path.stat().st_size
        if size > MAX_FILE_BYTES:
            raise PluginPackageError(
                f"{relative_path} exceeds {MAX_FILE_BYTES} bytes"
            )
        total_size += size
        if total_size > MAX_PACKAGE_BYTES:
            raise PluginPackageError(
                f"source package exceeds {MAX_PACKAGE_BYTES} bytes"
            )
        _scan_file_content(path, relative_path)
        files.append(
            _PackageFile(
                relative_path=relative_path,
                source_path=path,
                size=size,
                sha256=_sha256_bytes(path.read_bytes()),
            )
        )

    if len(files) > MAX_PACKAGE_FILES:
        raise PluginPackageError(f"package has more than {MAX_PACKAGE_FILES} files")
    return files


def _is_ignored_path(root: Path, path: Path) -> bool:
    relative_parts = path.relative_to(root).parts
    if not relative_parts:
        return False
    for part in relative_parts:
        if part in IGNORED_DIRECTORIES:
            return True
    return path.name in IGNORED_FILENAMES


def _validate_package_path(relative_path: str) -> None:
    if PULSE_TOKEN_PATTERN.search(relative_path):
        raise PluginPackageError("secret-like filename is not allowed")
    pure_path = PurePosixPath(relative_path)
    if pure_path.is_absolute() or ".." in pure_path.parts:
        raise PluginPackageError(f"unsafe package path: {relative_path}")
    for part in pure_path.parts:
        if part.startswith("."):
            raise PluginPackageError(f"hidden files are not allowed: {relative_path}")
    lowered = relative_path.lower()
    if lowered.endswith(REJECTED_SUFFIXES):
        raise PluginPackageError(f"file type is not allowed: {relative_path}")
    if any(marker in lowered for marker in SECRET_FILENAME_MARKERS):
        raise PluginPackageError(f"secret-like filename is not allowed: {relative_path}")


def _scan_file_content(path: Path, relative_path: str) -> None:
    content = path.read_bytes()
    if b"\x00" in content:
        raise PluginPackageError(f"binary files are not allowed: {relative_path}")
    try:
        text = content.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise PluginPackageError(
            f"non-utf8 files are not allowed: {relative_path}"
        ) from exc
    for pattern in SECRET_TEXT_PATTERNS:
        if pattern.search(text):
            raise PluginPackageError(
                f"secret-like content is not allowed: {relative_path}"
            )


def _package_metadata(
    *,
    manifest: dict[str, Any],
    manifest_sha256: str,
    files: list[_PackageFile],
) -> dict[str, Any]:
    return {
        "package_format": PACKAGE_FORMAT,
        "package_version": PACKAGE_VERSION,
        "plugin_id": manifest["plugin_id"],
        "plugin_version": manifest["version"],
        "manifest_sha256": manifest_sha256,
        "file_count": len(files),
        "total_source_bytes": sum(file.size for file in files),
        "files": [
            {
                "path": file.relative_path,
                "size": file.size,
                "sha256": file.sha256,
            }
            for file in files
        ],
    }


def _write_zip(
    package_path: Path,
    *,
    metadata_bytes: bytes,
    files: list[_PackageFile],
) -> None:
    with zipfile.ZipFile(package_path, mode="w", compression=zipfile.ZIP_DEFLATED) as archive:
        _write_zip_entry(archive, PACKAGE_METADATA_NAME, metadata_bytes)
        for file in files:
            _write_zip_entry(
                archive,
                f"plugin/{file.relative_path}",
                file.source_path.read_bytes(),
            )


def _write_zip_entry(archive: zipfile.ZipFile, name: str, data: bytes) -> None:
    info = zipfile.ZipInfo(filename=name, date_time=ZIP_TIMESTAMP)
    info.create_system = 3
    info.compress_type = zipfile.ZIP_DEFLATED
    info.external_attr = 0o100644 << 16
    archive.writestr(info, data)


def _relative_posix(root: Path, path: Path) -> str:
    return path.relative_to(root).as_posix()


def _sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()
